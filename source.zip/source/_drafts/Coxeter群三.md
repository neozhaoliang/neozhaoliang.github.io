---
title: "Coxeter 群基础知识 (三)：双曲 Coxeter 群与 Boyd-Maxwell 球堆"
categories: [Coxeter Groups]
date: 2021-12-24
tags:
  - Coxeter groups
  - Cartan matrix
  - Coxeter matrix
  - Tits cone
  - Hyperbolic space
  - Boyd-Maxwell ball packings
  - Reflection
  - Sphere inversion
  - Root system
  - Circle packing
url: "coxeter-groups-III"
---
\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}

在本系列的前两篇文章 [反射](/coxeter-groups-I/) 和 [几何实现](/coxeter-groups-II/) 中，我介绍了 Coxeter 群的一些基本知识。本文是此系列的第三篇，将介绍 Coxeter 群与圆堆 (circle packing) 的关系。


