---
title: "Coxeter 群基础知识 (三)：双曲 Coxeter 群与 Boyd-Maxwell 球堆"
categories: [Coxeter Groups]
date: 2021-12-24
tags:
  - Coxeter groups
  - Cartan matrix
  - Coxeter matrix
  - Tits cone
  - Hyperbolic space
  - Boyd-Maxwell ball packings
  - Reflection
  - Sphere inversion
  - Root system
  - Circle packing
url: "coxeter-groups-III"
---
\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}

在本系列的前两篇文章 [反射](/coxeter-groups-I/) 和 [几何实现](/coxeter-groups-II/) 中，我介绍了 Coxeter 群的一些基本知识。本文是此系列的第三篇，将介绍双曲 Coxeter 群与圆堆 (circle packing) 的关系。

本文的讲述将紧接着上一篇[几何实现](/coxeter-groups-II/)的结尾处，以下是一些回顾。

<!--more-->

# 上期回顾

在本系列的前两篇文章中，我们是把根系和 Tits 锥放在不同的空间（$V^\ast$ 和 $V$）中处理的。本文中我们将使用一个非退化的内积 $\bullet$ 把二者等同起来，从而只在 $V$ 中讨论即可。

设 $(W,S)$ 是一个 Coxeter 群，$M=(m_{s,t})_{s,t\in S}$ 是 Coxeter 矩阵，$\Delta=\{\alpha_s\}_{s\in S}\in V^\ast$ 是一组单根，$V^\ast$ 上的内积 $\bullet$ 定义为

$$\alpha_s\bullet\alpha_t=c_{s,t}/2=\begin{cases}-\cos\dfrac{\pi}{m_{s,t}}&m_{s,t}<\infty,\\a_{s,t}&m_{s,t}=\infty.\end{cases}$$
其中 $a_{s,t}$ 是 $\leq-1$ 的实数，$C$ 是 Cartan 矩阵。在这个内积下，每个 $\alpha_s$ 都是单位向量：$\alpha_s\bullet\alpha_s=1$，不同 $\alpha_s$ 之间的内积非正：$\alpha_s\bullet\alpha_t\leq0,\,s\ne t$。此外每个 $\alpha_s$ 给出一个 $V^\ast$ 上的反射变换 $\rho_s$:
$$\rho_s:\ x\to x - 2(\alpha_s\bullet x)x,\quad x\in V^\ast.$$
不难验证 $\rho_s$ 保持内积 $\bullet$ 不变，因而是 $V^\ast$ 上的正交变换。

这个用内积 $\bullet$ 来把 $(W,S)$ 同构地映射到 $\mathrm{GL}(V)$ 的方法是许多教材普遍采用的，我们来说明当 $\bullet$ 非退化时这种方式和我们之前的处理是完全一致的。

如果内积 $\bullet$ 是非退化的，即不存在 $x\in V^\ast$ 使得 $x\bullet V^\ast=0$ 恒成立，则我们可以将 $V^\ast$ 和 $V$ 等同起来，这个对应就是把 $\alpha_s$ 等同于上一篇文章中的 $\alpha_s^\vee/2$，这是一个 $V^\ast\to V$ 的线性同构，并且 $\bullet$ 也成为 $V$ 上的内积，且对任何 $v\in V$ 有 $\lfun{\alpha_s}{v}=\alpha_s\bullet v$。这里左边的 $\lfun{\alpha_s}{v}$ 是把 $\alpha_s$ 看作对偶空间 $V^\ast$ 中的线性泛函，右边 $\alpha_s\bullet v$ 是把 $\alpha_s$ 看作 $V$ 中的向量（等同于 $\alpha_s^\vee/2$）。于是半空间 $\lfun{\alpha_s}{\cdot}>0$ 就是以 $\alpha_s$ 为法向量的超平面的正半空间 $\{v\in V\mid \alpha_s\bullet v > 0\}$。

所以在 Cartan 矩阵非退化的情况下，如果用 $\bullet$ 来定义正半空间和基本区域的话，即 $\fd=\cap_{s\in S}\{v\in V\mid \alpha_s\bullet v>0\}$，$\barfd$ 为 $\fd$ 的闭包，则我们之前的所有讨论都仍然适用。注意现在根系 $\Phi=W\cdot\Delta$ 和 Tits 锥 $\tc$ 都是 $V$ 中的集合。

$\{\alpha_s\}$ 的对偶基 $\{e_s\}$ 也非常有用，它的定义是 $\alpha_s\bullet e_t=\delta_{s,t},\,s,t\in S$。显然对任何 $e_t$ 有 $\alpha_s\bullet e_t\geq0,\forall s\in S$，所以 $e_t\in\barfd$。其实 $\{e_s\}$ 就是基本区域 $\barfd$ 的顶点，即房间的“墙角”。$e_s$ 落在所有 $\{\alpha_t=0,\,t\ne s\}$ 这些墙壁的交线上。


# Coxeter 群的 level

记 $\Gamma$ 为 Coxeter 群 $(W, S)$ 的 Coxeter 图。**在本文中都假定 $\Gamma$ 是连通的**。

记 $|S|=n$，我们给出如下定义：

+ 称 $W$ 是**有限** Coxeter 群，如果 $\bullet$ 是正定的。
+ 称 $W$ 是**仿射** Coxeter 群，如果 $\bullet$ 具有符号 $(n-1, 0)$。
+ 称 $W$ 是**双曲** Coxeter 群，如果 $\bullet$ 具有符号 $(n-1, 1)$。

由此我们给出 Coxeter 群的 level 的定义：

{% blockquote %}
**定义**：一个 Coxeter 群 $(W,S)$ 的 level 是最小的非负整数 $l$，使得在其 Coxeter 图 $\Gamma$ 中删去任何 $l$ 个顶点后得到的都是仿射或者有限图。
{% endblockquote %}

根据定义有限和仿射 Coxeter 群的 level 都是 0（因为不需要删去任何顶点即可得到有限或仿射的图）。

我们来看几个 level 大于 0 的例子：

|     |     |     |
|:---:|:---:|:---:|
| level=1 | level=2 | level=3 |
|<img src="/images/coxeter/level1.svg" height=120>| <img src="/images/coxeter/level2.svg" height=120> |<img src="/images/coxeter/level3.svg" height=120>|

+ 第一个图的三条边标号分别是 $(3,3,7)$，它不是有限的也不是仿射的，但是删去任何一个顶点以后剩下的两个顶点都构成一个有限二面体群，所以其 level 等于 1。
+ 第二个图的三条边标号分别是 $(3, 4, -1.1)$，它删去红色顶点以后剩下的两个顶点仍然构成一个双曲群，所以 level 肯定大于 1；删去任何两个顶点的话只剩一个顶点当然是有限的，所以这个群的 level 等于 2。
+ 第三个图删去两个红色顶点以后剩下的两个顶点仍然构成一个双曲群，所以 level 肯定大于 2；删去任何三个顶点以后只剩一个顶点当然是有限的，所以这个群的 level 等于 3。

在一个 level 等于 $l$ 的图中删去 $l$ 个顶点得到的必然是一些有限或者仿射的子图，我们其实可以进一步说，如果再多删掉一个顶点的话，那么剩下的一定是一些有限的子图：

{% blockquote %}
**定理 1**：在一个 level 等于 $l$ 的图中删去 $l+1$ 个顶点得到的必然是一些有限的子图。
{% endblockquote %}

**证明**：对 $l$ 归纳。当 $l=0$ 时，由于在一个有限或者仿射的图里面删去一个顶点得到的一定都是有限子图 [^1]，所以结论成立。

假设结论对所有小于 $l$ 的正整数成立，考虑 $l$ 的情形。用反证法。

不妨设删去 $\{i_1,\ldots,i_{j+1}\}$ 这 $l+1$ 个顶点后得到的不都是有限子图，那么剩下的部分中某个连通分支必然是仿射的。不妨设 $\Gamma-\{i_1,\ldots,i_{l+1}\}=\Gamma'\cup\Gamma''$，其中 $\Gamma'$ 是一个仿射的连通分支，$\Gamma''$（可能为空集）和 $\Gamma'$ 之间没有边相连。

由于 $\Gamma$ 是连通的，所以 $\Gamma'$ 必然和 $\{i_1,\ldots,i_{l+1}\}$ 中某个顶点有边连接，不妨设为 $i_{l+1}$：

|   |    |    |    |
|:---:|:---:|:---:|:---:|
|$i_1,i_2,\ldots,i_l$| $i_{l+1}$ | $\Gamma'$ | $\Gamma''$|

由于 $\Gamma$ 的 level 是 $l$，所以 $\{i_{l+1}\}\cup\Gamma'\subseteq\Gamma-\{i_1,\ldots,i_l\}$ 是一个仿射的连通子图，这个仿射子图删除 $i_{l+1}$ 后得到的 $\Gamma'$ 仍然是仿射的，这与我们刚论证过的 $l=0$ 的情形矛盾，所以结论得证。

# Level 1 的群是双曲的

首先是两个定义：

+ 如果 $v\in V$ 满足 $v\bullet v>0$，我们就称 $v$ 是**实的**。
+ 如果 $u,v\in V$ 满足 $u\bullet v\leq 0$ 且 $\bullet$ 限制在 $u,v$ 张成的二维子空间上**不是正定**的，就称 $u,v$ 是**分离**的 (disjoint)。

{% blockquote %}
**定理 2**：level 等于 1 的群都是双曲的，所有的 $\{e_s\}_{s\in S}$ 都不是实的且两两分离。
{% endblockquote %}

证明：我们先证明第一条，level 等于 1 的群都是双曲的。若不然，由于 $\bullet$ 的正负惯性指数必须都大于 0（即不可能是正半定或者负半定的），则有两种可能：

1. $\bullet$ 的负惯性指数是 1 且包含 0 空间。
2. $\bullet$ 的负惯性指数至少是 2。

情形 1 可以取 $V$ 的一组正交基包含两个向量 $u,v$ 满足 $u\bullet u=-1$ 和 $v\bullet v=0$。情形 2 可以取 $V$ 的一组正交基包含三个向量 $x,y,z$ 满足 $x\bullet x=y\bullet y=-1$ 和 $z\bullet z=1$。这时 $u=y$ 和 $v=x+z$ 满足 $u,v$ 正交且 $u\bullet u=-1$ 和 $v\bullet v=0$。

总之不论哪种情况我们都可以找到两个正交的非零向量 $u,v$ 满足 $u\bullet u<0$ 和 $v\bullet v=0$。

**我们断言任何满足 $u\bullet u<0$ 的向量，当其表示为 $u=\sum_{s\in S}u_s\alpha_s$ 时，所有的系数 $u_s$ 都非零且同号**。这是因为记
$$I_+=\{s\in S\mid u_s>0\},\quad I_-=\{s\in S\mid u_s<0\},\quad I_0=\{s\in S\mid u_s=0\}.$$
并记 $u_+=\sum_{s\in I_+}u_s\alpha_s$，$u_-=\sum_{t\in I_-}u_t\alpha_t$，则 $u=u_++u_-$ 且 $u_+\bullet u_-\geq 0$。所以 $u_+\bullet u_+ < 0$ 和 $u_-\bullet u_-<0$ 中至少有一个成立，不妨设 $u_+\bullet u_+<0$。如果 $u\ne u_+$，那么删去 $I_-\cup I_0$ 以后得到的子图不是有限的也不是仿射的，这与 $\Gamma$ 的 level 等于 1 矛盾。

**对于 $v\bullet v=0$ 我们可以使用同样的分析得到 $v=\sum_{s\in S}v_s\alpha_s$ 的系数 $v_s$ 中至多只有一个为 0，且剩下的其余非零元都同号**。这是因为如果 $I_0$ 包含至少两个元素的话，那么 $v\bullet v=0$ 说明删除 $I_0$ 以后得到的子图不是有限的，这与 $\Gamma$ 的 level 是 1 和前面的定理 1 矛盾。所以 $v_s$ 中至多只有一个为 0。其次如果 $v_+$ 和 $v_-$ 都不为 0 的话，类似上面对 $u$ 的讨论，这必然有 $(v_+\bullet v_+)\geq0$ 且 $(v_-\bullet v_-)\geq0$。然而
$$v\bullet v = (v_+\bullet v_+) + (v_-\bullet v_-) + 2(v_+\bullet v_-)=0.$$
三个非负数的和等于 0，所以只能是 $(v_+\bullet v_+) = (v_-\bullet v_-) =(v_+\bullet v_-)=0$。如果 $I_0$ 不是空集的话，由于 $(v_+\bullet v_+)=0$，所以删掉 $I_-\cup I_0$ 会至少删掉两个顶点，但得到的子图不是有限的，与 $\Gamma$ 的 level 是 1 和定理 1 矛盾，所以 $I_0=\emptyset$，$S=I_+\cup I_-$。然而 $(v_+\bullet v_-)=\sum_{s\in I_+,\,t\in I_-}v_sv_t(\alpha_s\bullet\alpha_t)=0$ 说明对任何 $s\in I_+,\,t\in I_-$ 有 $\alpha_s\bullet\alpha_t=0$，从而 $I_+$ 和 $I_-$ 将 $\Gamma$ 分成互不连通的两个集合，这与 $\Gamma$ 连通矛盾。

于是我们可以取合适的 $s\in S$ 使得 $v_s\ne 0$，令实数 $a=v_s/u_s$，则 $u'=au-v$ 满足 $(u'\bullet u')<0$ 且 $u'$ 的系数 $u'_s=0$，这与我们刚才论证的矛盾。

总之我们证明了 $\Gamma$ 的 level 等于 1 时内积 $\bullet$ 是双曲的。这一步我们其实只用到了 $u$ 的系数均不为 0 以及 $v$ 的系数至多只有一个为 0，并没有使用非零系数必然同号这一点，不过下面马上就会用到。

我们接下来证明所有的 $\{e_s\}_{s\in S}$ 都不是实的且两两分离。

注意到对任何 $s\in S$，由于子图 $\Gamma-\{s\}$ 的 level 等于 0，所以 $\{\alpha_t,\,t\ne s\}$ 张成一个有限或者仿射的 $\dim V-1$ 维子空间。这个子空间的正交补显然是 $e_s$ 张成的一维子空间，再结合 $\bullet$ 是双曲的我们有 $e_s\bullet e_s\leq 0$，所以所有的 $\{e_s\}_{s\in S}$ 都不是实的。

另一方面设 $e_s=\sum_{t\in S}c_t\alpha_t$，两边用 $e_t$ 内积不难看出 $c_t=e_s\bullet e_t$，所以

$$e_s = (e_s\bullet e_s)\alpha_s + \sum_{t\ne s} (e_s\bullet e_t)\alpha_t.$$

如果 $(e_s\bullet e_s)<0$，根据我们之前的讨论，所有的系数 $(e_s\bullet e_t)$ 都小于 0。

如果是 $(e_s\bullet e_s)=0$，则后面的所有系数 $\{e_s\bullet e_t,\,t\ne s\}$ 都不为 0 且同号。但是根据
$$1=(e_s\bullet \alpha_s) = (e_s\bullet e_s) + \sum_{t\ne s} (e_s\bullet e_t)(\alpha_t\bullet \alpha_s)=\sum_{t\ne s} (e_s\bullet e_t)(\alpha_t\bullet \alpha_s),$$
由于对所有的 $t\ne s$ 有 $(\alpha_s\bullet\alpha_t)\leq 0$，所以对这些 $t$ 仍然有 $(e_s\bullet e_t)<0$。

根据定理 1，对任何 $s, t$，$\{\alpha_{s'},\,s'\ne s,t\}$ 张成一个正定子空间，其正交补是 $\{e_s,e_t\}$ 张成的二维子空间，此子空间必然是双曲的，从而 $\{e_s,e_t\}$ 是分离的。

至此我们就完成了定理 2 的证明。

{% blockquote %}
**推论**：level 等于 1 的群其 Tits 锥 $\mathcal{C}$ 等于光锥的一个分支。
{% endblockquote %}

这是因为基本区域的闭包 $\barfd$ 都属于光锥的某个分支，所以 Tits 锥 $\tc=\cup_{w\in W}w\barfd$ 也属于光锥的同一个分支，再结合上一篇文章结尾处的结论，双曲的情形 Tits 锥是包含光锥的一个分支的，即得所证。

# Level 2 的群也是双曲的


{% blockquote %}
**定理 3**：level 等于 2 的群都是双曲的，所有的 $\{e_s\}_{s\in S}$ 两两分离。$e_s$ 是实的当且仅当 $T-\{s\}$ 的 level 等于 1，这时有 $0<(e_s\bullet e_s)\leq 1$。
{% endblockquote %}

证明：我们需要针对 $\Gamma$ 的顶点个数是否大于 3 分别处理。在 $\Gamma$ 只包含 3 个顶点的情形，$\Gamma$ 的 level 是 2 说明其必然有一条边的 Vinberg 标号小于 -1，所以 $\bullet$ 的矩阵形如
$$\begin{pmatrix}1&a&b\\a&1&c\\b&c&1\end{pmatrix}.$$
其中 $a,\,b,\,c\leq0$ 且 $a < -1$。这个矩阵的行列式是
$$1 - a^2 + 2abc - b^2-c^2 = 1-a^2 + 2bc(a+1)-(b+c)^2<0.$$
考虑到矩阵的迹等于 3，所以矩阵的 Sylvester 惯性指数必然是 $(2, 1)$，从而是双曲的。

下面我们再处理 $\Gamma$ 包含至少 4 个顶点的情形。

和 level 1 的情形类似，如果 $\bullet$ 不是双曲的，则我们可以取正交的向量 $u,v$ 满足 $u\bullet u<0,\,v\bullet v=0$。

**我们断言任何满足 $u\bullet u<0$ 的向量，当其表示为 $u=\sum_{s\in S}u_s\alpha_s$ 时，除去至多一个系数 $u_j$ 之外，其它的 $u_s$ 都非零且同号，$u_j$ 可能为 0 也可能异号**。

和之前一样，我们仍然记
$$I_+=\{s\in S\mid u_s>0\},\quad I_-=\{s\in S\mid u_s<0\},\quad I_0=\{s\in S\mid u_s=0\}.$$
如果 $I_0$ 包含至少两个元素，则 $u\bullet u<0$ 与 $\Gamma$ 的 level 是 2 矛盾。所以 $u_s$ 中至多只有一个是 0。

1. 如果 $I_0$ 包含一个元素 $s_0$，由于 $T-\{s_0\}$ 的 level 等于 1，根据我们定理 2 的证明中的讨论，$u$ 的所有其它系数非零且同号。
2. 如果 $I_0$ 是空集，且 $u_+\,u_-$ 均不为 0。由于 $(u_+\bullet u_+) < 0$ 和 $(u_-\bullet u_-)<0$ 中至少有一个成立，不妨设 $(u_+\bullet u_+)<0$，则 $I_-$ 中至多只能包含一个元素。

总之我们证明了系数 $u_s$ 要么均不为 0 且同号，要么除去一个 $u_j$ 之外均不为 0 且同号。

类似地，**我们断言任何满足 $v\bullet v=0$ 的向量，当其表示为 $v=\sum_{s\in S}v_s\alpha_s$ 时，除了会发生上面 $u$ 的两种情形之外，还有一种情形是系数 $v_s$ 中有两个是 0，其余的非零且同号**。

首先 $I_0$ 至多包含两个元素是显然的。

1. 如果 $I_0$ 包含两个元素，且 $v_+,\,v_-$ 都不是 0。由于 $\Gamma$ 的 level 是 2，所以删除任何三个顶点以后都是正定的，所以必须有 $(v_+\bullet v_+)>0,\,(v_-\bullet v_-)>0$。这与
    $$v\bullet v=(v_+\bullet v_+)+(v_-\bullet v_-)+2(v_+\bullet v_-)=0$$
    矛盾。所以 $v=v_+$ 或 $v=v_-$ 之一成立，即 $v$ 的所有非零系数都同号。
1. 如果 $I_0$ 包含一个元素 $s_0$，且 $v_+,\,v_-$ 都不是 0。$\Gamma$ 的 level 是 2 说明 $(v_+\bullet v_+)\geq0,\,(v_-\bullet v_-)\geq0$，从而 $(v_+\bullet v_+)=(v_-\bullet v_-)=(v_+\bullet v_-)=0$。由于 $\Gamma$ 至少包含 4 个顶点，所以 $I_+,\,I_-$ 中必有一个包含两个或者更多的顶点。不妨设 $|I_+|\geq2$，则删除 $I_+\cup I_0$ 后得到的子图不是正定，与 $\Gamma$ 的 level 等于 2 矛盾。所以 $v$ 的非零系数仍然同号。
2. 如果 $I_0$ 是空集，且 $v_+\,v_-$ 均不为 0。$\Gamma$ 是连通的说明 $v_+\bullet v_->0$，所以 $(v_+\bullet v_+) < 0$ 和 $(v_-\bullet v_-)<0$ 中至少有一个成立，不妨设 $(v_+\bullet v_+)<0$，则 level 2 说明 $I_-$ 中至多只能包含一个元素。

现在由于 $\{u_s\}$ 中至多只有一个是 0，$\{v_s\}$ 中至多只有两个是 0，而 $|\Gamma|\geq4$，所以存在下标 $i$ 使得 $a=v_i/u_i\ne 0$。于是 $u'=au-v$ 仍然满足与 $v$ 正交和 $u'\bullet u'<0$，但是它的下标 $i$ 的系数 $u'_i=0$，所以我们不妨用 $u'$ 代替 $u$，在一开始就假定 $u$ 的某个系数 $u_i=0$，于是 $u$ 的其它系数都非 0 且同号，不妨假设它们都大于 0。

由于 $v_s$ 中至多只有两个为 0，而 $|\Gamma|\geq4$，所以 $\{v_j,\,j\ne i\}$ 中至少有一个是非零的。

如果 $\{v_j,\,j\ne i\}$ 中只有一个非零元 $v_j$，则 $\Gamma$ 必然恰好有 4 个顶点，$v$ 形如 $v=v_i\alpha_i + v_j\alpha_j$ 满足 $v\bullet v=0$ 且 $\{\alpha_i,\alpha_j\}$ 是一个二维欧式平面，所以必然是 $m_{ij}=\infty$，$\alpha_i\bullet\alpha_j=-1$，$v$ 可以取为 $\alpha_i+\alpha_j$。由于 $\alpha_j$ 正交于 $v$，$u\bullet v=0$ 说明
$$u\bullet v=(u_j\alpha_j+u_k\alpha_k+u_m\alpha_m)\bullet v=(u_k\alpha_k+u_m\alpha_m)\bullet (\alpha_i+\alpha_j)=0,$$
由于 $u_k,u_m$ 大于 0，这说明
$$\alpha_k\bullet \alpha_i = \alpha_k\bullet \alpha_j =\alpha_m\bullet \alpha_i =\alpha_m\bullet \alpha_j =0.$$
即顶点 $\{i, j\}$ 与 $\{k,m\}=\Gamma-\{i,j\}$ 是不连通的，与 $\Gamma$ 连通矛盾。

如果至少有两个下标 $j,k$ 满足 $v_j/u_j\ne0,\,v_k/u_k\ne0$，通过选择 $v$ 或者 $-v$ 我们可以不妨设 $v_i<0$，以及 $v_j/u_j\leq v_k/u_k$。记 $a=v_j/u_j$，则 $u'=au-v$ 满足 $(u'\bullet u')<0$，但是 $u'_i=-v_i>0$，$u'_j=0$，$u'_k\leq 0$，矛盾。

至此我们证明了当 $\Gamma$ 的 level 等于 2 时是双曲的。

利用定理 2 中的恒等式

$$e_s = (e_s\bullet e_s)\alpha_s + \sum_{t\ne s} (e_s\bullet e_t)\alpha_t.$$

如果 $(e_s\bullet e_s)\leq0$，则除去至多一个例外的 $k$ 必有 $(e_s\bullet e_t)\leq 0,\,t\ne s$。但是在上式两边用这个例外的 $k$ 对应的 $\alpha_k$ 内积得到 

$$0=e_s\bullet \alpha_k = (e_s\bullet e_t)(\alpha_s\bullet\alpha_t) +\sum_{t\ne s,k} (e_s\bullet e_t)(\alpha_t\bullet\alpha_k) + (e_s\bullet e_k)(\alpha_k\bullet\alpha_k).$$
上面的和项前两个都非负，最后一个大于 0，矛盾。

如果 $e_s\bullet e_s>0$，显然这当且仅当 $\Gamma-\{s\}$ 是双曲的，即 level 是 1。考虑 $\alpha_s$ 在 $(\mathbb{R}e_s)^\bot$ 上的正交投影 $\alpha_s'=\alpha_s-e_s/(e_s\bullet e_s)$。$\alpha_s'$ 仍然满足对任何 $t\ne s$ 有 $\alpha_s'\bullet\alpha_t\leq0$，所以它属于 $\Gamma-\{i\}$ 的对偶锥，所以 $(\alpha_s'\bullet\alpha_s')= 1-(e_s\bullet e_s)^{-1}\leq0$，即 $0<(e_s\bullet e_s)\leq1$。以及由于在对偶锥中所以 $(\alpha_s'\bullet e_j)=-(e_s\bullet e_j)/(e_s\bullet e_s)\geq0$，即 $(e_s\bullet e_j)\leq 0$。于是所有的 $\{e_s\}$ 之间两两内积非正。

又因为对任何 $i,j$，$\Gamma-\{i,j\}$ 是有限或者仿射的，所以其正交补，也就是 $\{e_i,e_j\}$ 张成的二维平面不是欧式的，所以 $\{e_s\}$ 之间是两两分离的。


# level = 1, 2 等价于双曲和分离


{% blockquote %}
**定理 4**：下面两点是等价的：

1. $\Gamma$ 的 level 等于 1 或 2；
2. $\Gamma$ 是双曲的，且任何两个权都互相分离。
{% endblockquote %}

证明：$1\Rightarrow 2$：只再证明对任何 $w\in W$，如果有 $e_i\ne w(e_j)$，则 $(e_i,w(e_j))\leq0$，并且二维平面 $\{e_i,w(e_j)\}$ 不是欧式的。

对 $l(w)$ 归纳：$l(w)=0$ 的情形已经证明。下面假设 $l(w)>0$，且结论对所有长度 $<l(w)$ 的群元素成立。

1. 如果存在 $k\ne i$ 使得 $l(s_kw)<l(w)$，则由于 $s_k(e_i)=e_i$，所以
    $$e_i\bullet w(e_j)=s_k(e_i)\bullet s_kw(e_j)=e_i\bullet s_kw(e_j).$$
   对 $l(s_kw)<l(w)$ 用归纳法即得。
2. 如果对任何 $k\ne i$ 都有 $l(s_kw)>l(w)$，则 $w$ 的任一既约表示必然以 $s_i$ 开头，即 $w$ 形如 $w=s_iw'$ 且 $l(w)>l(w')$。从而
    $$e_i\bullet w(e_j)=s_i(e_i)\bullet w'(e_j)=e_i\bullet w'(e_j)-2\alpha_i\bullet w'(e_j).$$
    根据归纳假设 $e_i\bullet w'(e_j)\leq0$。第二项 $\geq0$ 是由于 $l(s_iw')>l(w')$ 所以 $w'^{-1}\alpha_i\in\Phi^+$，从而 $(w'^{-1}\alpha_i\bullet e_j) = (\alpha_i\bullet w'(e_j))\geq0$。所以 $e_i\bullet w(e_j)\leq0$ 同样成立。为了证明 $\{e_i,w(e_j)\}$ 不是正定的，用反证法。若不然，则 $e_i$ 具有正的范数，从而其正交补 $(\mathbb{R}e_i)^\bot$，也就是 $\Gamma-\{i\}$ 的 level 必然是 1。设 $v$ 是 $w(e_j)$ 在 $(\mathbb{R}e_i)^\bot$ 上的投影分量，记 $U$ 是 $v$ 在 $(\mathbb{R}e_i)^\bot$ 中的正交补，则 $U =\mathbb{R}\{e_i,w(e_j)\}^\bot$ 是一个双曲子空间，所以 $v$ 也具有正范数：$(v\bullet v)>0$。然而对任何 $k\ne i$，我们有 $v\bullet\alpha_k = (w(e_j), \alpha_k)\geq0$，所以 $v$ 属于 $\Gamma-\{i\}$ 的对偶锥，所以必然有$v\bullet v=0$，矛盾。

$2\Rightarrow 1$：由于任何两个基本权 $e_i,e_j$ 张成的子空间 $U$ 不是正定的，所以其正交补 $U^\bot$ 不会包含 time-like 的向量（否则设 $u\in U^\bot$ 是 time-like 的，则 $U=(U^\bot)^\bot\subseteq (\mathbb{R}u)^\bot$，而 $(\mathbb{R}u)^\bot$ 是正定的），即 $\Gamma-\{i,j\}$ 必然是正定的或者半正定的，从而 $\Gamma$ 的 level 是 1 或者 2。


# 


[^1]: 这其实是 Coxeter 群中的一个重要结论，本文没有给出证明：如果 Coxeter 群 $(W,S)$ 的 Coxeter 图 $\Gamma$ 是连通的，且 Cartan 矩阵是半正定的，则 Cartan 矩阵的任何余子式都是正定的，即从 $\Gamma$ 中删除若干顶点后得到的是有限 Coxeter 群。见 Humphreys 著 "Reflection groups and Coxeter groups" 一书 2.6 小节。