---
title: "Coxeter 群基础知识 （三）：双曲 Coxeter 群与 Boyd-Maxwell 球堆"
categories: [Coxeter Groups]
date: 2021-12-24
tags:
  - Coxeter groups
  - Cartan matrix
  - Coxeter matrix
  - Tits cone
  - Hyperbolic space
  - Boyd-Maxwell ball packings
  - Reflection
  - Sphere inversion
  - Root system
  - Circle packing
url: "coxeter-groups-III"
---
\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}
\newcommand{\R}{\mathbb{R}}
\newcommand{\L}{\mathbb{L}}
\newcommand{\Q}{\mathcal{Q}}
\newcommand{\P}{\mathcal{P}}
\newcommand{\LR}{\mathbb{R}^{n+1,1}}
\newcommand{\PR}{\mathrm{P}(\mathbb{R}^{n+1,1})}
\newcommand{\cl}[1]{\overline{ #1 }}
\newcommand{\inn}{(\cdot,\cdot)}


本系列的前两篇文章 [反射](/coxeter-groups-I/) 和 [几何实现](/coxeter-groups-II/) 介绍了 Coxeter 群的一些基本知识。本文是系列的第三篇，将正式介绍双曲 Coxeter 群与球堆 (sphere packing) 的关系。本文主要是对 George Maxwell 的两篇文章的重新整理：

1. Sphere packings and hyperbolic reflection groups, Journal of Algebra, Volume 79, Issue 1, 1982.
2. Wythoff's construction for Coxeter groups, Journal of Algebra, Volume 123, Issue 2, 1989.

在文中我将分别用 Maxwell'82 和 Maxwell'89 来引用它们。

<!--more-->

# 上期回顾

设 $(W,S)$ 是 Coxeter 群，$M=(m_{s,t})_{s,t\in S}$ 是 Coxeter 矩阵，$\Delta=\{\alpha_s\}_{s\in S}\in V^\ast$ 是一组单根，$V^\ast$ 上的内积 $\inn$ 定义为

$$(\alpha_s,\alpha_t)=c_{s,t}/2=\begin{cases}-\cos\dfrac{\pi}{m_{s,t}}&m_{s,t}<\infty,\\-a_{s,t}&m_{s,t}=\infty.\end{cases}$$
其中 $a_{s,t}$ 是 $\geq1$ 的实数，$C=(c_{s,t})$ 是 Cartan 矩阵。在此内积下，每个 $\alpha_s$ 都是单位向量：$(\alpha_s,\alpha_s)=1$，且不同 $\alpha_s$ 之间的内积非正：$(\alpha_s,\alpha_t)\leq0,\,s\ne t$。

如果内积是非退化的，即不存在 $x\in V^\ast$ 使得 $(x,v)=0$ 对任何 $v\in V^\ast$ 成立，则我们可以将 $V^\ast$ 和 $V$ 等同起来，将 $\{\alpha_s\}$ 取为 $V$ 中的向量使得 $\lfun{\alpha_s}{\cdot}=(\alpha_s,\cdot)$ （实际上令 $\alpha_s=\alpha_s^\vee/2$ 即可），于是根系 $\Phi$ 和 Tits 锥 $\tc$ 都属于 $V$，我们可以抛掉对偶空间 $V^\ast$，只在 $V$ 中进行讨论。

对每个 $s\in S$，反射变换 $\rho_s$ 是 $\inn$ 下的正交变换：
$$\rho_s:\ x\to x - 2(\alpha_s, x)\alpha_s,\quad x\in V.$$

继续定义基本区域为 $\fd=\cap_{s\in S}\{v\in V\mid (\alpha_s, v)>0\}$，$\barfd$ 为 $\fd$ 的闭包，则我们之前的所有讨论都仍然适用。

$\{\alpha_s\}$ 的对偶基 $\{\omega_s\}$ 也非常有用，它定义为 $(\alpha_s,\omega_t)=\delta_{s,t},\,s,t\in S$。$\{\omega_s\}$ 就是基本区域 $\barfd$ 的“墙角”。

> **定义**：我们称 $\{\omega_s\}$ 为**基本权**，集合 $\{w\omega_s\mid w\in W, s\in S\}$ 为**权**。


# 背景知识

设 $V$ 是 $\R$ 上的 $n$ 维向量空间，$\inn$ 是 $V$ 上的一个符号为 $(n-1,1)$ 的内积，于是 $V$ 在此内积下成为一个 Lorentz 空间。对 $v\in V$，我们称 $v$ 是

1. space-like 的，如果 $(v,v)>0$；
2. light-like 的，如果 $(v,v)=0$；
3. time-like 的，如果 $(v,v)<0$。

如果 $U\subset V$ 是一个子空间，我们称 $U$ 是

1. space-like 的，如果 $\inn\mid_U$ 是正定的；
2. light-like 的，如果 $\inn\mid_U$ 是半正定的，但不是正定的；
3. time-like 的，如果 $\inn\mid_U$ 不是正定或者半正定的，或者等价地，$U$ 包含 time-like 的向量。

记 $U^\bot$ 是 $U$ 在 $V$ 中的正交补，则我们有如下结论：

1. $U$ 是 space-like 的当且仅当 $U^\bot$ 是 time-like 的；
2. $U$ 是 light-like 的当且仅当 $U^\bot$ 是 light-like 的。

这个结论会在后面经常用到。

设 $C=\{v\in V\mid (v,v)\leq 0\}$ 是所有非 space-like 向量组成的集合，在除去原点以后 $C$ 可以分成两个不相交的连通分支 $C=C_+\cup C_-$，$C_+,\,C_-$ 都是点锥且 $C_+=-C_-$。下面的结论也是经常用到的：

{% blockquote %}
对任何 $x,y\in C-\{0\}$：

1. 若 $(x,y)<0$ 则 $x,y$ 必然属于同一个连通分支；
2. 若 $(x,y)>0$ 则 $x,y$ 必然属于不同的连通分支；
3. $(x,y)=0$ 当前仅当 $x,y$ 是共线的 light-like 的向量。
{% endblockquote %}

在本文中我们用记号 $x\sim y$ 来表示 $x,y$ 属于同一个连通分支。


# Coxeter 群的 level

记 $\Gamma$ 为 Coxeter 群 $(W, S)$ 的 Coxeter 图。**在本文中都假定 $\Gamma$ 是连通的**。

记 $|\Gamma|=n$。回忆我们之前给出的有限、仿射、双曲 Coxeter 群的定义：

> **定义**：我们称 $W$ 具有
>
> 1. **有限**型，如果内积 $\inn$ 是正定的；
> 2. **仿射**型，如果内积 $\inn$ 的符号是 $(n-1,0)$；
> 3. **双曲**型，如果内积 $\inn$ 的符号是 $(n-1, 1)$。

当 $W$ 属于以上某种类型之一时，我们也称其 Coxeter 图 $\Gamma$ 具有对应的类型。

如果 $\Gamma'$ 是 $\Gamma$ 的子图，其顶点集是 $I\subseteq S$，则 $\Gamma'$ 对应的 Coxeter 群是椭圆子群 $W_I$，$W_I$ 的类型（当然也是 $\Gamma'$ 的类型）由 $\inn$ 在子空间 $U={\rm span}\{\alpha_s,s\in I\}$ 上的限制决定。

{% blockquote %}
**定义**：一个 Coxeter 群 $(W,S)$ 的 level 定义为最小的非负整数 $l$，使得在其 Coxeter 图 $\Gamma$ 中删去任何 $l$ 个顶点后，剩下的连通分支都是仿射或者有限的。
{% endblockquote %}

根据定义有限和仿射 Coxeter 群的 level 都是 0（因为不需要删去任何顶点）。

我们来看几个 level 大于 0 的例子：

|     |     |     |
|:---:|:---:|:---:|
| level=1 | level=2 | level=3 |
|<img src="/images/coxeter/level1.svg" height=120>| <img src="/images/coxeter/level2.svg" height=120> |<img src="/images/coxeter/level3.svg" height=120>|

+ 第一个图的三条边标号分别是 $(3,3,7)$，它不是有限的也不是仿射的，但是删去任何一个顶点以后剩下的两个顶点都构成一个有限二面体群，所以其 level 等于 1。
+ 第二个图的三条边标号分别是 $(3, 4, -1.1)$，它删去红色顶点以后剩下的两个顶点仍然构成一个 Vinberg 记号下的双曲群，所以 level 肯定大于 1；删去任何两个顶点的话只剩一个顶点当然是有限的，所以这个群的 level 等于 2。
+ 第三个图删去两个红色顶点以后剩下的两个顶点仍然构成一个 Vinberg 记号下的双曲群，所以 level 肯定大于 2；删去任何三个顶点以后只剩一个顶点当然是有限的，所以这个群的 level 等于 3。

<div id="thm1">
{% blockquote %}
**定理 1** (Maxwell'82 proposition 1.1)：在一个 level 等于 $l$ 的图中删去任何 $l+1$ 个顶点后，剩下的必然是一些有限的子图。
{% endblockquote %}
</div>

**证明**：对 $l$ 归纳。当 $l=0$ 时，由于在一个有限或者仿射的图里面删去一个顶点剩下的一定都是有限子图 [^1]，所以结论成立。

假设结论对所有小于 $l$ 的正整数成立，考虑 $l$ 的情形。用反证法。

不妨设删去 $\{i_1,\ldots,i_{l+1}\}$ 这 $l+1$ 个顶点后得到的不都是有限子图，那么剩下的部分中某个连通分支必然是仿射的。不妨设 $\Gamma-\{i_1,\ldots,i_{l+1}\}=\Gamma'\cup\Gamma''$，其中 $\Gamma'$ 是一个仿射的连通分支，$\Gamma''$（可能为空集）和 $\Gamma'$ 之间没有边相连。

由于 $\Gamma$ 是连通的，所以 $\Gamma'$ 必然和 $\{i_1,\ldots,i_{l+1}\}$ 中某个顶点有边连接，不妨设为 $i_{l+1}$：

<img style="margin:0px auto;display:block" width=400 src="/images/coxeter-groups/lemma.svg"/>

由于 $\Gamma$ 的 level 是 $l$，所以 $\{i_{l+1}\}\cup\Gamma'\subseteq\Gamma-\{i_1,\ldots,i_l\}$ 是一个仿射的连通子图，这个仿射子图删除 $i_{l+1}$ 后得到的 $\Gamma'$ 仍然是仿射的，这与 $l=0$ 的情形矛盾，所以结论得证。

## Level 1 的群是双曲的

本节来证明 level 1 的群都是双曲的。

首先是两个定义：

+ 如果 $v\in V$ 满足 $(v, v)>0$，我们就称 $v$ 是**实的**。
+ 如果 $u,v\in V$ 满足 $(u,v)\leq 0$ 且 $\inn$ 限制在 $u,v$ 张成的二维子空间上**不是正定**的，就称 $u,v$ 是**分离**的 (disjoint)。

<div id="thm2">
{% blockquote %}
**定理 2** (Maxwell'82 proposition 1.4)：level 等于 1 的群都是双曲的，所有的基本权 $\{\omega_s\}_{s\in S}$ 都**不是**实的且两两分离。
{% endblockquote %}
</div>

证明：我们先证明第一条，level 等于 1 的群都是双曲的。首先给出一个引理：

> **引理**：如果 $W$ 的 level 是 1，且不是双曲的，则我们可以找到两个正交的非零向量 $u,v$ 满足 $(u,u)<0$ 和 $(v, v)=0$。

引理的证明：由于 $W$ 的 level 是 1，$\inn$ 不可能是正定/半正定的，也不可能是负定/半负定的，所以 $\inn$ 的正负惯性指数都非 0。如果 $W$ 不是双曲的，即 $\inn$ 的符号不是 $(n-1,1)$，那么有两种可能：

1. $\inn$ 的负惯性指数是 1 且有非平凡的零空间 (null space)。
2. $\inn$ 的负惯性指数至少是 2。

情形 1 可以取 $V$ 的一组正交基包含两个向量 $u,v$ 满足 $(u, u)=-1$ 和 $(v,v)=0$。情形 2 可以取 $V$ 的一组正交基包含三个向量 $x,y,z$ 满足 $(x,x)=(y, y)=-1$ 和 $(z,z)=1$。第二种情形下取 $u=y$ 和 $v=x+z$，则 $u,v$ 正交且 $(u,u)=-1,\,(v,v)=0$。$\blacksquare$

回到定理的证明。

用反证法，如果 $\Gamma$ 的 level 是 1 但不是双曲的，则按照上面的引理，我们可以取两个正交的非零向量 $u,v$ 满足 $(u,u)<0,\, (v,v)=0$。我们有如下两个断言：

1. 我们断言**任何满足 $(u, u)<0$ 的向量，当其表示为 $u=\sum_{s\in S}u_s\alpha_s$ 时，所有的系数 $u_s$ 都非零且同号**。
2. 我们断言**任何满足 $(v, v)=0$ 的向量，当其表示为 $v=\sum_{s\in S}v_s\alpha_s$ 时，所有的系数 $v_s$ 中至多只有一个为 0，且非零元都同号**。

我们先承认这两个断言是正确的，用它们来导出矛盾。

取 $s\in S$ 使得 $v_s\ne 0$，令 $a=v_s/u_s$，则 $u'=au-v$ 满足 $(u',u')=a^2(u,u)<0$ 且 $u'$ 的 $\alpha_s$ 项的系数 $u'_s=0$。但根据断言 1，$u'$ 的系数必须非零且同号，这就导致了矛盾，所以 $\Gamma$ 必然是双曲的。

断言 1 的证明如下：记

$$I_+=\{s\in S\mid u_s>0\},\quad I_-=\{s\in S\mid u_s<0\},\quad I_0=\{s\in S\mid u_s=0\}.$$
并记 $u_+=\sum_{s\in I_+}u_s\alpha_s$，$u_-=\sum_{t\in I_-}u_t\alpha_t$，则 $u=u_++u_-$ 且
$$(u_+, u_-)=\sum_{s\in I_+}\sum_{t\in I_-}u_su_t(\alpha_s,\alpha_t)\geq 0.$$
而 $(u,u)=(u_+,u_+) + (u_-,u_-) + 2(u_+,u_-)$，所以 $(u_+, u_+) < 0$ 和 $(u_-, u_-)<0$ 中至少有一个成立，不妨设 $(u_+, u_+)<0$。如果 $I_-$ 和 $I_0$ 中有一个不是空集，那么 $I_+$ 作为删去$I_-\cup I_0$ 后的子图包含 time-like 的向量 $u_+$，所以不是有限/仿射的，这与 $\Gamma$ 的 level 等于 1 矛盾。所以 $I=I_+$，即所有系数 $u_s$ 都大于 0。相应地如果是 $(u_-,u_-)<0$ 的话则 $I=I_-$ 且所有 $u_s$ 都小于 0。

对断言 2 我们仍然采用类似的记号，记
$$I_+=\{s\in S\mid v_s>0\},\quad I_-=\{s\in S\mid v_s<0\},\quad I_0=\{s\in S\mid v_s=0\}.$$
并记 $v_+=\sum_{s\in I_+}v_s\alpha_s$，$v_-=\sum_{t\in I_-}v_t\alpha_t$，则 $(v_+,v_-)\geq0$。

我们想证明 $|I_0|\leq1$，并且 $I_+$ 和 $I_-$ 中必有一个是空集。

如果 $|I_0|\geq2$，那么 $(v, v)=0$ 说明删除 $I_0$ 以后得到的子图不是有限的，这与 $\Gamma$ 的 level 是 1 和[定理 1](#thm1) 矛盾。所以 $|I_0|\leq 1$。

如果 $I_+,\,I_-$ 都不是空集的话，则 $v_+,v_-$ 非零，并且必然有 $(v_+, v_+)\geq0$ 且 $(v_-, v_-)\geq0$，否则删掉 $I_+$ 或者 $I_-$ 以后剩下的子图不是有限或者仿射的，与 $\Gamma$ 的 level 是 1 矛盾。然而
$$0=(v, v) = (v_+,v_+) + (v_-,v_-) + 2(v_+,v_-).$$
三个非负数的和等于 0，只能是 $(v_+,v_+) = (v_-,v_-) =(v_+, v_-)=0$。现在分情况讨论：

1. 如果 $|I_0|=1$，那么删掉 $I_-\cup I_0$ 会至少删掉两个顶点，但 $(v_+,v_+)=0$ 说明剩下的子图不是有限的，与 $\Gamma$ 的 level 是 1 和[定理 1](#thm1) 矛盾。
2. 如果 $I_0=\emptyset$，则 $S=I_+\cup I_-$。然而 $(v_+,v_-)=\sum_{s\in I_+,\,t\in I_-}v_sv_t(\alpha_s,\alpha_t)=0$ 说明对任何 $s\in I_+,\,t\in I_-$ 有 $(\alpha_s,\alpha_t)=0$，从而 $I_+$ 和 $I_-$ 将 $\Gamma$ 分成互不连通的两个集合，这与 $\Gamma$ 连通矛盾。

总之 $I_+$ 和 $I_-$ 必有一个是空集，断言 2 得证。

我们还需要证明所有的基本权 $\{\omega_s\}_{s\in S}$ 都不是实的且两两分离。

注意到对任何 $s\in S$，由于子图 $\Gamma-\{s\}$ 的 level 等于 0，所以 $\{\alpha_t,\,t\ne s\}$ 张成一个有限或者仿射的 $n-1$ 维子空间。这个子空间在 $\inn$ 下的正交补显然是 $\omega_s$ 张成的一维子空间 $\mathbb{R}\omega_s$，再结合 $\inn$ 是双曲的我们有 $(\omega_s,\omega_s)\leq 0$，所以 $\{\omega_s\}_{s\in S}$ 都不是实的。

进一步设 $\omega_s=\sum_{t\in S}c_t\alpha_t$，两边用 $\omega_t$ 作内积不难看出 $c_t=(\omega_s,\omega_t)$，所以

$$\omega_s = (\omega_s,\omega_s)\alpha_s + \sum_{t\ne s} (\omega_s,\omega_t)\alpha_t.$$

我们已经看到了必然有 $(\omega_s,\omega_s)\leq0$。根据之前的讨论：

1. 如果 $(\omega_s,\omega_s)<0$，则后面所有的系数 $(\omega_s,\omega_t)$ 都小于 0。
2. 如果 $(\omega_s,\omega_s)=0$，则后面所有的系数 $\{(\omega_s,\omega_t)\}_{t\ne s}$ 都不为 0 且同号。我们来确定它们的符号：根据
$$1=(\omega_s,\alpha_s) = (\omega_s,\omega_s) + \sum_{t\ne s} (\omega_s,\omega_t)(\alpha_t,\alpha_s)=\sum_{t\ne s} (\omega_s,\omega_t)(\alpha_t,\alpha_s),$$
由于对所有的 $t\ne s$ 有 $(\alpha_s,\alpha_t)\leq 0$，所以只能是 $(\omega_s,\omega_t)<0$。

总之对任何 $s\ne t$ 都有 $(\omega_s,\omega_t)<0$。此外二维子空间 $U={\rm span}\{\omega_s,\omega_t\}$ 的正交补是 $U^\bot={\rm span}\{\alpha_{k},\,k\ne s,t\}$，根据[定理 1](#thm1) $U^\bot$ 是正定的，所以 $U$ 必然是双曲的，从而 $\{\omega_s,\omega_t\}$ 是分离的。

至此我们就完成了[定理 2](#thm2) 的证明。

{% blockquote %}
**推论**：level 等于 1 的群其 Tits 锥 $\mathcal{C}$ 等于光锥的一个分支。
{% endblockquote %}

这是因为根据[定理 2](#thm2)，所有的基本权 $\{\omega_s\}$ 都不是实的且两两之间的内积小于 0，所以它们都属于光锥的同一个连通分支，记作 $L$，从而 $\barfd$ 作为 $\{\omega_s\}$ 的闭包也属于 $L$。$W$ 作为正交变换群保持 $L$ 不变，所以 Tits 锥 $\tc=\cup_{w\in W}w\barfd$ 也属于 $L$，再结合 [前一篇文章](/coxeter-groups-II/#有限欧氏双曲三种几何的-tits-锥) 中证明的结论，双曲的情形 Tits 锥是包含 $L$ 的，即得所证。

## Level 2 的群也是双曲的

本节我们在上一小节的结论中再进一步，证明 level 2 的群也是双曲的。需要的论证会更加繁琐一些。

<div id="thm3">
{% blockquote %}
**定理 3** (Maxwell'82 proposition 1.6)：level 等于 2 的群都是双曲的，所有的 $\{\omega_s\}_{s\in S}$ 两两分离。$\omega_s$ 是实的当且仅当 $T-\{s\}$ 的 level 等于 1，且对这样的 $\omega_s$ 有 $0<(\omega_s,\omega_s)\leq 1$。
{% endblockquote %}
</div>

证明：我们需要针对 $\Gamma$ 的顶点个数是否大于 3 分别处理。在 $\Gamma$ 只包含 3 个顶点的情形，$\Gamma$ 的 level 是 2 说明其必然有一条边的 Vinberg 标号小于 -1。不妨设 $\inn$ 的矩阵形如
$$\begin{pmatrix}1&a&b\\a&1&c\\b&c&1\end{pmatrix}.$$
其中 $a,\,b,\,c\leq0$ 且 $a < -1$。这个矩阵的行列式是
$$1 - a^2 + 2abc - b^2-c^2 = 1-a^2 + 2bc(a+1)-(b+c)^2<0.$$
考虑到矩阵的迹等于 3，所以矩阵的 Sylvester 惯性指数必然是 $(2, 1)$，从而是双曲的。

下面再处理 $\Gamma$ 包含至少 4 个顶点的情形。

和 level 1 的情形类似，如果 $\Gamma$ 不是双曲的，则我们可以取两个非零且正交的向量 $u,v$ 满足 $(u, u)<0,\,(v, v)=0$。

我们也有如下两个断言：

1. **我们断言任何满足 $(u,u)<0$ 的向量，当其表示为 $u=\sum_{s\in S}u_s\alpha_s$ 时，除去至多一个系数 $u_j$ 之外，其它的 $u_s$ 都非零且同号**。
2. **我们断言任何满足 $(v,v)=0$ 的向量，当其表示为 $v=\sum_{s\in S}v_s\alpha_s$ 时，除了断言 1 的情形之外，还有一种情形是 $\{v_s\}$ 中有两个是 0，其余的非零且同号**。

和之前一样，我们仍然记 $I_+,I_-,I_0,u_+,u_-$ 如前。

对断言 1，如果 $|I_0|\geq2$，则 $(u,u)<0$ 与 $\Gamma$ 的 level 是 2 矛盾。所以 $|I_0|\leq 1$。

1. 如果 $I_+,I_-$ 都不是空集，则 $u_+,\,u_-$ 均不为 0 且 $(u_+, u_+) < 0$ 和 $(u_-, u_-)<0$ 中至少有一个成立。不妨设 $(u_+,u_+)<0$，结合 $\Gamma$ 的 level 是 2，这要求 $|I_-\cup I_0|\leq 1$，从而只能是 $|I_-|=1,\, I_0=\emptyset$。即系数全部非 0 且恰好有一个异号。
2. 如果 $I_+,I_-$ 中有一个是空集，不妨设 $I_-=\emptyset$，我们仍然有 $|I_-\cup I_0|=|I_0|\leq1$。即系数至多有一个为 0 且其它的均同号。

总之我们证明了除去至多一个系数之外，其它的系数均非 0 且同号。断言 1 得证。

对断言 2，同样记 $I_+,I_-,I_0,v_+,v_-$ 如前。

首先 $|I_0|\leq2$ 是显然的，否则 $(v,v)=0$ 与 $\Gamma$ 的 level 是 2 和[定理 1](#thm1) 矛盾。

1. 如果 $I_0\ne\emptyset$，则 $I_+,I_-$ 中必有一个为空。否则 $|I_+\cup I_0|\geq2,\,|I_-\cup I_0|\geq2$。level 2 要求 $(v_+,v_+)\geq0,\,(v_-,v_-)\geq0$，从而 $(v_+,v_+)=(v_-, v_-)=(v_+,v_-)=0$。由于 $\Gamma$ 至少包含 4 个顶点，所以 $I_+,\,I_-$ 中必有一个包含两个或者更多的顶点。不妨设 $|I_+|\geq2$，则删除 $I_+\cup I_0$ 会至少删掉 3 个顶点，但得到的子图不是正定的，与 $\Gamma$ 的 level 等于 2 矛盾。所以系数 $\{v_s\}$ 中如果有 0 的话，则至多只有两个 0，且剩下的都同号。
3. 如果 $I_0=\emptyset$ 是空集，则要么 $I_+,I_-$ 中有一个也是空集，从而所有的系数都非 0 且同号；要么 $v_+,\,v_-$ 均不为 0。这时 $\Gamma$ 连通说明 $(v_+,v_-)>0$，所以 $(v_+,v_+) < 0$ 和 $(v_-, v_-)<0$ 中至少有一个成立。不妨设 $(v_+,v_+)<0$，则 level 2 要求 $|I_-|\leq1$，即 $\{v_s\}$ 均非零且恰有一个元素与其它元素异号。

至此断言 2 得证。

现在由于 $u$ 的系数 $\{u_s\}$ 中至多只有一个是 0，$v$ 的系数 $\{v_s\}$ 中至多只有两个是 0，而 $|\Gamma|\geq4$，所以存在下标 $i$ 使得 $u_i,\,v_i$ 均不为 0。记 $a=v_i/u_i\ne 0$。于是 $u'=au-v$ 仍然满足 $u'$ 与 $v$ 正交和 $u'\bullet u'<0$，但是它的下标 $i$ 的系数 $u'_i=0$，所以我们不妨一开始就取 $u$ 为 $u'$，于是 $u$ 有一个 $u_i=0$，其它系数都非 0 且同号，不妨假设这些非零系数都大于 0。

由于 $\{v_s\}$ 中至多只有两个为 0，而 $|\Gamma|\geq4$，所以 $\{v_j,\,j\ne i\}$ 中至少还有一个非零。

+ 如果 $\{v_j,\,j\ne i\}$ 中仅有一个非零，则这时必有 $|\Gamma|=4$ 且 $v$ 形如 $v=v_i\alpha_i + v_j\alpha_j$。$\{\alpha_i,\alpha_j\}$ 张成的二维平面是有限/或者仿射的，但是由于此平面包含 $(v,v)=0$，所以是仿射的，从而 $(\alpha_i,\alpha_j)=-1$。我们可以不妨把 $v$ 取为 $v=\alpha_i+\alpha_j$。

    此外 $u_i=0$ 说明 $u$ 形如 $u=u_j\alpha_j+u_k\alpha_k+u_m\alpha_m$。
    由 $(u,v)=0$ 以及 $(\alpha_j,v)=0$ 有
    $$(u, v)=(u_j\alpha_j+u_k\alpha_k+u_m\alpha_m, v)=(u_k\alpha_k+u_m\alpha_m, \alpha_i+\alpha_j)=0,$$
    由于 $\{\alpha_k,\alpha_m\}$ 和 $\{\alpha_i,\alpha_j\}$ 之间的内积都小于等于 0，而 $u_k,u_m$ 大于 0，这说明
    $$(\alpha_k,\alpha_i) = (\alpha_k,\alpha_j) =(\alpha_m, \alpha_i) =(\alpha_m,\alpha_j)=0.$$
    即顶点 $\{i, j\}$ 与 $\{k,m\}=\Gamma-\{i,j\}$ 是不连通的，与 $\Gamma$ 连通矛盾。

+ 如果 $\{v_j,\,j\ne i\}$ 包含两个下标 $j,k$，即 $v_j/u_j\ne0,\,v_k/u_k\ne0$，由于 $v_i\ne0$，通过选择 $v$ 或者 $-v$ 可以不妨设 $v_i<0$，并不妨设 $v_j/u_j\leq v_k/u_k$。记 $a=v_j/u_j$，则 $u'=au-v$ 满足 $(u',u')<0$，但是 $u'_i=-v_i>0$，$u'_j=0$，$u'_k\leq 0$，这与上面断言中 $u'$ 的系数除去至多一个例外，剩下的均非零且同号矛盾。

至此我们证明了当 $\Gamma$ 的 level 等于 2 时是双曲的。

我们接下来证明所有的基本权 $\{\omega_s\}$ 是两两分离的。

仍然利用恒等式

$$\begin{align*}
\omega_s &= (\omega_s,\omega_s)\alpha_s + \sum_{t\ne s} (\omega_s,\omega_t)\alpha_t,\\
1 &= (\omega_s,\omega_s) + \sum_{t\ne s} (\omega_s,\omega_t)(\alpha_t,\alpha_s).\end{align*}$$

+ 如果 $(\omega_s,\omega_s)\leq0$，则根据第二个等式，$\{(\omega_s,\omega_t)\}_{t\ne s}$ 中必然至少有一个严格小于 0，从而 $\{(\omega_s,\omega_t)\}_{t\ne s}$ 中至多有一个严格大于 0。这是因为根据前面的断言，在 $\omega_s$ 的所有的系数中不可能出现两个大于 0，一个严格小于 0，还有一个 $\leq0$ 的情况。但我们将证明大于 0 也不可能。否则不妨设 $k\ne s$ 使得 $(\omega_s,\omega_k)>0$。在第一个等式两边用 $\alpha_k$ 内积得到
$$0=(\omega_s,\omega_s)(\alpha_s,\alpha_k) +\sum_{t\ne s,k} (\omega_s,\omega_t)(\alpha_t,\alpha_k) + (\omega_s,\omega_k).$$
上面的和项前两个都非负，最后一个大于 0，矛盾。

+ 如果 $(\omega_s,\omega_s)>0$，显然这当且仅当其正交补 $U=\omega_s^\bot={\rm span}\{\alpha_t,\,t\ne s\}$ 是双曲的，即 $\Gamma-\{s\}$ 的 level 是 1。考虑 $\alpha_s$ 在 $U$ 上的正交投影 $\alpha_s'=\alpha_s-\omega_s/(\omega_s,\omega_s)$。$\alpha_s'$ 满足对任何 $t\ne s$ 有 $(\alpha_s',\alpha_t)\leq0$，从而 $-\alpha_s'$ 属于 $\Gamma-\{s\}$ 的基本区域的闭包，即 $-\alpha_s'\in\cl{\{\omega_t,t\ne s\}}$。而[定理 2](#thm2) 及其推论已经证明了 $\Gamma-\{s\}$ 是双曲的，其基本区域的闭包 $\cl{\{\omega_t,t\ne s\}}$ 属于光锥的一个连通分支，从而 $(\alpha_s',\alpha_s')= 1-(\omega_s,\omega_s)^{-1}\leq0$，即 $0<(\omega_s,\omega_s)\leq1$。又由于 $-\alpha_s'$ 和所有 $\{\omega_t,t\ne s\}$ 属于光锥的同一连通分支，所以对任何 $t\ne s$ 有 $(-\alpha_s',\omega_t)=(\omega_s,\omega_t)/(\omega_s,\omega_s)\leq0$，即 $(\omega_s,\omega_t)\leq 0$，于是所有的 $\{(\omega_s,\omega_t)\}_{t\ne s}$ 都非正。

> 注：我们需要考虑 $\alpha_s$ 的投影 $\alpha_s'$ 是因为 $\alpha_s$ 不属于 ${\rm span}\{\alpha_t,\,t\ne s\}$，无法根据 $(\alpha_s,\alpha_t)\leq0$ 得出 $\alpha_s$ 属于 $\Gamma-\{s\}$ 的基本区域的闭包。

总之我们证明了不论 $(\omega_s,\omega_s)$ 的符号如何，它与其它的基本权的内积 $(\omega_s, \omega_t)$ 都非正。

又因为对任何 $s,t$，$\Gamma-\{s,t\}$ 是有限或者仿射的，所以其正交补，即 $\{\omega_s,\omega_t\}$ 张成的二维子空间不是正定的，即 $\{\omega_s\}$ 之间是两两分离的。

## level = 1, 2 等价于双曲和分离

{% blockquote %}
**定理 4** (Maxwell'82 theorem 1.9)：下面两点是等价的：

1. $\Gamma$ 的 level 等于 1 或 2；
2. $\Gamma$ 是双曲的，且任何两个权都互相分离。
{% endblockquote %}

证明：

$1\Rightarrow 2$：只要再证明对任何 $w\in W$，以及两个基本权 $\omega_i,\,\omega_j$，如果有 $\omega_i\ne w(\omega_j)$，则 $(\omega_i,w(\omega_j))\leq0$，并且二维子空间 $\{\omega_i,w(\omega_j)\}$ 不是正定的。

对长度 $l(w)$ 归纳：$l(w)=0$ 的情形在[定理 2](#thm2) 和[定理 3](#thm3) 中已经证明。下面假设 $l(w)>0$，且结论对所有长度 $<l(w)$ 的群元素成立。

1. 如果存在 $k\ne i$ 使得 $l(s_kw)<l(w)$，则由 $s_k(\omega_i)=\omega_i$ 有 $\omega_i=s_k(\omega_i)\ne s_kw(\omega_j)$，由归纳假设 $\{\omega_i,s_k(\omega_j)\}$ 是分离的，从而 $\{\omega_i,\omega_j\}$ 作为 $\{\omega_i,s_k(\omega_j)\}$ 的正交变换也是分离的。

2. 如果对任何 $k\ne i$ 都有 $l(s_kw)>l(w)$，则 $w$ 的任一既约表示必然以 $s_i$ 开头，即 $w$ 形如 $w=s_iw'$ 且 $l(w)>l(w')$。从而
    $$(\omega_i,w(\omega_j))=(s_i(\omega_i), w'(\omega_j))=(\omega_i, w'(\omega_j))-2(\alpha_i,w'(\omega_j)).$$

    + 如果 $\omega_i\ne w'(\omega_j)$，则由归纳假设上面第一项 $(\omega_i, w'(\omega_j))\leq0$。第二项由于 $l(s_iw')>l(w')$ 所以 $w'^{-1}\alpha_i\in\Phi^+$，从而 $(w'^{-1}\alpha_i, \omega_j)\geq0$，即 $(\alpha_i, w'(\omega_j))\geq0$，所以 $(\omega_i,w(\omega_j))\leq0$ 成立。
    + 如果 $\omega_i=w'(\omega_j)$，则 $s_i(\omega_i)=w(\omega_j)$，于是
      $$(\omega_i, w(\omega_j))=(\omega_i, s_i(\omega_i))=(\omega_i,\omega_i-2\alpha_i)=(\omega_i, \omega_i)-2 \leq 0.$$
      其中最后一个不等号是利用了[定理 3](#thm3) 的结论。

    为了证明 $\text{span}\{\omega_i,w(\omega_j)\}$ 不是正定的，用反证法。我们先插入一个简单的线性代数引理：

    > **引理**：在一个内积空间中，设 $x$ 是一个向量，$U$ 是一个子空间，$v$ 是 $x$ 在 $U$ 上的投影分量，$U_1$ 是 $v$ 在 $U$ 中的正交补，则 $U_1=x^\bot\cap U$。
    >

    引理的证明很简单，我这里省略。

    回到反证法。如果二维子空间 ${\rm span}\{\omega_i,w(\omega_j)\}$ 是正定的，设 $v$ 是 $w(\omega_j)$ 在
    $$U=\omega_i^\bot={\rm span}\{\alpha_k,\,k\ne i\}$$
    上的投影分量，$U_1$ 是 $v$ 在 $U$ 中的正交补，则
    $$U_1=w(\omega_j)^\bot\cap U=w(\omega_j)^\bot\cap\omega_i^\bot=\{\omega_i,w(\omega_j)\}^\bot$$
    是一个双曲子空间，所以 $v\in U_1^\bot$ 是 space-like 的：$(v,v)>0$。然而对任何 $k\ne i$，由于 $\alpha_k\in\omega_i^\bot$ 所以 $(v,\alpha_k) = (w(\omega_j),\alpha_k)=(\omega_j, w^{-1}\alpha_k)$。而 $l(s_kw)>l(w)$ 说明 $w^{-1}\alpha_k\in\Phi^+$，所以 $(\omega_j, w^{-1}\alpha_k)\geq0$，即 $(v,\alpha_k)\geq0$。这对任何 $k\ne i$ 都成立所以 $v$ 属于 $\Gamma-\{i\}$ 的基本区域的闭包。但是 $\omega_i$ 是实的，所以 $\Gamma-\{i\}$ 的 level 是 1，它的基本区域的闭包都包含在光锥的一个连通分支中，从而必须有 $(v, v)\leq0$，矛盾。

$2\Rightarrow 1$：由于内积 $\inn$ 是双曲的，而子空间 $\text{span}\{\omega_i,\omega_j\}$ 不是正定的，所以正交补是正定或者半正定的。于是 $\Gamma-\{i,j\}$ 是有限或者仿射的，从而 $\Gamma$ 的 level 等于 1 或 2。

# 基本同构

这一节对应的是 Maxwell'82 的第 2 部分，我们将介绍，$\R^n$ 中的球和超平面可以表示为 $n+1$ 维射影空间 $\mathrm{P}(\R^{n+1,1})=\R\mathrm{P}^{n+1}$ 中 space-like 的点，并且 $\R^n$ 中关于球面的反演和超平面的反射可以表示为 $\mathrm{P}(\R^{n+1,1})$ 中的反射变换。这里的叙述和 Maxwell'82 本质是一样的，但稍有不同。


## 将 $\R^n$ 和 $S^{n}$ 提升到 $\R^{n+1, 1}$ 中

我们先从 Lorentz 空间 $\R^{n+1, 1}$ 说起。设 $n$ 是正整数，$e_1,e_2,\ldots,e_{n+2}$ 是 $\R^{n+2}$ 的一组基，在 $\R^{n+2}$ 上定义内积 $\inn$ 如下：对任何 $i\ne j$ 有 $(e_i,e_j)=0$，对 $1\leq i\leq n+1$ 有 $(e_i,e_i)=1$，以及 $(e_{n+2},e_{n+2})=-1$。即这组基下内积的 Gram 矩阵为
$$\begin{pmatrix}I_{n+1} &\\ & -1\end{pmatrix}.$$
此内积的符号为 $(n+1,1)$，在此内积下 $\R^{n+2}$ 成为 Lorentz 空间 $\R^{n+1,1}$。

$e_1,e_2,\ldots,e_{n+2}$ 是一组标准正交基，但是在处理球面时，另一组基更方便。定义
$$e_0=\frac{1}{2}(e_{n+2}-e_{n+1}),\quad e_\infty=\frac{1}{2}(e_{n+2}+e_{n+1}).$$
$\{e_1,\ldots,e_n,e_0,e_\infty\}$ 也构成 $\R^{n+1,1}$ 的一组基，$\inn{\,}{}$ 在这组基下的 Gram 矩阵为
$$\begin{pmatrix}I_n&&\\&0& -\frac{1}{2}\\&-\frac{1}{2}&0\end{pmatrix}.$$
坐标变换公式为（假设 $x\in\R^n$ 来自前 $n$ 个分量）
$$x+x_{n+1}e_{n+1}+x_{n+2}e_{n+2}= x+(x_{n+2}-x_{n+1})e_0+(x_{n+2}+x_{n+1})e_\infty.$$

对 $v\in\R^{n+1,1}$，我们约定用 $[v]$ 表示 $v$ 在射影空间 $\mathrm{P}(\R^{n+1,1})$ 中的等价类。

{% blockquote %}
**定义**：定义光锥 (light cone/null cone) 为
$$\mathbb{L}^{n+1} = \{v\in \mathbb{R}^{n+1, 1}\mid(v,v)=0\}.$$
以及
$$\mathcal{Q}=\mathrm{P}(\mathbb{L}^{n+1})=\{[v]\in\mathrm{P}(\mathbb{R}^{n+1,1})\mid( v,v)=0\}$$
$\mathcal{Q}$ 可以看作是 $\mathbb{L}^{n+1}$ 中所有直线组成的集合。
{% endblockquote %}

我们知道 $\overline{\R^n}=\R^n\cup\{\infty\}$ 和单位球 $S^n=\{x_1^2+x_2^2+\cdots+x_{n+1}^2=1\}\subset\R^{n+1}$ 在球极投影下是一一对应的。实际上它们都可以提升为光锥中的点，如下图所示：

（原图出自 [conformalgeometricalgebra](http://conformalgeometricalgebra.org/wiki/index.php?title=Main_Page)，我拿来在 inkscape 里面做了一些修改）

<img style="margin:0px auto;display:block" width=500 src="/images/coxeter-groups/Horosphere.svg"/>

$S^n$ 对应的是图中的红圈，它是光锥 (null cone) 与超平面 $x_{n+2}=1$ 相交的截线；$\R^n$ 对应的是图中的 horosphere，它是光锥和超平面 $x_{n+2}-x_{n+1}=1$ 相交的截线；$\infty$ 对应 $e_\infty$。

我们来验证这一点。

记 $\|x\|$ 为向量 $x$ 的 Euclidean 范数，则
$$x\in S_n\Leftrightarrow\|x\|=1\Leftrightarrow((x,1),(x,1))=0\Leftrightarrow(x,1)\in\L^{n+1}.$$
所以 $S^n$ 确实可以等同于截线 $Q_1^n=\{v\in\L^{n+1}\mid v_{n+2}=1\}$，对应由映射
$$S^n\to\Q_1^n: x\to x + e_{n+2}$$
给出。由于 $\Q$ 中每个元素在 $Q_1^n$ 中有唯一代表元，所以 $\Q$ 可以写成 $\Q=\{[v]\mid v\in Q_1^n\}$。这是 $\Q$ 的第一种参数化表示。

另一方面我们可以把 $\R^n$ 等同于截线
$$Q_0^n=\{v\in\L^{n+1}\mid (v,e_\infty)=-1/2\}=\{v\in\L^{n+1}\mid v_{n+2}-v_{n+1}=1\},$$
此对应由映射
$$\R^n\to Q_0^n: x\to x + e_0 + \|x\|^2e_\infty$$
给出。$\Q$ 上每个 $e_0$ 分量非零的点都具有如上的形式，而 $\Q$ 上 $e_0$ 分量为 0 的点只有 $[e_\infty]$，将 $\infty$ 对应到 $e_\infty$，我们就得到了 $\overline{\R^n}$ 和 $\Q$ 之间的一一对应。于是 $\Q$ 也可以写成
$$\Q=\begin{cases}[x+e_0+\|x\|^2e_\infty], &x\in\R^n\\
 [e_\infty],&x=\infty\end{cases}$$
为了方便记 $\cl{Q_0^n}=Q_0^n\cup\{e_\infty\}$，则上面的式子可以写成 $\Q =  \{[v]\mid v\in\cl{Q_0^n}\}$，此即为 $\Q$ 的第二种参数化表示。

$\Q$ 的这两种参数化表示可以通过球极投影联系起来：设 $x\in\R^n$ 和 $y\in S^n$ 对应的是 $\Q$ 上同一点，即
$$[x + e_0 + \|x\|^2e_\infty] = [y + e_{n+2}].$$
记
$$y=\widetilde{y}+y_{n+1}e_{n+1} + e_{n+2}=\widetilde{y} +(1-y_{n+1})e_0+(1+y_{n+1})e_\infty,$$
其中 $\widetilde{y}\in\R^n$，则存在非零实数 $\lambda$ 满足
$$x + e_0 + \|x\|^2e_\infty =\lambda\left(\widetilde{y}+(1-y_{n+1})e_0+(1+y_{n+1})e_\infty\right).$$
比较两边 $e_0$ 的系数即得 $\lambda=\frac{1}{1-y_{n+1}}$，于是
$$x=(x_1,\ldots,x_n)=\lambda\widetilde{y}=\frac{\widetilde{y}}{1-y_{n+1}}=\frac{(y_1,\ldots,y_n)}{1-y_{n+1}}.$$
这正是以 $e_{n+1}$ 为极点的球极投影。

当 $x=\infty$ 时，$x$ 在球极投影下对应的是球面的北极点 $e_{n+1}\in S^n$，$x$ 在 $\cl{Q_0^n}$ 中对应的点是 $e_\infty$，$e_{n+1}$ 在 $Q_1^n$ 中对应的点是 $e_{n+1}+e_{n+2}=2e_\infty$，两种参数化表示下对应的点分别是 $e_\infty$ 和 ，显然 $[e_\infty]=[e_{n+1}+e_{n+2}]$。

总之 $\overline{\R^n}$ 和 $S^n$ 在球极投影下对应的点，在 $\Q$ 的两种参数化表示中对应的也是同一个点。


## 将 $\R^n$ 中的球提升到 $\R^{n+1,1}$ 中

我们知道 $\R^n$ 中的球（包含超平面）在球极投影下对应于 $S^n$ 上的圆。它们在 $\R^{n+1,1}$ 中也有对应的表示吗？下面来分析一下。

记
$$\mathcal{S}=\{v\in\R^{n+1,1}\mid( v,v)=1\}$$
是所有 space-like 的单位向量组成的集合，我们来建立 $\R^n$ 中的球/超平面和 $\mathcal{S}$ 的一一对应。

设 $C$ 是 $\R^n$ 中以 $a$ 为中心，半径为 $r\ne 0$ 的球，注意我们允许 $r$ 是负数以区分球的内部和外部，于是 $r>0$ 时 $C$ 的内部就是通常意义下满足 $\|x-a\|< r$ 的有界集合；$r<0$ 时 $C$ 的内部是满足 $\|x-a\|>|r|$ 的无界集合。对 $\R^n$ 中的球，在球极投影下它对应 $S^n$ 上的一个圆，它的内部和外部对应圆两侧的球冠，所以把 $C$ 的外部和内部统一处理是非常合理的。不难验证
$$s=\frac{a + e_0 + (\|a\|^2 - r^2)e_\infty}{r}$$
满足 $(s,s)=1$，所以 $s\in\mathcal{S}$。对 $x\in\R^n$，设 $z=x + e_0 + \|x\|^2e_\infty\in Q_0^n$ 是 $x$ 在光锥中对应的点，则
$$(z,s)=\left(x + e_0 + \|x\|^2e_\infty,\, \frac{a + e_0 + (\|a\|^2 - r^2)e_\infty}{r}\right)=\frac{r^2-\|x-a\|^2}{2r}.$$

于是 $\R^n$ 中圆 $C$ 的方程 $\|x-a\|=|r|$ 在 $\R^{n+1,1}$ 中变成了 $(z,s)=0,\, z\in Q_0^n$。

可以看到不论 $r>0$ 或是 $r<0$，$x$ 落在 $C$ 的边界或者内部当且仅当 $(z,s)\geq0$。这个内部是有界的，当且仅当 $e_\infty$ 位于 $C$ 的外部，即 $(e_\infty, s)<0$。

对 $\R^n$ 中的超平面，设其方程为 $(n,x)=d$，其中 $n$ 是超平面的单位法向量，$d\in\R$。我们将其对应到 $s=n+2de_\infty\in\mathcal{S}$。不难验证
$$(z,s)=(x + e_0 + \|x\|^2e_\infty,\, n+2de_\infty)=(x,d)-d.$$
所以 $x$ 属于超平面的正半空间当且仅当 $(z,s)\geq0$。


## 球面之间的 seperation

设 $C_1,C_2$ 是 $\R^n$ 中的两个球，球心分别为 $a_1,a_2$，半径分别为 $r_1,r_2$。设 $s_1=\frac{a_1+e_0+(\|a_1\|^2-r_1^2)e_\infty}{r_1}$，$s_2=\frac{a_2+e_0+(\|a_2\|^2-r_2^2)e_\infty}{r_2}$ 是它们在 $\R^{n+1,1}$ 中对应的点，我们称
$$(s_1,s_2)=\frac{r_1^2+r_2^2 - \|a_1-a_2\|^2}{2r_1r_2}$$
为 $C_1$ 和 $C_2$ 的 seperation。

在 $r_1,r_2$ 都大于 0 时，不难验证：

1. $C_1$ 和 $C_2$ 没有公共点当且仅当 $|(s_1,s_2)|>1$。在 $(s_1,s_2)<-1$ 时互相分离，在 $(s_1,s_2)>1$ 时一个完全包含另一个。
2. $C_1$ 和 $C_2$ 相交当且仅当 $|(s_1,s_2)|\leq1$，并且在 $(s_1,s_2)=-1$ 时两球外切，$(s_1,s_2)=1$ 时两球内切。不难验证这时 $(s_1,s_2)$ 的值就是它们球面交点处的**外法向量**夹角的余弦值。

有一点需要注意的是，如果 $C_1,C_2$ 相交，并且恰有一个是超平面，不妨设 $C_2$ 的方程为 $(x,n)=d$，则 $s_2=n + 2de_\infty$，
$$(s_1,s_2)=\frac{r_1^2+r_2^2 - \|a_1-a_2\|^2}{2r_1r_2}=\frac{(a_1,n)-d}{r_1}.$$
这时 $(s_1,s_2)$ 等于 $C_1$ 在球面交点处的外法向量和平面法向量夹角余弦的**相反数**。这是因为球面的外法向量指向的是球的外部，而 $s_1$ 指向的是球的内部。


## 关于球面的反演

设 $C$ 是 $\R^n$ 中以 $a$ 为中心，半径为 $r$ 的球，关于 $C$ 的反演变换将 $a$ 映射为 $\infty$（反之亦然），将 $x\ne a$ 映射为 $\frac{r^2}{\|x-a\|^2}(x-a) +a$。这个变换可以通过射影空间 $\mathrm{P}(\R^{n+1,1})$ 中关于 $s$ 的反射
$$\rho_s: z \to z - 2(z,s)s$$
来计算。由于 $(s,s)=1$，这是一个保持 Lorentz 内积的正交变换。我们来验证
$$\begin{align*}z-2(z,s)s&=(x+e_0+\|x\|^2e_\infty)-\frac{r^2-\|x-a\|^2}{r^2}(a + e_0 + (\|a\|^2-r^2)e_\infty)\\
&=\left(x-a+a\frac{\|x-a\|^2}{r^2}\right)+\frac{\|x-a\|^2}{r^2}e_0+\ast e_\infty\\
&\sim \left(\frac{r^2}{\|x-a\|^2}(x-a)+a \right)+ e_0 + \ast e_\infty\end{align*}$$
这里我们不用关心 $e_\infty$ 的系数，最后的 $\sim$ 表示两个向量是射影等价的，我们只要将 $e_0$ 分量归一化即可。

将另一个球关于 $C$ 作反演同样可以用反射 $\rho_s$ 来实现，步骤和上面是类似的，这里不再赘述。


# 球堆

{% blockquote %}
**定义**：我们称一个非空集合 $\mathcal{P}\subset V$ 是一个**球堆**，如果 $\mathcal{P}$ 满足：

1. 对任何 $k\in\mathcal{P}$ 有 $(k,k)=1$。
2. 对 $\mathcal{P}$ 中任何 $k\ne k'$ 有 $(k,k')\leq -1$。
{% endblockquote %}

类似 $\mathcal{P}=\{k,-k\}$ 这样的球堆是平凡的，它对应单个球的内部和外部。反之则称为非平凡的。非平凡的球堆中的点必然两两互不共线。

对任何满足 $(k,k)=1$ 的点 $k$，我们定义球帽
$$C_k = \{v\in Q_0^n\mid (v,k)\geq0\}.$$
根据上一节的讨论，$C_k$ 对应的是 $\R^n$ 中某个球的边界和内部（或者某超平面法向量指向的正半空间），这个内部可以是包含 $\infty$ 的无界区域。

对一个非平凡的球堆 $\mathcal{P}$，$-\mathcal{P}=\{-k\mid k\in\mathcal{P}\}$ 也是非平凡的球堆，而且它翻转 $\mathcal{P}$ 中每个球的内部和外部。我们将证明，$\mathcal{P}$ 和 $-\mathcal{P}$ 中必有一个可以给出 $\R^n$ 中一族两两分离或者相切的球：

{% blockquote %}
**定理 5** (Maxwell'82 proposition 3.1)：设 $\mathcal{P}$ 是 $V$ 的一个非空子集，则下面两点是等价的：

1. $\mathcal{P}$ 是一个非平凡的球堆。
2. 对 $\mathcal{P}$ 或者 $-\mathcal{P}$ 之一，其包含的任何两个球帽 $C_k$ 和 $C_{k'}$ 至多有一个公共点。
{% endblockquote %}

证明：首先注意到 $Q_0^n$ 位于光锥的上半分支，即对任何 $v,v'\in Q_0^n$ 都有 $v\sim v'$。

1 $\Rightarrow$ 2：设 $k,\,k'\in\P$ 且 $k\ne k'$，我们来证明 $C_k\cap C_{k'}$ 和 $C_{-k}\cap C_{-k'}$ 必有一个至多只包含一个点。设 $v\in C_k\cap C_{k'}$，$v'\in C_{-k}\cap C_{-k'}$，则我们有

1. $(v, k+k')\geq0$，$(v',k+k')\leq0$。
2. $(k+k',k+k')=2+2(k,k')\leq 0$。

如果 $(k+k',k+k')<0$，即 $k+k'$ 是 time-like 的，则 $v'\sim k+k'$。但是 $v\sim v'$，所以 $v\sim k+k'$，从而 $(v,k+k')<0$，矛盾。所以 $(k+k',k+k')=0$，即 $k+k'$ 是 light-like 的。进一步如果 $(v,k+k')>0$ 且 $(v',k+k')<0$，则 $v'\sim k+k'$ 但是 $v\not\sim k+k'$，这与 $v\sim v'$ 矛盾。所以 $(v,k+k')$ 和 $(v',k+k')$ 中必然有一个是 0，即 $v$ 和 $v'$ 中必有一个是 $k+k'$ 的倍数，然而 $Q_0^n$ 中与 $k+k'$ 共线的点是唯一确定的，所以 $C_k\cap C_{k'}$ 和 $C_{-k}\cap C_{-k'}$ 中必有一个至多包含一个点。

不妨设 $k_1,k_2\in\mathcal{P}$ 使得 $C_{k_1}\cap C_{k_2}$ 至多包含一个点。我们来证明 $\mathcal{P}$ 中的所有球冠两两之间至多有一个公共点。为此设 $k, k'\in\mathcal{P}$ 且 $k\ne k'$，并设 $v\in C_k\cap C_{k'}$ 是一个公共点。记 $u=v-(v, k_2)k_2$，则我们有
$$(u,u)=(v,v)-(v,k_2)^2 = -(v,k_2)^2\leq0$$
和 $(u,k_2)=0$。即 $u$ 落在 $C_{k_2}$ 边界上。由于 $C_{k_1}\cap C_{k_2}$ 至多只有一个点，所以 $u$ 落在 $C_{k_1}$ 的外部或者边界上，即
$$(u,k_1)=(v-(v,k_2)k_2, k_1)=(v, k_1-(k_1,k_2)k_2)\leq0.$$
记 $w=k_1-(k_1,k_2)k_2$，则 $w$ 满足 $(w,w)\leq0$ 和 $(v,w)\leq 0$，所以 $w\sim v$，从而 $w$ 的某个正倍数 $w'$ 属于 $H$。我们有 $(w',k)\leq 0$ 和 $(w',k')\leq0$，这两个不等式至少有一个是严格成立的，根据上一段的讨论，这必须有 $(k,k')=-1$ 并且 $v$ 是 $k+k'$ 的倍数。

2 $\Rightarrow$ 1: 内积 $(\cdot,\cdot)$ 限制在 $k,k'$ 张成的二维子空间上肯定不是正定的，否则的话 $C_k$ 和 $C_{k'}$ 会在 $H$ 的内部有交点，所以 $|(k,k')|\geq1$。如果是 $(k,k')\geq1$ 的话，则 $C_k\cap C_{-k'}$ 和 $C_{-k}\cap C_{k'}$ 二者中必有一个至多只包含一个点，不妨设为 $C_{k}\cap C_{-k'}$。但是根据已知 $C_k\cap C_{k'}$ 也至多只包含一个点，从而 $C_k$ 作为二者的并也只多只有一个点，矛盾。


# Maxwell 89


> **定理**：设 $s\in S$ 使得 $(\omega_s\bullet \omega_s)=0$，即 $X=S\backslash s$ 是 Euclidean 的，则对任何 $x\in\barfd$ 都有 $\omega_s\in\cl{\cup_{w\in W_X}wp}$。

证明：由于 $\omega_s\bullet \omega_s=0$，所以 $\omega_s = \sum_{i\ne s}(\omega_s, \omega_i)\alpha_i\in V_X$，所以 $\mathbb{R}\omega_s$ 张成了 ${\rm Rad}(V_X)$，并且标准椭圆子群 $W_X$ 保持 ${\rm Rad}(V_X)$ 不动：$w\omega_s=\omega_s$ 对任何 $w\in W_X$ 成立，从而 $W_X$ 作用在 $V_X/\mathbb{R}\omega_s$ 上，此作用给出了一个同态 $W_X\to{\rm GL}(V_X/\mathbb{R}\omega_s)$。令 $W_X'$ 为此同态的核，则对任何 $w\in W_X'$，
$$w(v + \mathbb{R}\omega_s) = v + \mathbb{R}\omega_s,\quad v\in V_X$$
即 $(w-1)v\in\mathbb{R}\omega_s$，于是 $w$ 满足 $(w-1)\alpha_i\in\mathbb{R}\omega_s$ 对任何 $i\in X$ 成立，从而 $(w-1)^2$ 在整个 $V_X$ 上恒为 0。更进一步，$w\alpha_s$ 是 $\alpha_s$ 和 $\{\alpha_i,i\in X\}$ 的线性组合，所以 $w\alpha_s-\alpha_s=(w-1)\alpha_s\in V_X$，所以 $(w-1)^2V\subset\mathbb{R}\omega_s$，$(w-1)^3V\equiv0$。

如果 $p$ 是 $\omega_s$ 的正倍数，则结论是平凡的。否则取 $w\in W_X'$ 且 $w\ne 1$，则存在 $k\in X$ 使得 $w\alpha_k\ne\alpha_k$。设 $w\alpha_k=\alpha_k+a\omega_s,\,a\ne 0$，并构造换位子 $w_1=s_kws_k^{-1}w^{-1}\in W_X'$，则 $(w_1-1)^2p=b\omega_s$，其中 $b\in\mathbb{R}$。我们来计算 $b$。

注意到 $ws_kw^{-1}=s_{w\alpha_k}$，所以
$$\begin{align*}
s_{w\alpha_k}(p)&=p - 2(p\bullet w\alpha_k)w\alpha_k\\
&=p-2(p, \alpha_k+a\omega_s)(\alpha_k+a\omega_s)\\
&=p-2(p, \alpha_k+a\omega_s)\alpha_k - c\omega_s\\
&=s_k(p) - 2a(p, \omega_s)\alpha_k - c\omega_s.
\end{align*}$$
其中 $c=2a(p, \alpha_k+a\omega_s)$ 是实数。于是
$$(w_1-1)p=s_ks_{w\alpha_k}p-p = 2a(p,\omega_s)\alpha_k - c\omega_s.$$
其中我们利用了 $s_k(\omega_s)=\omega_s$。继续由于 $(w_1-1)\omega_s=0$，所以
$$(w_1-1)^2p = 2a(p,\omega_s)(w_1-1)\alpha_k.$$
对于 $(w_1-1)\alpha_k$，我们可以应用上面对 $p$ 的计算，并利用 $(\alpha_k,\omega_s)=0$ 和 $(\alpha_k,\alpha_k)=1$，得到
$$(w_1-1)\alpha_k=2a(\alpha_k, \omega_s)\alpha_k - 2a(\alpha_k, \alpha_k+a\omega_s)\omega_s=-2a\omega_s.$$
于是 $(w_1-1)^2p=-4a^2(p,\omega_s)\omega_s$，即 $b=-4a^2(\omega_s\bullet p)$。由于 $p\in\barfd$ 是 $\{\omega_s,s\in S\}$ 的非负线性组合，以及对任何 $i\ne s$ 有 $(\omega_s,\omega_i)<0$，我们有 $\omega_s\bullet p<0$，从而 $b>0$。

最后利用 $(w_1-1)^3=0$ 我们得到对任何 $N\geq 1$ 有
$$w_1^Np=p + \binom{N}{1}(w_1-1)(p) + \binom{N}{2}b\omega_s,$$
可见 $\lim_{N\to\infty}\frac{w_1^Np}{\binom{N}{2}b} = \omega_s$，即得所证。


> **定理**：如果 $(W,S)$ 的 level 大于等于 2，则 $\cl{\mathcal{C}_r} = \cl{\mathcal{C}}$。

证明：只要证明 $\cl{\mathcal{C}_r}$ 包含那些满足 $e_k\bullet e_k\leq 0$ 的 $e_k$ 即可。若如此，则 $\cl{\mathcal{C}_r}$ 包含所有的 $\{\omega_s,s\in S\}$，再结合 $\cl{\mathcal{C}_r}$ 是 $W-$ 不变的，即得 $\cl{\mathcal{C}_r}$ 包含所有 $\{w\omega_s\mid w\in W,s\in S\}$，从而包含它们的凸包 $\cl{\mathcal{C}}$。

$e_k\bullet e_k<0$ 的情形比较容易，由于 $e_k$ 是 time-like 的，所以其正交补 $\{\alpha_s,s\in S\backslash k\}$ 是正定的，从而标准椭圆子群 $W_{S\backslash k}$ 是有限的。任取 $\omega_s$ 满足 $\omega_s\bullet \omega_s>0$ 并考虑
$$v = \sum_{w\in W_{S\backslash k}}w\omega_s,$$
显然 $v\in\cl{\mathcal{C}_r}$，并且对任何 $s\in S\backslash k$ 都有 $\lfun{\alpha_s}{v}=0$。这个线性方程组的解空间是一维的，所以 $v$ 和 $e_k$ 共线：存在 $a\in\mathbb{R}$ 使得 $v=ae_k$。两边同时与 $\alpha_k$ 作内积得到
$$a = \sum_{w\in W_{S\backslash k}}(\alpha_k\bullet w\omega_s)=\sum_{w\in W_{S\backslash k}}(w\alpha_k\bullet \omega_s).$$
对任何 $w\in W_{S\backslash k}$，$w\alpha_k$ 是 $\alpha_k$ 和一些 $\{\alpha_i,i\ne k\}$ 的线性组合，$\alpha_k$ 的系数总是 1，所以 $w\alpha_k$ 仍然是正根，所以上面求和的每一项都非负。由于 $\Gamma$ 是连通的，所以存在一条从 $k$ 到 $s$ 的路径 $k\sim i_1\sim\cdots\sim i_m\sim s$。不难验证对 $w=s_{i_m}\cdots s_{i_1}\in W_{S\backslash k}$，$w\alpha_k$ 的表达式中 $\alpha_s$ 的系数大于 0，所以 $a$ 必然严格大于 0，所以 $e_k=v/a\in\cl{\mathcal{C}_r}$。

如果 $e_k\bullet e_k=0$，则其正交补 $e_k^\bot$ 是 Euclidean 的，Sylvester 符号为 $(n-2,0)$，并且包含 $\{\alpha_s,s\in S\backslash k\}$。于是 $\Gamma\backslash k$ 是 Euclidean 的。特别地，$\Gamma\backslash k$ 由一些 Euclidean 和有限连通成分组成，并且有且恰有一个连通成分是 Euclidean 的。设 $\omega_s$ 满足 $\omega_s\bullet \omega_s>0$，我们需要讨论两种情况：

1. 如果 $\omega_s$ 属于某个有限型的连通成分 $Y$，类似上面的讨论，$v = \sum_{w\in W_Y}w\omega_s$ 满足对任何 $t\in k$ 都有 $\lfun{\alpha_t}{v}=0$，从而等于 $\omega_s$ 乘以一个正实数，从而属于 $\cl{\mathcal{C}_r}$。

2. 如果 $\omega_s$ 属于某个 Euclidean 型的连通成分 $X$，设 $Y=S\backslash(X\cup\{k\})$ 是 $\Gamma\backslash k$ 的除 $X$ 以外的连通成分的并，则 $X$ 和 $Y$ 互不连通，从而
$$e_k = (e_k\bullet e_k)\alpha_k + \sum_{t\ne k} (e_k\bullet \omega_t)\alpha_t=\sum_{t\in X} (e_k\bullet \omega_t)\alpha_t + \sum_{t\in Y} (e_k\bullet \omega_t)\alpha_t=e_k'+e_k''.$$
并且 $e_k'$ 和 $e_k''$ 是正交的。于是
$$e_k'\bullet e_k' + e_k''\bullet e_k'' = e_k\bullet e_k=0.$$
由于 $e_k'\in V_X$ 来自 Euclidean 型，$e_k''\in V_Y$ 来自有限型，所以只能是 $e_k'\bullet e_k'= 0$ 并且 $e_k''=0$，从而 $e_k=e_k'\in X$。于是 $e_k$ 张成了 ${\rm Rad}(V_X)$，从而它表示为 $\{\alpha_i,i\in X\}$ 的线性组合时所有的系数 $(e_k,\omega_i)$ 系数都是非零且同号的。我们断言它们都小于 0。实际上由
$$e_k=\sum_{t\in X} (e_k\bullet \omega_t)\alpha_t$$
两边同时用 $\alpha_k$ 作内积有
$$1=e_k\bullet\alpha_k=\sum_{t\in X} (e_k\bullet \omega_t)(\alpha_t\bullet\alpha_k).$$
由于 $\alpha_t\bullet\alpha_k\leq 0$，所以必须所有 $e_k\bullet \omega_t<0$。特别地，$e_k\bullet \omega_s<0$。利用前面的定理，我们得到
$$e_k\in\overline{\bigcup_{w\in W_x}w\omega_s}\subset\cl{\mathcal{C}_r}.$$

> 定理：$\mathcal{C}_r$ 是堆积当且仅当 $\Gamma$ 的 level 是 2。并且在 level 2 时 $\mathcal{C}_r$ 还是极大堆积。

证明：若 $\Gamma$ 的 level 是 2，则根据前面的定理，$\mathcal{C}_r$ 中的两两分离，将 $\mathcal{C}_r$ 中的向量单位化，则这些单位化后的权仍然两两分离，并且任何两个权张成的子空间都不是正定的，所以它们两两之间的内积 $\leq -1$。所以 $\mathcal{C}_r$ 确实给出一个堆积。如果存在某个圆与任何 $\mathcal{C}_r$ 中的圆都不相交/相切的话，则这个圆对应于一个单位向量 $(k,k)=1$ 并且 $(k,x)\leq 0$ 对任何 $x\in\mathcal{C}_r$ 成立。由于 $\cl{\mathcal{C}_r}=\cl{\tc}$，这意味着 $(k,y)\leq0$ 对任何 $y\in\tc$ 成立。于是 $(k,k)\leq0$，矛盾。这就证明了 level 2 时 $\mathcal{C}_r$ 是极大堆积。

反之若 $W$ 是双曲的，并且 $\mathcal{C}_r$ 是一个堆积，那么由于实权之间两两分离，而一个非实权和其它任何权张成的子空间当然不可能是正定的，所以也是分离的，所以 $\Gamma$ 的 level 只能是 2。



[^1]: 这是 Coxeter 群中的一个熟知结论：如果 Coxeter 群 $(W,S)$ 的 Coxeter 图 $\Gamma$ 是连通的，且 Cartan 矩阵是半正定的，则 Cartan 矩阵的任何余子式都是正定的，即从 $\Gamma$ 中删除若干顶点后得到的是有限 Coxeter 群。见 Humphreys 的 "Reflection groups and Coxeter groups" 2.6 小节。