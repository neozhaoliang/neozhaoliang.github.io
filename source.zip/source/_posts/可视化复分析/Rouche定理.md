---
title: "遛狗中的数学：曲线的环绕数、Rouché 定理和开映射定理"
categories: [可视化复分析]
tags:
  - Shadertoy
  - Visual complex analysis
  - Winding number
  - Argument principle
  - Rouché's theorem
  - Analytic functions
date: 2021-09-011
url: "Rouché-theorem-winding-number"
---
我写了一个 [Shadertoy 小动画](https://www.shadertoy.com/view/fdK3RD)，演示 Needham 的《Visual complex analysis》一书中第七章 "Winding numbers and topology" 中的结论：

<!--more-->

{% blockquote %}
一个人和他的狗在公园里绕着一棵树散步，人和狗各自走的路径都是闭曲线，即经过一段时间后都会回到起点。如果人把狗绳抓的紧一些，使得整个过程中狗**无法接触**到树，则结束后人和狗绕着树走的圈数是一样的，这就是下面这个动画演示的：(**树的位置是原点，用一个表盘标记**)

<object data="/code/rouche.svg"></object>

{% endblockquote %}

对应的数学结论是：两条闭曲线 $\gamma_1,\gamma_2$ 如果都不经过原点，且 $\gamma_1$ 可以在不碰触到原点的前提下通过连续的形变变为 $\gamma_2$ (同伦)，则 $\gamma_1,\gamma_2$ 关于原点的环绕数相等。

其实动画中还包含了幅角原理：动画中左下角的圆周是单位圆 $S^1:\{z\in\mathbb{C}:|z|=1\}$，动画右边的两条路径分别是 $S^1$ 在两个解析函数 $f,g$ 下的像，这里的 $f$ 我取的形如
$$f(z) =\frac{z-a}{1-\overline{a}z}\frac{z-b}{1-\overline{b}z}\frac{z-c}{1-\overline{c}z} (z-2-2i),\quad a,b,c\in\mathbb{D}.$$
于是 $f(z)$ 在单位圆 $\mathbb{D}:\{z\in\mathbb{C}:|z|<1\}$ 的内部有 3 个根 (我用红点标出来了)，在边界 $S^1$ 上不为 0，在单位圆外部有一个根 (图中没有画)。$f(z)$ 的前三个因子构成一个 Blaschke 乘积，这是一个多对一的映射，它把圆盘 $\mathbb{D}$ 的内部仍然映射为内部，把边界 $S^1$ 仍然映射为 $S^1$，于是对任何 $z\in S^1$ 有
$$|f(z)| = |z - 2 - 2i| \geq 2\sqrt{2} - 1,\quad z\in S^1.$$
所以如果绳子 $l(z)$ 满足 $|l(S^1)| < 2\sqrt{2}-1$，则狗走的路径 $g(S^1)=f(S^1)+l(S^1)$ 就不可能接触到原点。我这里取了 $l(z) = cz$，其中 $c$ 是一个小于 $2\sqrt{2}-1$ 的正实数。 

根据[幅角原理](https://en.wikipedia.org/wiki/Argument_principle)，$f(S^1)$ 和 $g(S^1)$ 关于原点的环绕数等于它们在 $\mathbb{D}$ 内的零点个数，于是我们知道 $g(z)$ 也必然在 $\mathbb{D}$ 内有三个零点。这就是 Rouché 定理的结论。


Rouché 定理说的是两条曲线关于一个点的环绕数相等的结论。它可以稍微改动一下变成一条曲线关于两个点的环绕数：

> 设 $\gamma$ 是一条简单闭曲线，内部围的区域为 $\Omega$，$f(z)$ 是一个非常数的解析函数。假设有两棵树分别位于 $w_0,\,w_1$ 两点，且人行走的路线 $f(\gamma)$ 到 $w_0$ 的距离始终大于两棵树之间的距离：即对任何 $z\in\gamma$ 有 $|f(z)-w_0| > |w_0-w_1|$ 成立，则 $f(\gamma)$ 关于 $w_0,w_1$ 的环绕数相等，从而 $w_0,w_1$ 在 $\gamma$ 内部的原像个数相同：$\sharp\{z\in \Omega: f(z)=w_0\} = \sharp\{z\in \Omega: f(z)=w_1\}$。

这是因为将 $f(\gamma)$ 和 $w_1$ 同时平移 $w_0-w_1$ 不改变环绕数，所以 $g(\gamma)=f(\gamma)+(w_0-w_1)$ 关于 $w_0$ 的环绕数等于 $f(\gamma)$ 关于 $w_1$ 的环绕数。而已知绳子的长度 $|w_0-w_1|$ 小于 $f(z)$ 到 $w_0$ 的距离，所以 $g(\gamma)$ 和 $f(\gamma)$ 关于 $w_0$ 有相同的环绕数，从而它们在 $\Omega$ 内关于 $w_0$ 的原像个数相同，此即为所证。
 
由此我们不难得出复分析中的[开映射定理](https://en.wikipedia.org/wiki/Open_mapping_theorem_(complex_analysis))：

> **定理**：如果 $U\subseteq\mathbb{C}$ 是开集，$f:U\to\mathbb{C}$ 是**非常数**的解析函数，则 $f(U)$ 也是开集。

我把这个证明留给你 (欢迎在评论区写出你的答案)。