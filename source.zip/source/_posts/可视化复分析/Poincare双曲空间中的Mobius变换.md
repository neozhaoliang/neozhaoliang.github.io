---
title: "Möbius 变换的分类与 Poincaré 双曲空间的等距"
date: 2022-03-22
tags:
  - Complex analysis
  - Python
  - Visual Complex Analysis
  - Hyperbolic space
  - Möbius transformation
  - Circle inversion
  - Poincaré disk model
categories: [可视化复分析]
url: "mobius-poincare"
---
\newcommand{\tr}[1]{\mathrm{tr}(#1)}

这几天因为疫情居家观察难得多出点时间 (不用健步挤地铁)，可以写点小文章。我之前写过一篇介绍 [Möbius 变换分类的文章](/mobius-cn)，今天继续那里的讨论，介绍 Möbius 变换 $M$ 作为 Poincaré 双曲空圆盘 $\mathbb{H}$ 上的等距的两种构造方法：

1. 指定 $M$ 的不动点的位置，不动点的位置就可以决定变换的类型。
2. 指定两个反射镜面的位置：取 $\mathbb{H}$ 中的两条测地线作为镜面，则关于这两个镜面的反演变换的复合变换就是一个 Möbius 变换。镜面之间的关系也可以决定变换的类型。

这两种方法分别对应在 $M$ 作用下保持不变的两个圆族。

本文的插图使用 [matplotlib](https://matplotlib.org/) 绘制，代码在 [Github](https://github.com/neozhaoliang/pywonderland/tree/master/src/mobius) 上。

<!--more-->

{% blockquote %}
记号约定：

+ $\mathbb{H}$ 为二维 Poincaré 双曲圆盘。
+ $M$ 为一个 Möbius 变换。
+ $S^1$ 为单位圆周 $|z|=1$。
{% endblockquote %}


# 用不动点构造双曲等距

在复分析课程中，我们学过 $\mathbb{H}$ 的保持定向的等距同构是 Möbius 群的一个子群，其中元素具有如下的表示形式：
$$M(z) = \mathrm{e}^{i\theta}\frac{z - a}{1-\overline{a}z},\quad \theta\in\mathbb{R},\, |a|<1.$$
可见 $M$ 的迹 $\tr{M}=\mathrm{e}^{i\theta}+1$ 总是满足 $0\leq|\tr{M}|\leq2$，所以 $M$ 不可能是斜航型的 (loxodromic)，从而 $\mathbb{H}$ 的保持等向的等距只能是椭圆、抛物、双曲三种。

这一点也可以从圆族上看出来：$\mathbb{H}$ 的任何等距变换必然保持 $S^1$ 不变，但斜航型的变换没有不变圆，所以不可能是 $\mathbb{H}$ 上的等距变换。


下面分别介绍这三种情形。


## 椭圆型

椭圆型变换共轭于复平面上的旋转 $z\to\mathrm{e}^{i\theta}z$，它们总是有两个不动点。如果 $M$ 是 $\mathbb{H}$ 上的椭圆型等距，则其两个不动点 $p_1,\,p_2$ 必然一个在单位圆内，一个在单位圆外，且它们关于单位圆互为反演点。设 $p_1$ 位于单位圆内，则 $M$ 在 $\mathbb{H}$ 上的作用是一个绕着 $p_1$ 的旋转：

<img style="margin:0px auto;display:block" width=400 src="/images/mobius/elliptic.svg"/>

图中画出了两族圆：

1. 第一族圆是彩色的，它们在双曲度量下的中心都是 $p_1$，$M$ 作用在它们上面保持每个圆不变，同时将圆上的每个点绕着 $p_1$ 旋转。
2. 第二族圆用虚线标注，这些圆都和第一族圆正交、同时经过 $p_1$ 和 $p_2$，并且都与单位圆正交。$M$ 作用在这些圆上会把一个圆变成同族中的另一个。

双曲空间中的圆也是欧式空间中的圆，但是它们的圆心未必重合。一个 $\mathbb{H}$ 中的圆越靠近边界，它的双曲度量下的圆心也会被“吸引”到靠近边界的位置。


## 抛物型

抛物型变换共轭于复平面上的平移 $z\to z+1$，它们总是只有一个不动点。如果 $M$ 是 $\mathbb{H}$ 上的抛物型等距，则其唯一的不动点 $p$ 必然位于单位圆周 $S^1$ 上，$M$ 在 $\mathbb{H}$ 上的作用是一个双曲空间中的平移：

<img style="margin:0px auto;display:block" width=400 src="/images/mobius/parabolic.svg"/>

图中也画出了两族圆：

1. 第一族圆是彩色的，它们都和 $S^1$ 在 $p$ 点处相切。$M$ 作用在它们上面保持每个圆不变，同时将圆上的每个点沿着测地线向着 $p$ 移动。这些圆叫做 horocycle，它们在双曲度量下的圆心是 $p$。
2. 第二族圆用虚线标注，这些圆都和第一族圆正交、互相之间也在 $p$ 点相切，并且都与单位圆正交。$M$ 作用在这些圆上会把一个圆变成同族中的另一个。


## 双曲型

双曲型变换共轭于复平面上的缩放 $z\to cz,\,c\in\mathbb{R}^+$，它们总是有两个不动点。如果 $M$ 是 $\mathbb{H}$ 上的双曲型等距，则其两个不动点 $p_1,p_2$ 必然都位于单位圆周 $S^1$ 上。$M$ 在 $\mathbb{H}$ 上的作用以其中一个为源点，另一个为汇点：

<img style="margin:0px auto;display:block" width=400 src="/images/mobius/hyperbolic.svg"/>

图中的两族圆中，

1. 第一族圆是彩色的，它们同时经过 $p_1$ 和 $p_2$，$M$ 作用在它们上面保持每个圆不变，同时将圆上的每个点沿着圆给出的测地线从源点移动到汇点。
2. 第二族圆用虚线标注，这些圆都和第一族圆正交、$p_1$ 和 $p_2$ 关于它们中的每一个都互为反演点，并且都与单位圆正交。$M$ 作用在这些圆上会把一个圆变成同族中的另一个。


# 用反演变换的复合构造双曲等距

在上面的三张图中，彩色的圆对应的是 $\mathbb{H}$ 中的点在 $M$ 作用下的轨迹，它们都是测地线。我似乎有意冷落了虚线的圆族，把它们画的很不起眼。其实通过它们的反演变换也可以给出 $M$ 的构造：

|     |     |     |
|:---:|:---:|:---:|
| 椭圆型 | 抛物型 | 双曲型 |
|<img src="/images/mobius/elliptic2.svg" width=180>|<img src="/images/mobius/parabolic2.svg" width=180>|<img src="/images/mobius/hyperbolic2.svg" width=180>|

+ $M$ 是椭圆型的，当且仅当它是两个在 $\mathbb{H}$ 中**相交**的圆的反演变换的复合。
+ $M$ 是抛物型的，当且仅当它是两个在 $\mathbb{H}$ 中**平行**的圆的反演变换的复合。这里平行的意思是两圆相切，且切点位于无穷远边界上。
+ $M$ 是双曲型的，当且仅当它是两个在 $\mathbb{H}$ 中**超平行**的圆的反演变换的复合。这里超平行的意思是它们要么不相交，要么一个完全位于另一个的内部。

这些背后的原因都不难理解：

+ 椭圆型变换共轭于绕原点的角度为 $\theta$ 的旋转，此旋转是两个夹角为 $\theta/2$ 的直线反射的复合。**这两个直线可以选取为 Poincaré 空间中过原点的两直线**。
+ 抛物型变换共轭于平移 $T:z\to z + 1$，$T$ 是上半双曲空间模型中的等距，它可以表示为关于两平行直线 $x=0$ 和 $x=1/2$ 的反射的复合。我们可以用一个从上半空间到 $\mathbb{H}$ 的等距变换把实轴变成单位圆周，并把 $\infty$ 点变到边界上的指定点 $p$。这时所有形如 $x=k$ 的直线，由于它们过原点、互相平行、与实轴正交，所以都会变成过 $p$ 点、两两相切于 $p$、且与单位圆正交的圆。在这些圆中任取两个圆，作它们反演变换的复合，给出的就是一个抛物型变换。
+ 双曲型变换共轭于缩放 $S:z\to cz,\,c>0$，$S$ 是**上半空间模型**中两个同心圆 $|z|=1$ 和 $|z|=\sqrt{c}$ 的反演变换的复合。$S$ 的两个不动点是原点和无穷远点，它们关于这两个同心圆互为反演点。同理我们可以用一个从上半空间到 $\mathbb{H}$ 的等距变换把实轴变成单位圆，并把原点和无穷远点分别映射到单位圆周上指定的两个不动点。这两个同心圆会被映射为 $\mathbb{H}$ 中的两条测地线。关于这两条测地线的反演的复合就共轭于上半空间模型中的缩放。

{% blockquote %}
**注**：为什么两个圆的反演变换的复合是一个 Möbius 变换？对一个圆 $C$，你可以用一个 Möbius 变换 $T$ 将 $C$ 变为实直线 $\mathbb{R}^1$，关于 $\mathbb{R}^1$ 的反演就是复共轭 $\mathrm{conj}(z)=\overline{z}$，所以关于 $C$ 的反演为 $S=T^{-1}\cdot\mathrm{conj}\cdot T$，从而 $S$ 形如
$$S(z) = \frac{a\overline{z} + b}{c\overline{z}+d},\quad a,b,c,d\in\mathbb{C},\,z\in\mathbb{C}_{\infty}.$$
所以两个反演变换的复合是 Möbius 变换。
{% endblockquote %}