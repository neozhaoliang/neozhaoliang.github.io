---
title: "Coxeter element: a computational approach"
date: 2013-10-11
categories: [代数]
tags:
  - Coxeter group
  - Coxeter element
  - Coxeter plane
  - Root system
  - Cartan matrix
url: "coxeter-element"
---
虽然本文起了个英文标题，但内容完全是中文的，原因是我没有想到合适的能概括内容的中文标题。

如果你对李代数有所了解的话，相信很大概率你会见过下面的图案：(参考维基百科的 [Lie algebra 词条](https://en.wikipedia.org/wiki/Lie_algebra))

<img style="margin:0px auto;display:block" src="/images/coxeter-element/e8.svg" width="400"/>

它展示的是李代数 $E_8$ 的根系图，李代数 $E_8$ 的根系由八维欧式空间 $\mathbb{R}^8$ 中的 240 个向量组成，每个向量恰好有 56 个与其距离最近的邻居。将这 240 个向量投影到一个特殊的二维平面 (叫做 Coxeter 平面) 就会呈现一个旋转对称的图案，你可以看到上图中的图案中，240 个投影点分布在 8 个圆周上，每个圆周包含 30 个均匀分布的顶点，所以它在角度为 $\frac{2\pi}{30}$ 的旋转下是不变的。$h=30$ 叫做 $E_8$ 的 Coxeter 数。

这个现象并不是 $E_8$ 独有的，对任何有限 Coxeter 群都有类似的结论成立，比如下图显示的是将 5 维超立方体的 32 个顶点投影到其 Coxeter 平面后得到的图案：

<img style="margin:0px auto;display:block" src="/images/coxeter-element/5-cube.svg" width="480"/>

可以看到有两个顶点被同时投影到了原点，其余 30 个顶点分布在 3 个圆周上，每个圆周包含 10 个均匀分布的顶点，所以其 Coxeter 数 $h=10$。

所以这个特殊的投影平面是怎么来的？本文下面以 $E_8$ 为例子，通过具体的计算来解释背后的数学。

<!--more-->


# $E_8$ 的结构

我们知道 $E_8$ 的 Dynkin 图为

<img style="margin:0px auto;display:block" src="/images/coxeter-element/e8-dynkin.svg" width="400"/>

其一组单根系为
$$\Delta=\begin{bmatrix}1&-1&0&0&0&0&0&0\\0&1&-1&0&0&0&0&0\\0&0&1&-1&0&0&0&0\\0&0&0&1&-1&0&0&0\\0&0&0&0&1&-1&0&0\\0&0&0&0&0&1&1&0\\-\frac{1}{2}&-\frac{1}{2}&-\frac{1}{2}&-\frac{1}{2}&-\frac{1}{2}&-\frac{1}{2}&-\frac{1}{2}&-\frac{1}{2}\\0&0&0&0&0&1&-1&0\end{bmatrix}.$$
其中 Dynkin 图中编号为 $i$ 的顶点对应的单根 $\alpha_i$ 是矩阵的第 $i$ 行。注意每个单根的长度是 $\sqrt{2}$， 并不是单位向量，这样主要是为了书写方便。

其 Cartan 矩阵为
$$C=\left((\alpha_i,\alpha_j)\right)_{1\leq i,j\leq 8}=\begin{pmatrix}2&-1&0&0&0&0&0&0\\-1&2&-1&0&0&0&0&0\\0&-1&2&-1&0&0&0&0\\0&0&-1&2&-1&0&0&0\\0&0&0&-1&2&-1&0&0\\0&0&0&0&-1&2&-1&0\\0&0&0&0&0&-1&2&0\\0&0&0&0&-1&0&0&2\end{pmatrix}.$$

每个单根 $\alpha_i$ 对应一个单反射 $s_i$：
$$s_i(v) = v - \frac{2(v,\alpha_i)}{(\alpha_i, \alpha_i)}\alpha_i.$$
这里 $(\,,\,)$ 是标准欧式内积。

所有单反射生成的群 $W$ 叫做 Weyl 群，这个群包含 696729600 个元素。单根系在 Weyl 群的作用下生成的集合 $\Phi = \{w\cdot\alpha\,|\, w\in W, \alpha\in\Delta\}$ 叫做 $E_8$ 的根系，$\Phi$ 中包含 240 个不同的向量，$W$ 在 $\Phi$ 上的作用置换 $\Phi$ 中的向量。

$\Phi$ 中的向量从形式上看分为两类：

1. 第一类包含 $(\pm1,\pm1,0,0,0,0,0,0)$ 的所有置换，即有两个分量是 $+1$ 或者 $-1$，其余６个分量都是 0 的向量。这样的向量有 112 个。
2. 第二类包含所有形如 $1/2\times(\pm1,\pm1,\cdots,\pm1)$ 的向量，其中 $-1$ 的个数是偶数。这样的向量有 128 个。

我们来写出几个单反射对应的矩阵。显然 $s_1(\alpha_1)=-\alpha_1$，$s_1(\alpha_2)=\alpha_1+\alpha_2$，$s_1(\alpha_i)=\alpha_i,\,i>2$，所以 $s_1$ 在 $\alpha_1,\ldots,\alpha_8$ 这组基下的矩阵为
$$
\begin{pmatrix}-1&1&0&0&0&0&0&0\\0&1&0&0&0&0&0&0\\0&0&1&0&0&0&0&0\\0&0&0&1&0&0&0&0\\0&0&0&0&1&0&0&0\\0&0&0&0&0&1&0&0\\0&0&0&0&0&0&1&0\\0&0&0&0&0&0&0&1\end{pmatrix}.$$
由 $s_2(\alpha_1)=\alpha_1+\alpha_2,s_2(\alpha_2)=-\alpha_2,s_2(\alpha_3)=\alpha_2+\alpha_3,s_2(\alpha_i)=\alpha_i,\,i>3$ 可得 $s_2$ 对应的矩阵为
$$\begin{pmatrix}1&0&0&0&0&0&0&0\\1&-1&1&0&0&0&0&0\\0&0&1&0&0&0&0&0\\0&0&0&1&0&0&0&0\\0&0&0&0&1&0&0&0\\0&0&0&0&0&1&0&0\\0&0&0&0&0&0&1&0\\0&0&0&0&0&0&0&1\end{pmatrix}.$$
$s_5$ 对应的矩阵为
$$\begin{pmatrix}1&0&0&0&0&0&0&0\\0&1&0&0&0&0&0&0\\0&0&1&0&0&0&0&0\\0&0&0&1&0&0&0&0\\0&0&0&1&-1&1&0&1\\0&0&0&0&0&1&0&0\\0&0&0&0&0&0&1&0\\0&0&0&0&0&0&0&1\end{pmatrix}.$$
其它单反射对应的矩阵我就不再一一写出来了，相信你已经 get 到了，我要强调的是这些矩阵都是在基 $\alpha_1,\ldots,\alpha_8$ 下的。

# Coxeter 元和 Coxeter 平面

{% blockquote %}
**定义**：将单反射 $s_1,\ldots,s_8$ 按照任意顺序排列然后相乘得到的元素 $\gamma\in W$ 叫做 Coxeter 元。
{% endblockquote %}
Coxeter 元不是唯一的，但它们都属于同一个共轭类 [^1]。

一种经典的选择 Coxeter 元的方式是这样的：注意到 $E_8$ 的 Dynkin 图可以分为 1, 3, 5, 7 和 2, 4, 6, 8 两组，同组中的顶点互不相邻，所以对应的单反射两两交换。记 $x=s_1s_3s_5s_7,y=s_2s_4s_6s_8$，则取 Coxeter 元 $\gamma$ 为
$$\gamma=xy=\begin{pmatrix}0&-1&1&0&0&0&0&0\\1&-1&1&0&0&0&0&0\\-1&1&-1&1&0&0&0&0\\0&0&1&-1&1&0&0&0\\0&0&1&-1&2&-1&1&-1\\0&0&0&0&1&-1&1&0\\0&0&0&0&1&-1&0&0\\0&0&0&0&1&0&0&-1\end{pmatrix}.$$
于是
$$\gamma^{-1} = yx=\begin{pmatrix}-1&1&0&0&0&0&0&0\\-1&1&-1&1&0&0&0&0\\0&1&-1&1&0&0&0&0\\0&1&-1&1&-1&1&0&1\\0&0&0&1&-1&1&0&1\\0&0&0&1&-1&1&-1&1\\0&0&0&0&0&1&-1&0\\0&0&0&1&-1&1&0&0\end{pmatrix}.$$

关键的一步来了：我们发现
$$2I + \gamma + \gamma^{-1} = \begin{pmatrix}
1&0&1&0&0&0&0&0\\
0&2&0&1&0&0&0&0\\
1&0&2&0&1&0&0&0\\
0&1&0&2&0&1&0&1\\
0&0&1&0&3&0&1&0\\
0&0&0&1&0&2&0&1\\
0&0&0&0&1&0&1&0\\
0&0&0&1&0&1&0&1
\end{pmatrix}=(2I - C)^2.$$

Coxeter 元和 Cartan 矩阵竟有如此简洁的关系，Amazing! 不过这能告诉我们什么呢？

我们需要两个断言，这两个断言并不能从 $2I+\gamma+\gamma^{-1}=(2I-C)^2$ 这个等式得出，需要一些其它的分析。它们的证明可以在 Casselman 的文章 [^2] 中找到：

{% blockquote %}
**断言**:

1. $\gamma$ 的特征值均不为 1。
2. $2I-C$ 和 $C-2I$ 有同样的特征值，从而若 $\lambda$ 是 $2I-C$ 的特征值，则 $-\lambda$ 也是。
{% endblockquote %}

注意到 $\gamma$ 的阶有限，并且 $\gamma$ 是实矩阵，所以其特征值必然都是单位根，形如 $e^{i\theta}$，由于 1 不是 $\gamma$ 的特征值，所以其特征值 $e^{\pm i\theta}$ 成对共轭出现。设 $v$ 是 $\gamma$ 的特征值为 $e^{i\theta}$ 的特征向量，则 $v$ 是复向量且
$$(2I-C)^2 (v) = (2+e^{i\theta}+e^{-i\theta})(v) = (4\cos^2\frac{\theta}{2})(v).$$

于是 $v$ 是 $(2I-C)^2$ 的特征值为 $4\cos^2\frac{\theta}{2}$ 的特征向量。同理 $\overline{v}\ne v$ 也是 $(2I-C)^2$ 的特征值为 $4\cos^2\frac{\theta}{2}$ 的特征向量。于是 $\gamma$ 的特征子空间直和 $U=V_{e^{i\theta}}\oplus V_{e^{-i\theta}}$ 是 $(2I-C)^2$ 的特征值为 $4\cos^2\frac{\theta}{2}$ 的特征子空间，所以 $2I-C$ 在 $U$ 上的特征值只能是 $\pm2\cos\frac{\theta}{2}$，而且根据断言 2 必须 $\pm$ 号都出现，于是 $C$ 在 $U$ 上的特征值为 $2\pm2\cos\frac{\theta}{2}$。

总之我们证明了 $\gamma$ 的特征值为 $e^{\pm i\theta}$ 的特征子空间对应于 $C$ 的特征值为 $2\pm2\cos\frac{\theta}{2}$ 的特征子空间。

来验证一下？使用 Python 的 `numpy.linalg.eigh` 函数可得 $C$ 的特征值从小到大依次为

```python
[0.01095621 0.51371035 1.18652671 1.58417662 2.41582338 2.81347329 3.48628965 3.98904379]
```

第一个和最后一个之和是 4，第二个和倒数第二个之和也是 4，第三个和倒数第三个之和也是 4，第四个和第五个之和也是 4，没错！

我们知道 $C$ 是一个对角线上都是 2，其它元素均非正的矩阵，所以 $2I-C$ 是一个非负矩阵，根据 Frobenius-Perron 定理其极大特征值非负并且重数是 1，即 $C$ 的极小特征值 $0.01095621$ 的重数是 1。$C$ 的极小特征值当然就是使得 $\cos\frac{\theta}{2}$ 最大的那个 $\theta_0$，于是
$$0.01095621 \approx 2-2\cos\frac{\theta_0}{2},\quad \theta_0\approx 2\arccos0.994521895\approx\frac{2\pi}{30}.$$
所以我们验证了 Coxeter 元 $\gamma$ 的一个特征值 $e^{i\theta_0}$ 由 $\theta_0=\frac{2\pi}{30}$ 给出，$e^{i\theta_0}$ 的重数是 1，于是 $U=V_{e^{i\theta_0}}\oplus V_{e^{-i\theta_0}}$ 是一个二维的平面，叫做 Coxeter 平面。$\gamma$ 在 $U$ 上的作用是一个角度为 $\frac{2\pi}{30}$ 的旋转。$U$ 的一组基当然可以从 $\gamma$ 求出来，但是更简洁的办法是对 Cartan 矩阵 $C$，求出 $C$ 的极小特征值 $2-2\cos\frac{\theta_0}{2}$ 和极大特征值 $2+2\cos\frac{\theta_0}{2}$ 对应的特征子空间的一组基。

利用 `numpy.linalg.eigh` 不难得出 $C$ 的极小极大特征值对应的特征向量分别为

```python
>>> eigenvals, eigenvecs = numpy.linalg.eigh(C)
>>> u = eigenvecs[:, 0]
>>> v = eigenvecs[:, -1]
>>> u
>>> [-0.1191177  -0.23693033 -0.35214709 -0.46350566 -0.56978596 -0.38336132 -0.19273649 -0.28646225]
>>> v
>>> [ 0.1191177  -0.23693033  0.35214709 -0.46350566  0.56978596 -0.38336132 0.19273649 -0.28646225]
```

于是 $C$ 作为 $\alpha_1,\ldots,\alpha_8$ 这组基下的线性变换其特征值 $2\pm2\cos\frac{\theta}{2}$ 对应的特征子空间的一组基由 $\alpha=\sum u_i\alpha_i$ 和 $\beta=\sum v_i\alpha_i$ 给出。$\{\alpha,\beta\}$ 也是二维 Coxeter 平面的一组基，将根系中的向量投影到这个平面上就得到了本文开头的图案。


[^1]: 证明见 [Conjugacy of Coxeter elements, Henrik Eriksson, Kimmo Eriksson](https://arxiv.org/abs/1302.2842)。我比较喜欢基于有向无环图的论证。

[^2]: 证明见 [Casselman 的文章](https://secure.math.ubc.ca/~cass/research/pdf/Element.pdf)。
