---
title: "有限维复半单李代数的 Weyl 特征公式"
date: 2014-07-27
categories: [代数]
tags:
  - Complex semisimple Lie algebra
  - Weyl character formula
  - Cartan subalgebra
  - Root system
  - Weyl group
  - Highest weight module
  - Universal enveloping algebra
  - Casimir element
  - Verma module
  - Dominant integral weight
  - Integral representation
url: "weyl-character-formula"
---

本文源自我学习 Humphreys 的教材 [^1] 第六章 "Representation theory" 时的读书笔记，目的是介绍有限维复半单李代数的 Weyl 特征公式。Humphreys 的书是李代数课程默认的必读经典，它看着很薄，不免给人一种“我可以一个月”搞定的错觉，但我初学的时候觉得这本书并不容易读，现在回头来看才深感作者叙述之精炼。由于本文的内容直接从 Humphreys 教材的第六章开始，所以需要读者对之前章节的内容有一些基本的了解，但本文采用的叙述并不完全与 Humphreys 一致。

<!-- more -->

以下是对 Humphreys 书中前五章介绍过的一些内容的简单罗列，这里列这个单子主要是帮助读者回忆，以及在符合约定上保持和 Humphreys 的一致：

{% blockquote %}
**背景回顾与符号约定**:

+ $\mathfrak{g}$ 为有限维复半单李代数，$U(\mathfrak{g})$ 是 $\mathfrak{g}$ 的泛包络代数。
+ $\mathfrak{h}$ 是 $\mathfrak{g}$ 的 Cartan 子代数。
+ $\mathfrak{g}=\mathfrak{n}^-\oplus\mathfrak{h}\oplus\mathfrak{n}^+$ 是三角分解，$\mathfrak{b}=\mathfrak{h}\oplus\mathfrak{n}^+$ 是 Borel 子代数。
+ $\Delta$ 是一组单根系，$\Phi^+,\,\Phi^{-}$ 分别是正根和负根组成的集合。$\Phi^- = -\Phi^+$ 且每个正根都可以表示为单根的非负整系数线性组合。
+ $\mathfrak{g}$ 有根空间分解 $\mathfrak{g}=\bigoplus\limits_{\alpha\in\Phi^+}(\mathfrak{g}_\alpha\oplus\mathfrak{g}_{-\alpha})\oplus\mathfrak{h}$。其中每个根空间 $\mathfrak{g}_\alpha,\mathfrak{g}_{-\alpha}$ 都是一维的且 $[\mathfrak{g}_{\alpha}, \mathfrak{g}_{-\alpha}]\subset\mathfrak{h}$。当 $\alpha+\beta\ne0$ 时 $[\mathfrak{g}_{\alpha}, \mathfrak{g}_{\beta}]=0$。
+ Killing 型 $\kappa(x,y)$ 限制在 $\mathfrak{h}$ 上是非退化的，于是对每个 $\lambda\in\mathfrak{h}^\ast$，存在对应的元素 $t_\lambda\in\mathfrak{h}$ 使得对任何 $h\in\mathfrak{h}$ 有 $\lambda(h) = \kappa(t_\lambda, h)$。
+ 设 $\alpha\in\Phi^+$ 是正根，$e_\alpha\in\mathfrak{g}_\alpha$，$f_\alpha\in\mathfrak{g}_{-\alpha}$，则 $[e_\alpha,f_\alpha] = \kappa(e_\alpha, f_\alpha)t_\alpha$。特别地若 $e_\alpha,f_\alpha$ 满足 $\kappa(e_\alpha,f_\alpha)=\dfrac{2}{\kappa(t_\alpha,t_\alpha)}$，则 $[e_\alpha,f_\alpha]=\dfrac{2t_\alpha}{\kappa(t_\alpha,t_\alpha)}=h_\alpha$，三元组 $\{e_\alpha,f_\alpha,h_\alpha \}$ 生成一个 $\mathfrak{sl}_2(\mathbb{C})$ 单子代数。$h_\alpha$ 叫做 $\alpha$ 的余根 (coroot)。
+ 每个单根 $\alpha$ 对应一个 $\mathfrak{h}^\ast$ 上的线性变换 $s_\alpha(\beta) = \beta - \beta(h_\alpha)\alpha$，$s_\alpha$ 是一个单反射，所有 $\{s_\alpha,\alpha\in\Delta\}$ 生成的群 $W$ 叫做 Weyl 群。
+ 设 $E_\mathbb{Q}$ 是单根系 $\Delta$ 在有理数域 $\mathbb{Q}$ 上张成的向量空间，则 Killing 型给出了 $E_\mathbb{Q}$ 上的一个欧式内积：$(\alpha,\beta)=\kappa(t_\alpha,t_\beta)$。
+ $P$ 为 $\mathfrak{g}$ 的权格点，即对任何正根 $\alpha\in\Phi^+$ 有
    $$\lambda(h_\alpha)=2\frac{(\lambda,\alpha)}{(\alpha,\alpha)}\in\mathbb{Z}.$$
+ $P^+$ 为所有支配整权组成的集合，即对任何正根 $\alpha\in\Phi^+$ 有 $\lambda(h_\alpha)\in\mathbb{Z}_{\geq0}$。
+ $\rho=\frac{1}{2}\sum\limits_{\alpha\in\Phi_+}\alpha$ 是所有正根之和的一半。
+ $\mathfrak{h}^\ast$ 上的偏序 $\preceq$ 定义如下：$\mu\preceq\lambda$ 当且仅当 $\lambda-\mu=\sum k_i\alpha_i,\,k_i\in\mathbb{Z}_{\geq0}$ 是单根的非负整系数线性组合。
{% endblockquote %}

打住！这个单子已经列的够长了，其余涉及的概念就放在正文中介绍吧。


# 权模


这一段是一些关于权模的基本常识，它们在教材中通常是略过不提的，这里还是啰嗦一番。

{% blockquote %}
**定义 1**：设 $V$ 是一个 $\mathfrak{g}-$ 模，我们称 $V$ 是一个权模 (weight module)，如果 $V$ 可以分解为关于 $\mathfrak{h}$ 的权空间的直和：
$$V = \bigoplus_{\lambda\in\mathfrak{b}^\ast} V_\lambda.$$
即对任何 $h\in\mathfrak{h}$，$h$ 在 $V_\lambda$ 上的作用为 $v\to\lambda(h)v$。

我们把权空间 $V_\lambda$ 中的向量叫做权向量。
{% endblockquote %}

> 注：在本文中，我们只考虑每个权空间的维数 $\dim V_\lambda$ 均为有限的情形，但注意这里直和项的个数可以是无限的。

关于权模有这么几个常识是时时都要用到的：

1. 不同权对应的权空间之和必然是直和。(类比：线性变换的不同特征值对应的特征子空间是直和)
2. 如果 $V$ 可以由一些权向量的线性组合生成，则 $V$ 是一个权模。(类比：若线性变换的特征向量可以张成整个空间，则该线性变换是可对角化的)
3. 权模的子模和商模也都是权模。(类比：可对角化的线性变换在子空间和商空间上也都是可对角化的)
4. $\mathfrak{g}$ 的根空间 $g_\alpha$ 把 $V_\lambda$ 映射到 $V_{\lambda+\alpha}$，即 $g_\alpha V_\lambda\subseteq V_{\lambda+\alpha}$。

这几点的证明都不难，这里只解释第三点。

我们来说明如果 $N\subset V$ 是一个子模，则 $N$ 也是权模，并且有分解
$$N = \bigoplus_{\lambda\in\mathfrak{b}^\ast} (N\cap V_\lambda).$$
证明如下：设 $x\in N$，则 $n$ 可以写成
$$x=v_1 + v_2 + \cdots + v_k,\quad v_i\in V_{\lambda_i}.$$
我们要证明的是必然有每个 $v_i\in N$。若不然，设 $x$ 是一个表示为上述权向量之和的“长度”最小的反例，则必有 $k>1$。我们可以取 $h\in\mathfrak{h}$ 使得对任何 $i,j$ 都有 $\lambda_i(h)\ne\lambda_j(h)$ 成立，这是因为方程 $\lambda_i=\lambda_j$ 给出的是 $\mathfrak{h}$ 中的一个超平面，而有限多个这样的超平面的并不可能等于 $\mathfrak{h}$，故这样的 $h$ 存在。然后注意到
$$y=hx-\lambda_1(h)x=\sum_{i=2}^k(\lambda_i(h)-\lambda_1(h))v_i$$
是 $N$ 中一个长度小于 $x$ 的元素，且每个 $v_i,i\geq2$ 的系数均不为 0，因此它们都属于 $N$，从而 $v_1$ 也属于 $N$，得证。

更进一步，设 $V\xrightarrow{\varphi}V/N$ 是自然同态，不难验证每个 $\varphi(V_\lambda)$ 都是 $V/N$ 中权为 $\lambda$ 的权空间，且显然 $V/N$ 可以由 $\varphi(V_\lambda)$ 张成，所以商模 $V/N = \bigoplus\limits_{\lambda\in\mathfrak{b}^\ast}\varphi(V_\lambda)$ 也是权模。

在后面的讨论中，我们经常会遇到 $N$ 是某个 $v\in V_\lambda$ 生成的循环模的情形，这时使用维数公式有
$$\dim V_\lambda = \dim N\cap V_\lambda + \dim\varphi(V_\lambda).$$
所以 $\varphi(V_\lambda)$ 的维数严格小于 $V_\lambda$。


# 最高权循环模


最高权循环模是权模，而且是可以由一个最高权向量生成的循环模。它包含了所有的有限维不可约模。

{% blockquote %}
**定义 2**：设 $V$ 是一个 $\mathfrak{g}-$ 模，$v^+\in V$ 是一个权为 $\lambda\in\mathfrak{h}^\ast$ 的权向量，如果 $v^+$ 满足对任何 $x\in\mathfrak{n}^+$ 有 $xv^+=0$ 成立，就称 $v^+$ 是一个**奇异向量**。我们称奇异向量 $v^+$ 生成的循环模 $U(\mathfrak{g})v^+$ 为**最高权循环模**，$v^+$ 叫做 $U(\mathfrak{g})v^+$ 的**最高权向量**。
{% endblockquote %}

注意这里奇异向量与最高权向量的区别：在一个 $\mathfrak{g}-$ 模 $V$ 中，每一个奇异向量都可以生成一个最高权循环子模。当 $V$ 本身是一个最高权循环模时，$V$ 中也可以包含其它的奇异向量。

我们来分析最高权循环模 $U(\mathfrak{g})v^+$ 的结构。(Humphreys 书 20.2 小节定理)

设 $\Phi^+=\{\alpha_1,\ldots,\alpha_n,\ldots,\alpha_m\}$ 是全体正根，其中 $\Delta=\{\alpha_1,\ldots,\alpha_n\}$ 是全体单根，则 $\{f_{\alpha_i}\}_{1\leq i\leq m}$ 构成 $\mathfrak{n}^-$ 的一组基，$\{e_{\alpha_i}\}_{1\leq i\leq m}$ 构成 $\mathfrak{n}^+$ 的一组基，$\{h_i\}_{1\leq i\leq n}$ 构成 $\mathfrak{h}$ 的一组基，由 Poincaré–Birkhoff–Witt 定理，$U(\mathfrak{g})$ 的一组基形如
$$f_{\alpha_1}^{i_1}f_{\alpha_2}^{i_2}\cdots f_{\alpha_m}^{i_m}
h_1^{k_1}h_2^{k_2}\cdots h_n^{k_n}e_{\alpha_1}^{j_1}e_{\alpha_2}^{j_2}\cdots e_{\alpha_m}^{j_m}.$$
这其中每个 $e_{\alpha_j}$ 作用在 $v^+$ 上会“杀死” $v^+$，每个 $h_k$ 作用在 $v^+$ 上是数乘，所以 $U(\mathfrak{g})v^+$ 可以由形如
$$f_{\alpha_1}^{i_1}f_{\alpha_2}^{i_2}\cdots f_{\alpha_m}^{i_m}\,v^+$$
的元素生成。而每一个 $f_{\alpha_1}^{i_1}f_{\alpha_2}^{i_2}\cdots f_{\alpha_m}^{i_m}\,v^+$，如果它不是零的话，则是一个权为
$$\mu=\lambda - (i_1\alpha_1+\cdots+i_m\alpha_m)$$
的权向量，所以 $U(\mathfrak{g})v^+$ 可以由一组权向量 $\{f_1^{i_1}f_2^{i_2}\cdots f_m^{i_m}\,v^+\}$ 生成，因此也是权模，并且每个权 $\mu$ 满足 $\mu\preceq\lambda$。这印证了为什么 $U(\mathfrak{g})v^+$ 叫做“最高权”循环模。

容易看到 $U(\mathfrak{g})v^+$ 的每个权空间 $V_\mu$ 的维数是有限的，这是因为不同权对应的权向量总是线性无关的，所以在集合 $\{f_{\alpha_1}^{i_1}f_{\alpha_2}^{i_2}\cdots f_{\alpha_m}^{i_m}\,v^+\}$ 中，你不可能使用一些不属于 $V_\mu$ 的元素来线性组合出 $V_\mu$ 中的非零元素来，而 $f_{\alpha_1}^{i_1}f_{\alpha_2}^{i_2}\cdots f_{\alpha_m}^{i_m}\,v^+$ 属于 $V_\mu$ 当且仅当 $(i_1,\ldots,i_m)$ 满足 $\lambda-\sum_{k=1}^mi_k\alpha_k=\mu$，这样的非负整数序列 $(i_1,\ldots,i_m)$ 只有有限多个，所以 $\dim V_\mu$ 不会超过这样的序列的个数 (某些 $f_{\alpha_1}^{i_1}f_{\alpha_2}^{i_2}\cdots f_{\alpha_m}^{i_m}\,v^+$ 可以是 0)。特别地 $\mu=\lambda$ 当且仅当 $i_1=\cdots=i_m=0$，因此 $\dim V_\lambda=1$，即 $V_\lambda$ 是 $v^+$ 生成的一维子空间。

设 $\lambda\in\mathfrak{h}^\ast$，有趣的是，在所有以 $\lambda$ 为最高权的最高权循环模中，既有一个最小的，也有一个最大的：

1. 这个最小的模 (记作 $L_\lambda$) 是一个不可约模，它是所有最高权循环模的商模 (所有最高权模之子)。在同构的意义下，这个不可约模是唯一的。

2. 最大的模 (记作 $M_\lambda$) 自然可以称为“所有最高权模之母”：其它所有最高权模都是它的商模。$M_\lambda$ 就是我们后面要介绍的 Verma 模，它在同构的意义下也是唯一的。

不可约模 $L_\lambda$ 的唯一性比较好证明，这是因为在一个最高权循环模 $V$ 中，任何真子模都不可能含有最高权向量 $v^+$，由于不同权的权向量的线性无关性，两个真子模的和也组合不出 $v^+$ 来，因此所有真子模的和仍然是真子模，这是一个唯一的极大真子模，所以 $V$ 有唯一的不可约商模 $L_\lambda$。要说明对两个不同的最高权循环模 $V,V'$ 有 $L_\lambda\cong L_{\lambda'}$，我们可以构造直和 $W=V\oplus V'$，$W$ 也是一个以 $\lambda$ 为最高权的循环模，其最高权向量为 $(v^+,v'^+)$，且 $V,V'$ 都是它的商模，所以 $L_\lambda,L_{\lambda'}$ 都是 $W$ 的不可约同态像，因此它俩必然都同构于 $W$ 的唯一不可约商模。

另一种更直接的证明 $L_\lambda$ 唯一性的方式是使用 Verma 模 (它们都是 Verma 的唯一不可约商模！)，关于 Verma 模我们放在下一节单独介绍。


# Verma 模


{% blockquote %}
**定义 3**：设 $\lambda\in\mathfrak{h}^\ast$，我们称一个最高权循环模 $M_\lambda$ 为 Verma 模，如果任何最高权为 $\lambda$ 的循环模都是它的商模。
{% endblockquote %}

我个人比较喜欢这个定义，第一它点明了 Verma 的本质是它的泛性质，第二它只有一句话。

不过从这个定义看不出来 Verma 是否存在，存在的话又是否唯一，下面来处理这两个问题。

首先我们的定义蕴含了 Verma 模的唯一性。设 $M_\lambda,N_\lambda$ 是任何两个最高权为 $\lambda$ 的 Verma 模，则它们互为彼此的商模。不妨设 $M_\lambda / W\cong N_\lambda$，这里 $W$ 是 $M_\lambda$ 的子模，于是对任何权 $\mu$，$$ \dim [M_\lambda]_\mu \geq\dim [N_\lambda]_\mu.$$然而 $N_\lambda$ 也是 $M_\lambda$ 的商模，所以反向不等式也成立，从而上式其实是个等式，因此 $M_\lambda$ 和 $N_\lambda$ 是同构的。

存在性的证明看似稍微麻烦一点点，但其实也是数学里面的惯用招数：注意我们对 Verma 模是通过其泛性质来定义的，而在数学中要在一类对象 $\mathcal{O}$ 中构造具有给定泛性质的特殊成员时，我们总是从一个最一般的对象 $A\in\mathcal{O}$ 出发，然后在 $A$ 中对泛性质所规定的约束条件取商，注意既不能多一分 (超出泛性质规定的约束)，也不能少一分 (少于泛性质规定的约束)，这样得到的对象就满足所需的泛性质。

在这里 $\mathcal{O}$ 由所有的 $U(\mathfrak{g})-$ 循环模构成，这其中最一般的自然是 $U(\mathfrak{g})$ 作为自身的左正则模，它可以由单位元 $1$ 生成，其它任何循环模都是它的商模。

要把这个最一般的循环模 $U(\mathfrak{g})$ 变成一个具有泛性质的最高权循环模，我们看看必须添加哪些必要的约束条件。由于我们要把单位元 1 变成最高权向量，所以对任何正根 $\alpha$ 必须有 $e_\alpha\cdot1=e_\alpha=0$，以及对任何 $h\in\mathfrak{h}$ 必须有 $h\cdot1 = \lambda(h)\cdot1$，这些就够了！所以我们取 $I$ 是由所有 $e_\alpha,\alpha\in\Phi^+$ 和 $h-\lambda(h)1,h\in\mathfrak{h}$ 生成的左理想，则 $U(\mathfrak{g})/I$ 就是所要构造的 Verma 模。

注意 $U(\mathfrak{g})/I$ 作为左 $U(\mathfrak{g})-$ 模自然也是左 $U(\mathfrak{n^-})-$ 模，这个模同构于 $U(\mathfrak{n}^-)$ 的左正则表示，同构映射由
$$U(\mathfrak{n}^-)\to U(\mathfrak{g})/I:\quad 1\to 1+I$$
给出，这是很容易用 PBW 定理验证的。所以在 Verma 模中，记 $v^+=1$，则所有的 $\{f_{\alpha_1}^{i_1}f_{\alpha_2}^{i_2}\cdots f_{\alpha_m}^{i_m}\,v^+\}$ 均非零且线性无关。换句话说，Verma 模是使得 $U(\mathfrak{n}^-)$ 的作用“最自由”的最高权循环模。

Verma 模也可以通过诱导表示来构造，这里不再赘述。


# Casimir 算子在最高权循环模上的作用


Casimir 算子并不是李代数 $\mathfrak{g}$ 中的元素，它其实是泛包络代数 $U(\mathfrak{g})$ 中的元素，而且是这个结合代数的中心元，它与 $\mathfrak{g}$ 的任何表示可交换，从而 Casimir 元素的特征子空间分解给出表示的分解。

回忆 $\mathfrak{g}$ 上的 Killing 型是非退化的双线性型，我们可以取 $\mathfrak{g}$ 的一组“正交基”如下：对每个正根 $\alpha$，取 $e_\alpha\in\mathfrak{g}_\alpha,f_\alpha\in\mathfrak{g}_{-\alpha}$ 使得 $\kappa(e_\alpha,f_\alpha)=1$，则 $[e_\alpha,f_\alpha]=t_\alpha$，这里 $t_\alpha$ 是在 Killing 型下与 $\alpha$ 对等的元素，即对任何 $h\in\mathfrak{h}$ 有 $\alpha(h)=(t_\alpha,h)$。此外设单根系 $\Delta=\{\alpha_1,\ldots,\alpha_n\}$，则 $t_{\alpha_1},\ldots,t_{\alpha_n}$ 构成 $\mathfrak{h}$ 的一组基，取 $t_{\alpha_1}^\ast,\ldots,t_{\alpha_n}^\ast\in\mathfrak{h}$ 使得 $\kappa(t_{\alpha_i},t_{\alpha_j}^\ast)=\delta_{ij}$。

> 注意 $\{e_\alpha, f_\alpha, t_\alpha\}$ 的选取，它们不构成 $\mathfrak{sl}_2(\mathbb{C})$ 三元组！

现在我们有了 $\mathfrak{g}$ 的一组基 $\{e_\alpha\},\{f_\alpha\}, \{t_{\alpha_i}\}$，它们在 Killing 型下的对偶基为 $\{f_\alpha\}$, $\{e_\alpha\}$, $\{t_{\alpha_i}^\ast\}$，把它们两两配对相乘然后相加，得到的就是 Casimir 算子：
$$\Omega = \sum_{\alpha\in\Phi_+} (e_\alpha f_\alpha +f_\alpha e_\alpha)+\sum_{i=1}^n t_{\alpha_i}t_{\alpha_i}^\ast.$$

注意 Casimir 算子其实是与基的选取无关的，这里选取一组特殊的基是为了计算方便。

利用 $e_\alpha f_\alpha=t_\alpha+f_\alpha e_\alpha$ 可得
$$\Omega=2\sum_{\alpha\in\Phi_+}f_\alpha e_\alpha+\sum_{\alpha\in\Phi_+}t_\alpha+\sum_{i=1}^nt_{\alpha_i}t_{\alpha_i}^\ast.$$

设 $\lambda\in\mathfrak{h}^\ast$，$V$ 是任一最高权为 $\lambda$ 的循环模，最高权向量为 $v^+$，显然 $\Omega\cdot v^+$ 仍然是一个权为 $\lambda$ 的权向量，所以它必须是 $v^+$ 的一个数乘，即
$$\Omega\cdot v_\lambda=c_\lambda v_\lambda.$$
我们来计算这个 $c_\lambda$。

利用 $e_\alpha\cdot v_\lambda=0$ 以及 $\lambda(t_\alpha)=(\lambda,\alpha)$ 可得
$$\begin{align}c_\lambda &=
\sum_{\alpha\in\Phi_+}(\alpha,\lambda)+\sum_{i=1}^n\lambda(t_{\alpha_i})\lambda(t_{\alpha_i}^\ast)\\
&= \sum_{\alpha\in\Phi_+}(\alpha,\lambda)+\sum_{i=1}^n(\lambda,\alpha_i)(\lambda,\alpha_{i}^\ast)\\
&= 2(\lambda,\rho)+(\lambda,\lambda)\\
&= |\lambda+\rho|^2-|\rho|^2.
\end{align}$$

其中倒数第二个等号是利用了一个非常简单的纯线性代数的结论：

{% blockquote %}
设 $\{x_i\}$ 是内积空间 $(\cdot)$ 的一组基，$\{y_j\}$ 是 $\{x_i\}$ 在这个内积下的对偶基， 则对任何向量 $x$ 有$$(x,x)=\sum_{i=1}^n(x,x_i)(x,y_i).$$
{% endblockquote %}

这个计算对任何最高权循环模都适用，这样我们就得到一个重要的结论：

> Casimir 算子作用在最高权为 $\lambda$ 的循环模上是一个数乘 $|\lambda+\rho|^2-|\rho|^2$。


# Verma 模的合成列


这一小节我们来证明 Verma 具有有限长度的合成列，从而同时是 Artinian 和 Noetherian 的。于是任何最高权循环模都是有有限的合成列的。

首先是一个小引理：

{% blockquote %}
**引理**：设 $V$ 是最高权为 $\lambda$ 的最高权循环模，$v^+$ 为最高权向量，则 $V$ 不可约的充要条件是 $V$ 除了 $v^+$ 以外不含其它的奇异向量。
{% endblockquote %}

回忆一个奇异向量 $u$ 是指满足对任何 $x\in\mathfrak{n}^+$ 有 $xu=0$ 的权向量。

这个引理的含义很简答：如果 $u$ 是一个权为 $\mu\ne\lambda$ 的奇异向量，则 $\mu$ 生成一个最高权为 $\mu$ 的循环子模，且是真子模，$V$ 不可能不可约。反之如果 $V$ 可约，$U$ 是 $V$ 的真子模，$u\in U$ 为一权向量，反复用每个正根 $\alpha$ 作用在 $u$ 上会把 $u$ 所在的权空间不断“提升”，但是又不可能到达“天花板” $\lambda$ (因为 $U$ 是真子模)，所以必然会在有限次后得到一个奇异向量 $u\in U$。

{% blockquote %}
**定理 1**：Verma 模 $M_\lambda$ 有有限长度的合成列
$$(0)\subset V_1\subset\cdots\subset V_m=M_\lambda.$$
其中每个合成因子 $V_i/V_{i-1}\cong L_{\mu_i}$ 都是不可约最高权模。
{% endblockquote %}

**证明**：这里的关键是注意到最高权循环模中奇异向量生成的子空间维数是有限的。

在 Verma 模 $M_\lambda$ 中，任何权为 $\mu$ 的奇异向量 $u$ 都生成一个最高权为 $\mu$ 的循环子模 $V_\mu$ (实际上 $V_\mu$ 也是 Verma 模)，而 Casimir 算子在 $V_\mu$ 上的作用为 $|\mu+\rho|^2-|\rho|^2$，这个值必须与 Casimir 算子在 $M_\lambda$ 上作用的值 $|\lambda+\rho|^2-|\rho|^2$ 相等，所以 $\mu$ 必须满足 $\mu\preceq\lambda$ 且 $|\mu+\rho|^2=|\lambda+\rho|^2$。定义
$$S^\lambda = \{\mu\,|\, \mu\preceq\lambda,\, |\mu+\rho|^2=|\lambda+\rho|^2\}.$$
$S^\lambda$ 是一个有限集，于是 $\mu\in S^\lambda$ 只有有限多种可能，而每个这样的权空间 $V_\mu$ 的维数又是有限的，于是所有奇异向量生成的子空间 $N$ 的维数是有限的。

我们首先取 $M_\lambda$ 中一个奇异向量 $u$，使得其权 $\mu$ 在偏序 $\preceq$ 下是最小的，由于 $\mu\in S^\lambda$ 只有有限多种可能，这总是可以办到的。又由于 $\mu$ 是最小的，所以 $u$ 生成的最高权循环模 $V_\mu$ 里面不会再有其它的奇异向量了，于是根据引理 $V_\mu$ 是不可约的。转移到商模 $M_\lambda/V_\mu$ 中，$M_\lambda/V_\mu$ 也是最高权循环模，其奇异向量对应的权也都属于 $S^\lambda$，所以我们可以继续取其中的最小者 $\mu'$ 得到 $M_\lambda/V_\mu$ 中的不可约子模 $V_\mu'/V_\mu$，如此这般继续下去，并注意到每次转移到商模中时，商模中属于 $S_\lambda$ 的权对应的权空间的维数之和总是严格下降的 (见权模一节最后一段话)，所以有限多次之后我们就得到了 $M_\lambda$ 的一个合成列。


# 何时不可约模 $L_\lambda$ 是有限维？


{% blockquote %}
**定理 2**：不可约模 $L_\lambda$ 是有限维的，当且仅当 $\lambda$ 是支配整权，即对任何正根 $\alpha$ 有
$$\lambda(h_\alpha)=\frac{2(\lambda,\alpha)}{(\alpha,\alpha)}\in\mathbb{Z}_{\geq0}.$$
{% endblockquote %}

定理的必要性是很简单的，$\mathfrak{g}$ 中有一个同构于 $\mathfrak{sl}_2(\mathbb{C})$ 的子代数 $\{e_\alpha,f_\alpha,h_\alpha\}$，其中 $h_\alpha=\dfrac{2t_\alpha}{(\alpha,\alpha)}$ 是 $\alpha$ 对应的余根 [^2]。$L_\lambda$ 的权子空间链
$$V_\lambda,V_{\lambda-\alpha},\ldots,V_{\lambda-m\alpha}$$
构成其一个 $\mathfrak{sl}_2$ 子表示，因此每个权在 $h_\alpha$ 上的值都是整数且关于原点对称，即每个 $(\lambda-i\alpha)(h_\alpha) = \lambda(h_\alpha)-2i$
都是整数，且集合
$$\lambda(h_\alpha), \lambda(h_\alpha)-2, \ldots, \lambda(h_\alpha) - 2m$$
关于原点对称，因此 $m=\lambda(h_\alpha)\in\mathbb{Z}_\geq0$。

充分性的证明关键在于证明 $L_\lambda$ 的权在 Weyl 群 $W$ 的作用下是不变的，从而只能有有限多个，而 $L_\lambda$ 作为最高权循环模其每个权空间的维数又是有限的，所以 $L_\lambda$ 是有限维的。

为什么 $L_\lambda$ 的权在 Weyl 群 $W$ 的作用下不变就能推出 $L_\lambda$ 只能有有限多个权呢？这是因为 $L_\lambda$ 的权在 $W$ 作用下是若干轨道的并，每一个轨道有一个支配整权 $\mu\in P^+,\mu\preceq\lambda$ 作为代表元。而这样的支配整权的个数是有限的，因此这样的轨道只有有限多个，相应地权也只有有限多个。

要证明 $L_\lambda$ 的权在 Weyl 群 $W$ 的作用下不变，只要证明每个单根 $\alpha_i\in\Delta$，存在 $L_\lambda$ 上的可逆线性变换 $\tau$，$\tau$ 将任何权空间 $V_\mu$ 映射为权空间 $V_{s_i(\mu)}$ 即可：
$$\tau\cdot V_\mu = V_{s_i(\mu)}.$$
下面是详细的解释。

我们知道对单根 $\alpha_i$，$\mathfrak{g}$ 包含一个 $\mathfrak{sl}_2(\mathbb{C})_i$ 子代数 $\{e_{\alpha_i},f_{\alpha_i},h_{\alpha_i}\}$，简写为 $\{e_i,f_i,h_i\}$。我们首先断言 $L_\lambda$ 必然包含一个非零的、有限维的 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模 $U_i$。注意这目前只是一个断言，还需要证明。我们先假定这个断言是对的，令 $V^{\rm int}$ 是 $L_\lambda$ 中所有有限维 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模的和。由于 $U_i\subset V^{\rm int}$ 所以 $V^{\rm int}$ 非零。我们来验证 $V^{\rm int}$ 是一个 $\mathfrak{g}-$ 子模，于是由 $L_\lambda$ 的不可约性 $V^{\rm int}=L_\lambda$。

为此对 $L_\lambda$ 中任何有限维 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模 $U$，考虑向量空间 $\mathfrak{g}\cdot U$，此空间由所有形如 $x\cdot u, x\in\mathfrak{g},u\in U$ 的元素生成。由于 $\mathfrak{g}$ 是有限维李代数，所以 $\mathfrak{g}\cdot U$ 也是有限维的，其维数不会超过 $\dim\mathfrak{g}\cdot\dim W$，而且很容易验证 $\mathfrak{g}\cdot U$ 在 $\mathfrak{sl}(2,\mathbb{C})_i$ 下不变：对任何 $z\in\mathfrak{sl}_2(\mathbb{C})_i$ 和 $x\in\mathfrak{g}$，
$$z\cdot x\cdot U = [z, x]\cdot U + x\cdot (z\cdot U)\subset \mathfrak{g}\cdot U + x\cdot U\subset\mathfrak{g}\cdot U.$$
从而每个 $x\in\mathfrak{g}$ 将任何有限维 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模 $U$ 映射到另一个有限维 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模 $\mathfrak{g}\cdot U$ 中，于是 $V^{\rm int}$ 作为所有有限维 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模的和确实是一个 $\mathfrak{g}-$ 模，从而等于 $L_\lambda$。

$V^{\rm int}=L_\lambda$ 可以告诉我们什么呢？这说明对任何 $v\in L_\lambda$，$v$ 都属于一个有限维的 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模 $U$，从而 $e_i,f_i$ 作用在 $v$ 上是“局部幂零的”，即存在正整数 $k,j$ 使得 $e_i^k\cdot v=f_i^j\cdot v=0$。

> 注：设 $T$ 是向量空间 $V$ 上的线性变换，$T$ 称作局部幂零的，如果对任何 $v\in V$ 都存在正整数 $m$ 使得 $T^m v=0$。
>
> 注意这里的整数 $m$ 可以依赖于 $v$，所以即使 $T$ 不是幂零的，即不存在整数 $n$ 使得 $T^n=0$，但它可以是局部幂零的。
>
> 当 $T$ 是局部幂零的线性变换时，算子 ${\rm exp}(T)=\sum_{k=0}^\infty T^k/k!$ 是 $V$ 上的可逆线性变换，这是因为对任何 $v$ 这个求和只有有限多项。

于是算子
$$\tau = {\rm exp}(e_i){\rm exp}(-f_i){\rm exp}(e_i)$$
定义合理且是 $L_\lambda$ 上的可逆线性变换。

设 $v\in L_\lambda$ 是一个权为 $\mu$ 的权向量，我们希望证明 $\tau(v)$ 是一个权为 $s_i(\mu)$ 的权向量，即对任何 $h\in\mathfrak{h}$ 有
$$h\cdot \tau(v)  = s_i(\mu)(h)\cdot v.$$
两边关于 $h$ 都是线性的，所以我们只要分别对 $h=h_i$ 和 $h\perp h_i$ 这两种情形验证即可。

这里我想多说一点关于 Weyl 群和反射的常识，对于理解下面的证明可能有帮助。设 $\lambda\in\mathfrak{h}^\ast$ 和 $h\in\mathfrak{h}$，记双线性对 $\langle\lambda,\, h\rangle = \lambda(h)$，这个类似“内积”的记号有很多好处，下面马上就会看到。

我们知道单根 $\alpha_i$ 对应的单反射 $s_i$ 分别作用在 $\mathfrak{h}$ 和 $\mathfrak{h}^\ast$ 上，在 $\mathfrak{h}^\ast$ 上它是
$$s_i(\lambda) = \lambda - \langle \lambda, \, h_i\rangle\alpha_i.$$
在 $\mathfrak{h}$ 上它是
$$s_i(h) = h - \langle \alpha_i, \, h\rangle h_i.$$

注意 $\alpha_i$ 和 $h_i=h_{\alpha_i}$ 互为对方在对偶空间中的余根，这两个反射表达式是统一的！不仅如此，$s_i$ 还保持双线性型 $\langle\cdot,\,\cdot\rangle$ 不变：
$$\langle s_i(\lambda),\, h \rangle = \langle\lambda,\,s_i(h)\rangle.$$

好了，回到刚才的证明，分情况讨论：

1. $h=h_i$。由于 $\{e_i,f_i,h_i\}$ 构成 $\mathfrak{sl}_2(\mathbb{C})$ 三元组，这是个单李代数，其在任何表示下都同构于标准三元组
    $$e=\begin{pmatrix}0&1\\0&0\end{pmatrix},\quad h=\begin{pmatrix}1&0\\0&-1\end{pmatrix},\quad f=\begin{pmatrix}0&0\\1&0\end{pmatrix}.$$
    所以根据 Humphreys 教材第 9 页上 2.3 小节的计算，$\tau^{-1} h_i \tau = -h_i$，从而
    $$h_i\cdot\tau(v)=\tau(\tau^{-1} h_i \tau)\cdot v=\tau (-h_i)\cdot v = \langle\mu,\,s_i(h_i)\rangle\tau(v) = \langle s_i(\mu),\,h_i\rangle\tau(v).$$
    从而 $h\cdot \tau(v)  = s_i(\mu)(h)\cdot v$ 确实对 $h=h_i$ 成立。
2. $h\perp h_i$。这时 $\alpha_i(h)=0$ 所以 $s_i(h)=h$ 且 $h$ 与 $e_i,f_i$ 都交换，从而 $h$ 与 $\tau$ 也交换，因此
    $$h\cdot\tau(v) = \tau(h\cdot v) =\langle \mu,\,h\rangle\tau(v)=\langle \mu,\,s_i(h)\rangle\tau(v)=\langle s_i(\mu),\,h\rangle\tau(v).$$
    即 $h\cdot \tau(v)  = s_i(\mu)(h)\cdot v$ 对 $h\perp h_i$ 也成立。

至此我们就证明了 $L_\lambda$ 的权在 Weyl 群作用下确实是不变的。

要完成定理 2 的证明，我们还需要在 $L_\lambda$ 中找到一个非零的 $\mathfrak{sl}_2(\mathbb{C})_i-$ 模 $U$，这一部分对应于 Humphreys 教材 113 页 21.2 小节的引理和证明部分的 (1), (2)，其本质是在 $\lambda\in P^+$ 时，在 Verma 模 $M_\lambda$ 中从最高权向量 $v^+$ 出发沿着 $\alpha_i$ 的方向可以找到不同于 $v^+$ 的奇异向量，这个奇异向量位于不可约模 $L_\lambda$ 的权围成的多面体的顶点外侧。

我们以 $\mathfrak{sl}_3(\mathbb{C})$ 为例来解释：

<img style="margin:0px auto;display:block" src="/images/weyl/weights.svg" width="500"/>

这个图展示了如下的信息：

+ $\mathfrak{sl}_3(\mathbb{C})$ 的 Weyl 群是 $S_3$。
+ 图中有两个阴影区域，右边的阴影区域是 Weyl 群作用下的基本区域，由满足 $\lambda(h_{\alpha_i})\geq0,i=1,2$ 的点构成。左边的阴影区域是由 Verma 模 $M_\lambda$ 的权所构成的区域。
+ 图中蓝色的点是 $\mathfrak{sl}_3(\mathbb{C})$ 的根，它们分别是 $\pm\alpha_1,\pm\alpha_2,\pm(\alpha_1+\alpha_2)$，特别地所有正根之和的一半 $\rho=\alpha_1+\alpha_2$。
+ 图中黄色的点是基本整权 $\omega_1,\omega_2$。
+ 图中红色的点是 $L_\lambda$ 的权，它们都位于一个六边形区域内，且此六边形在 $S_3$ 下不变。你可以注意到这个六边形不是旋转不变的，所以它的对称群不是二面体群 $D_6$，实际上 Weyl 群 $S_3$ 是根系的内自同构群 (由单反射生成)，$D_6$ 虽然是根系的自同构群，但包含了外自同构 (不能由单反射生成)。$D_6/S_3\cong \mathbb{Z}_2$，而 $\mathbb{Z}_2$ 正是 $A_2$ 的 Coxeter-Dynkin 图的自同构群！
+ 图中两个标注了的绿色的点是 $f_{\alpha_i}^{\lambda(h_{\alpha_i})+1}v^+,\,i=1,2$，它们都是 Verma 模中的奇异向量，因此各自生成一个子模，这两个子模也都是 Verma 模。其它未标注的绿色点也都是奇异向量。注意所有的奇异向量必然位于以 $-\rho$ 为中心，以 $|\lambda+\rho|$ 为半径的圆周上。
+ 注意到 $\lambda,\lambda-\alpha_1,\ldots,\lambda-\lambda(h_{\alpha_1})\alpha_1$ 构成一个过 $\lambda$ 的 $\alpha_1$ 权链，此权链是六边形的一条边，且关于超平面 $\alpha_1=0$ 是对称的。对 $\alpha_2$ 也有同样的结论。

我们以 $f_{\alpha_1}^{\lambda(h_{\alpha_1})+1}v^+$ 为例子来说明它是奇异向量，一般的情形道理是完全类似的。

首先 $f_{\alpha_1}^{\lambda(h_{\alpha_1})+1}v^+$ 是权为 $\lambda - (\lambda(h_{\alpha_1})+1)\alpha_1$ 的权向量，只要再说明
$$e_{\alpha_1}f_{\alpha_1}^{\lambda(h_{\alpha_1})+1}v^+=e_{\alpha_2}f_{\alpha_1}^{\lambda(h_{\alpha_1})+1}v^+=0$$
即可。由于 $[e_{\alpha_2}, f_{\alpha_1}]=0$ 所以二者交换 ($\alpha_2-\alpha_1$ 是两个单根之差，不会是任何李代数的任何根)，因此
$$e_{\alpha_2}f_{\alpha_1}^{\lambda(h_{\alpha_1})+1}v^+ = f_{\alpha_1}^{\lambda(h_{\alpha_1})+1} e_{\alpha_2} v^+=0.$$
而 $\{e_{\alpha_1},f_{\alpha_1},h_{\alpha_1}\}$ 构成一个 $\mathfrak{sl}_2(\mathbb{C})$ 子代数，
$$v^+, f_{\alpha_1}v^+,\ldots, f_{\alpha_1}^{\lambda(h_{\alpha_1})}v^+$$
构成一个 $\mathfrak{sl}_2(\mathbb{C})$ 的最高权为 $\lambda$ 的有限维不可约表示，根据 $\mathfrak{sl}_2(\mathbb{C})$ 的表示的知识 $e_{\alpha_1}f_{\alpha_1}^{\lambda(h_{\alpha_1})+1}v^+=0$。

至此我们就完成了定理 2 的证明。


# 权模的特征


设 $V=\oplus_{\lambda\in\mathfrak{h}^\ast}V_\lambda$ 是权模，定义形式幂级数
$$\mathrm{ch} V = \sum_{\lambda} \dim V_\lambda\, e^\lambda.$$
$\mathrm{ch} V$ 叫做 $V$ 的特征，这里 $e^\lambda$ 是一个形式的符号，满足运算 $e^\lambda\cdot e^\mu=e^{\lambda+\mu}$，其在 Weyl 权 $W$ 下的作用规定为 $w\cdot e^\lambda=e^{w(\lambda)}$。

特征通常是一个无穷项的线性组合，是一个形式级数，不存在收敛到某个值的说法。但在 $V$ 是有限维表示时，$\mathrm{ch}V$ 其实是一个 Laurent 多项式，我们来解释下为什么：

取 $\omega_1,\ldots,\omega_n\in P^+$ 为一组基本整权，即权格点的一组整基，并定义变元 $x_i=e^{\omega_i}$，则对 $V$ 的任何权空间 $V_\lambda$，由于有限维表示的权必然是整权，故 $\lambda$ 可以表示为 $\omega_1,\ldots,\omega_n$ 的整系数线性组合
$$\lambda=a_1\omega_1+\cdots+a_n\omega_n,\quad a_i\in\mathbb{Z}.$$
则
$$\mathrm{ch} V = \sum_{\lambda}\dim V_\lambda\, x_1^{a_1}\cdots x_n^{a_n}\in\mathbb{Z}[x_1^{\pm1},\ldots,x_n^{\pm1}]$$
是一个关于变元 $x_1,\ldots,x_n$ 的有理多项式，实际上它关于 $W$ 是对称的。

有了这些理解，我们来定义特征的运算。

加法就定义为函数的逐点加法：设 $\mathrm{ch}V=\sum_{\lambda}a_\lambda e^\lambda,\,\mathrm{ch}W=\sum_{\lambda}b_\lambda e^\lambda$，则
$$\mathrm{ch}(V\oplus W)=\mathrm{ch}V+\mathrm{ch}W=\sum_{\lambda}(a_\lambda+b_\lambda)e^\lambda.$$
特征的乘法则定义为形式级数的乘法，就是两两相乘然后相加：
$$\mathrm{ch}V\cdot \mathrm{ch}W=\sum_{\lambda}(\sum_{\mu+\nu=\lambda}a_\mu b_\nu )e^\lambda.$$
不难验证对两个模的张量积 $V\otimes W$ 有
$$\mathrm{ch}(V\otimes W)=\mathrm{ch}V\cdot\mathrm{ch}W.$$

但是注意如果内层的求和 $\sum_{\mu+\nu=\lambda}a_\mu b_\nu$ 是个无穷和，那收敛的问题怎么办？所以在对特征做乘法时我们必须小心保证这个内层的求和只有有限多项，比如 $V,W$ 的权都来自有限多个 $\mathfrak{h}^\ast$ 中的“锥”的并，这里一个锥形如 $\mathrm{Cone}(\lambda)=\{\mu\in\mathfrak{h}^\ast,\mu\preceq \lambda\}$。这时多个模的张量积的特征也是良定义的，且满足结合律。

Verma 模的特征是很好算的，设 $\Phi^+=\{\alpha_1,\ldots,\alpha_m\}$ 是全体正根，考虑如下的乘积：
$$e^{\lambda}\cdot(1+e^{-\alpha_1}+e^{-2\alpha_1}+\cdots)(1+e^{-\alpha_2}+e^{-2\alpha_2}+\cdots)\cdots(1+e^{-\alpha_m}+e^{-2\alpha_m}+\cdots).$$
这个乘积展开的时候，是在第一个括号中取形如 $e^{-i_1\alpha_1}$ 的一项，在第二个括号中取形如 $e^{-i_2\alpha_2}$ 的一项，...，在最后一个括号中取形如 $e^{-i_m\alpha_m}$ 的一项，将这 $m$ 项和 $e^{\lambda}$ 一起相乘得到形如 $e^{\mu},\,\mu=\lambda-(i_1\alpha_1+\cdots+i_m\alpha_m)$ 的项，然后将这些乘积相加。$e^{\mu}$ 前面的系数正是使得 $\mu=\lambda-(i_1\alpha_1+\cdots+i_m\alpha_m)$ 成立的整数组 $(i_1,\ldots,i_m)$ 的个数，即 Verma 模 $M_\lambda$ 中权为 $\mu$ 的权子空间的维数，所以上面的乘积就是 $M_\lambda$ 的特征，即
$$\mathrm{ch}M_\lambda = e^\lambda \prod_{\alpha\in\Phi_+}(1+e^{-\alpha}+e^{-2\alpha}+\cdots).$$
记 $q=e^\rho\prod_{\alpha\in\Phi_+}(1-e^{-\alpha})$，则不难验证对任何 $w\in W$ 有 $wq = (-1)^{l(w)}q$ [^3]，且
$$q\cdot\mathrm{ch}M_\lambda = e^{\lambda+\rho}\prod_{\alpha\in\Phi_+}(1+e^{-\alpha}+e^{-2\alpha}+\cdots)(1-e^{-\alpha}) = e^{\lambda+\rho}.$$


# Weyl 特征公式


在本节中，约定 $\lambda\in P^+$ 是支配整权，$S^\lambda$ 表示有限集
$$S^\lambda = \{\mu\,|\, \mu\preceq\lambda,\, |\mu+\rho|^2=|\lambda+\rho|^2\}.$$

根据我们之前的结论，Verma 有有限的合成列，每个不可约合成因子的最高权 $\mu\in S^\lambda$，所以

$$\mathrm{ch}M_\lambda=\sum_{\mu\in S^\lambda} a_{\mu}\mathrm{ch}L_\mu = L_\lambda + \sum_{\mu\in S^\lambda,\mu\ne\lambda} a_{\mu}\mathrm{ch}L_\mu.$$

注意这里我们要求 $\mu$ 跑遍整个 $S^\lambda$，如果某个 $L_\mu$ 不出现在 Verma 模 $M_\lambda$ 的合成列中则 $a_\mu=0$。于是 $a_\mu$ 都是非负整数，它们是 $L_\mu$ 出现在 $M_\lambda$ 的合成因子中的次数，叫做 Kazhdan-Luszitg 重数，是非常难计算的。

注意到对每个 $\mu$，Verma 模 $M_\mu$ 也可以分解为
$$\mathrm{ch}M_\mu  =\sum_{\nu\in S^\lambda} a_{\nu}\mathrm{ch}L_\nu = L_\mu + \sum_{\nu\in S^\lambda,\nu\ne\mu} a_{\nu}\mathrm{ch}L_\nu.$$
所有这些权都属于 $S^\lambda$ 所以只有有限多个。将这些 $\{\mathrm{ch}M_{\mu_i},\mathrm{ch}L_{\mu_i},1\leq i\leq l\}$ 按照偏序 $\preceq$ 排列，使得若 $\mu_i\prec\mu_j$ 则 $i > j$，则 $\{\mathrm{ch}M_{\mu}\}$ 和 $\{\mathrm{ch}L_{\mu}\}$ 之间的矩阵是一个对角线上都是 1 的上三角矩阵：
$$\begin{pmatrix}
\mathrm{ch}M_{\lambda}\\
\mathrm{ch}M_{\mu_2}\\
\vdots\\
\mathrm{ch}M_{\mu_l}
\end{pmatrix} =
\begin{pmatrix}
1 & \cdots & \cdots & \ast\\
  & 1 & \cdots & \ast\\
  &   & \ddots &\vdots\\
  &   &        & 1
\end{pmatrix}
\begin{pmatrix}
\mathrm{ch}L_{\lambda}\\
\mathrm{ch}L_{\mu_2}\\
\vdots\\
\mathrm{ch}L_{\mu_l}
\end{pmatrix}
$$
这个矩阵可逆，且逆矩阵也是对角元是 1 的上三角矩阵，所以可以反解出
$$\mathrm{ch}L_\lambda=\sum_{\mu\in S^\lambda} b_{\mu}\mathrm{ch}M_\mu= M_\lambda + \sum_{\mu\in S^\lambda,\mu\ne\lambda} b_{\mu}\mathrm{ch}M_\mu.$$
两边乘以 $q$ 得到
$$q\cdot\mathrm{ch}L_\lambda=\sum_{\mu\in S^\lambda} b_{\mu}e^{\mu+\rho}.$$

一种很方便的约定是规定 Weyl 群 $W$ 在 $\mathfrak{h}^\ast$ 上的“点”作用 $\bullet$ 为
$$w\bullet \lambda = w(\lambda+\rho) - \rho,$$
并规定 $\mathfrak{h}^\ast$ 上的等价关系 $\sim$ 为 $\lambda\sim\mu$ 当且仅当存在 $w\in W$ 使得 $\mu = w\bullet \lambda$。

记 $W\bullet\lambda = \{w\bullet\lambda, w\in W\}$，则集合 $W\bullet\lambda$ 中的元素互不相同，由于 $\lambda\in P^+$ 是支配整权，所以 $\lambda+\rho$ 是强支配整权，所以对任何 $w\in W$ 有 $w(\lambda+\rho)\preceq \lambda+\rho$，即 $w\bullet\lambda\preceq\lambda$，且等号成立当且仅当 $w=1$ [^4]。又
$$|w\bullet\lambda + \rho|=|w(\lambda+\rho)|=|\lambda+\rho|$$
所以 $W\bullet\lambda\subseteq S^\lambda$。

接下来的证明关键在于说明集合 $W\bullet\lambda$ 和 $S^\lambda$ 是一一对应的，且当 $\mu=w\bullet\lambda$ 时有 $b_\mu=(-1)^{l(w)}$，所以我们可以把等式
$$q\cdot\mathrm{ch}L_\lambda=\sum_{\mu\in S^\lambda} b_{\mu}e^{\mu+\rho}$$
改写为
$$q\cdot\mathrm{ch}L_\lambda=\sum_{\mu=w\bullet\lambda}(-1)^{l(w)}e^{w\bullet\lambda+\rho}=\sum_{w\in W}(-1)^{l(w)}e^{w(\lambda+\rho)}.$$
特别令 $\lambda=0$ 为一维平凡表示，则有

{% blockquote %}
**Weyl 分母公式**:
$$q=\sum_{w\in W}(-1)^{l(w)}e^{w(\rho)}.$$
{% endblockquote %}

从而有

{% blockquote %}
**Weyl 特征公式**：
$$\mathrm{ch}L_\lambda = \frac{\sum_{w\in W}(-1)^{l(w)}e^{w(\lambda+\rho)}}{\sum_{w\in W}(-1)^{l(w)}e^{w(\rho)}}.$$
{% endblockquote %}

要证明当 $\mu=w\bullet\lambda$ 时有 $b_\mu=(-1)^{l(w)}$，在
$$q\cdot\mathrm{ch}L_\lambda=\sum_{\mu\in S^\lambda} b_{\mu}e^{\mu+\rho}$$
两边用 $w\in W$ 作用，并利用 $wq=(-1)^{l(w)}q$ 以及 $\mathrm{ch}L_\lambda$ 是 $W-$ 不变的，得到
$$q\cdot\mathrm{ch}L_\lambda=\sum_{\mu\in S^\lambda}(-1)^{l(w)}b_{\mu}e^{w(\mu+\rho)}.$$

比较上面两关于 $q\cdot\mathrm{ch}L_\lambda$ 的式子的右边我们得到如果 $\mu+\rho=w(\nu+\rho)$，即 $\mu = w\bullet\nu$ 则 $b_\mu=(-1)^{l(w)}b_\nu$，特别地由于 $b_\lambda=1$ 所以若 $\mu=w\bullet\lambda$ 则 $b_\mu=(-1)^{l(w)}$。

要证明 $W\bullet\lambda = S^\lambda$，我们已经看到 $W\bullet\lambda\subset S^\lambda$，只要再证明反向包含也成立。设 $\mu\preceq\lambda$ 满足 $|\mu+\rho|=|\lambda+\rho|$，我们要证明 $\mu\in W\bullet\lambda$。我们知道 Weyl 群传递地作用在所有的胞腔 (chambers) 上，因此总可以选取 $w\in W$ 使得 $w(\mu+\rho)$ 落在基本 Weyl 胞腔的闭包内，即 $w(\mu+\rho)$ 是一个支配整权，从而对任何正根 $\alpha$ 有
$$ (\alpha,w(\mu+\rho))\geq0.$$
我们断言这时必有 $w(\mu+\rho)=\lambda+\rho$，即 $\mu=w^{-1}\bullet\lambda$。这是一个几何上很明显，证明起来也不难的事实：$w(\mu+\rho)$ 和 $\lambda+\rho$ 都是基本 Weyl 胞腔的闭包中的点 ($\lambda+\rho$ 是强支配整权所以还属于基本胞腔的内部)，它俩的长度相同，但是 $w(\mu+\rho)$ 在偏序 $\preceq$ 下小于等于 $\lambda+\rho$，这只有在它俩是同一个点时才可能 [^5]，因此 $w(\mu+\rho)=\lambda+\rho$，从而确实 $W\bullet\lambda = S^\lambda$，这就完成了 Weyl 特征公式的证明。


# 例子：$\mathfrak{sl}_n(\mathbb{C})$ 的特征公式


本节以 $\mathfrak{sl}_n(\mathbb{C})$ 为例来给出它的有限维不可约表示的特征，即著名的 Schur 多项式。

以下是 $\mathfrak{sl}_n(\mathbb{C})$ 的一些基本信息：

1. Cartan 子代数为
    $$\mathfrak{h}=\left\{\begin{pmatrix}a_1 &&&\\ &a_2&&\\&&\ddots&\\&&&a_n\end{pmatrix}\in\mathrm{Mat}_n(\mathbb{C})\,|\, a_1+a_2+\cdots+a_n=0\right\}.$$
    其对偶空间为 $\mathfrak{h}^\ast=\mathbb{C}\{L_1,\ldots,L_n\}/(L_1+\cdots+L_n)$，其中线性泛函
    $$L_i\left(\begin{pmatrix}a_1 &&&\\ &a_2&&\\&&\ddots&\\&&&a_n\end{pmatrix}\right) = a_i.$$
2. 设 $E_{ij}$ 为 $(i,j)$ 位置的分量是 1，其它位置均为 0 的矩阵，则 Cartan 子代数一组基为 $\{H_i = E_{ii} - E_{i+1,i+1}, 1\leq i\leq n-1\}$。
3. 记 $H_{ij} = E_{ii}- E_{jj}$，则对任何 $i<j$，$\{E_{ij},E_{ji},H_{ij}\}$ 构成一个 $\mathfrak{sl}_2(\mathbb{C})$ 三元组。
4. 一组单根为 $\Delta=\{L_i-L_{i+1},1\leq i\leq n-1\}$，对应的全体正根为 $\Phi^+=\{L_i-L_j,i<j\}$。
5. Weyl 群为 $n$ 阶置换群 $S_n$。$W$ 在 $\mathfrak{h}^\ast$ 上的作用如下：对任何 $\sum a_iL_i$，$\sigma\in S_n$ 将 $(L_1,\ldots,L_n)$ 置换为 $(L_{\sigma(1)},\ldots,L_{\sigma(n)})$。
6. Killing 型限制在 $\mathfrak{h}$ 上为 $\kappa(A,B)=2n\mathrm{tr}(AB)=2n\sum_{i=1}^na_ib_i$。
7. 正根 $\alpha=L_i-L_j$ 在 $\mathfrak{h}$ 中对等的元素为 $t_\alpha=\frac{1}{2n}H_{ij}$，对应的余根为 $h_\alpha=H_{ij}$。
8. 所有正根之和的一半 $\rho=\frac{1}{2}((n-1)L_1 +(n-3)L_2+\cdots+(1-n)L_{n}$。由于 $L_1+\cdots+L_n=0$ 我们可以给 $\rho$ 加上 $\frac{n-1}{2}(L_1+\cdots+L_n)$ 从而取 $\rho=(n-1)L_1+(n-2)L_2+\cdots+L_{n-1}+0L_n$。
9. 一组基本整权为 $\{\omega_i=L_1+\cdots+L_i,1\leq i\leq n-1\}$。
10. $\lambda\in P^+$ 是支配整权当且仅当 $\lambda$ 是基本整权的非负整系数线性组合，即
    $$\lambda=\sum a_i\omega_i=(a_1+\cdots+a_{n-1})L_1+(a_2+\cdots+a_{n-1})L_2+\cdots +a_{n-1}L_{n-1}.$$
    设 $\lambda_i=a_1+\cdots+a_i$ 并规定 $\lambda_n=0$，则 $\lambda_i\in\mathbb{Z}_{\geq0}$ 且 $\lambda_1\geq\cdots\geq\lambda_{n-1}\geq\lambda_n=0$。
11. 记 $x_i=e^{L_i}$，则 $e^{\lambda}= x_1^{\lambda_1}x_2^{\lambda_2}\cdots x_n^{\lambda_n}$，$e^{\rho}= x_1^{n-1}x_2^{n-2}\cdots x_{n-1}x_n^0$，且对任何 $\sigma\in S_n$ 有 $e^{\sigma(\lambda)}=e^{\sum \lambda_iL_{\sigma(i)}}=x_{\sigma(1)}^{\lambda_1}x_{\sigma(2)}^{\lambda_2}\cdots x_{\sigma(n)}^{\lambda_n}$。

于是根据 Weyl 特征公式有

$$\mathrm{ch}V_\lambda=\frac{\sum_{\sigma\in S_n}\mathrm{sgn}(\sigma)x_{\sigma(1)}^{\lambda_1+n-1}x_{\sigma(2)}^{\lambda_2+n-2}\cdots x_{\sigma(n)}^{\lambda_n}}{\sum_{\sigma\in S_n}\mathrm{sgn}(\sigma)x_{\sigma(1)}^{n-1}x_{\sigma(2)}^{n-2}\cdots x_{\sigma(n)}^{0}}=\frac{\det(x_j^{\lambda_i+n-i})}{\det(x_j^{n-i})}.$$
$\mathrm{ch}V_\lambda$ 是一个整系数对称多项式 $s_\lambda(x_1,\ldots,x_n)$，叫做 Schur 多项式。

---


[^1]: J. Humphreys. Introduction to Lie Algebras and Representation Theory. Graduate Texts in Mathematics, 9, Springer-Verlag New York, 1978.
[^2]: 见 Humphreys 教材 37 页 8.3 小节的 Proposition.
[^3]: 只要对单反射 $s_i$ 验证 $s_iq= - q$ 即可。而 $s_iq=e^{s_i(\rho)}\prod_{\alpha\in\Phi_+}(1-e^{-s_i(\alpha)})$，然后利用 $s_i(q)=\rho-\alpha_i$ 以及 $s_i$ 将 $\alpha_i$ 映射为 $-\alpha_i$ 并置换 $\Phi^+$ 中除 $\alpha_i$ 以外的其它正根这两个事实。
[^4]: 见 Humphreys 教材 68 页 13.2 小节的 Lemma A。
[^5]: 我们来证明若 $\mu\preceq\lambda$ 都是基本 Weyl 胞腔中的整权，且 $\lambda$ 是强支配整权，那么如果 $|\lambda|=|\mu|$ 则必有 $\lambda=\mu$。为此设 $\lambda-\mu=\sum k_i\alpha_i$ 为正根的整系数线性组合，则 $(\lambda+\mu,\lambda-\mu)=(\lambda+\mu,\sum k_i\alpha_i)=|\lambda|^2-|\mu|^2=0$，由于 $\lambda$ 是强支配整权所以 $\lambda+\mu$ 也是强支配整权，这只有在所有 $k_i$ 都是 0 时才可能，即 $\lambda=\mu$。
