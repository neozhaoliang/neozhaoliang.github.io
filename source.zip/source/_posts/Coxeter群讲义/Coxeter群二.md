---
title: "Coxeter 群基础知识 （二）：几何实现"
categories: [Coxeter Groups]
date: 2021-12-04
tags:
  - Coxeter groups
  - Cartan matrix
  - Coxeter matrix
  - Gallery
  - Reduced word
  - Reflection
  - Standard geometric realization
  - Tits cone
  - Simple root
  - Root system
url: "coxeter-groups-II"
---

\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}

本系列的 [第一篇文章](/coxeter-groups-I/) 讨论了两个反射生成的万花筒的结构，本文是系列的第二篇，将讨论推广到一般的有限生成 Coxeter 群。

我们还是会同时关注 $V^\ast$ 中根系 （反射镜面） 的结构和 $V$ 中 Tits 锥（万花筒）的结构。

“锥”是本文中出现的一个高频词，有必要在这里明确澄清。本文采用如下定义：

{% blockquote %}
设 $V$ 是一个实向量空间，称集合 $C\subset V$ 是一个**锥**，如果对任何 $x\in C$ 和实数 $\alpha\geq0$ 有 $\alpha x\in C$。此外如果 $C$ 还是一个凸集，就称 $C$ 是一个**凸锥**。这时对任何 $x,y\in C$ 和非负实数 $\alpha,\beta\geq0$ 都有 $\alpha x + \beta y\in C$ 成立。
{% endblockquote %}

<!--more-->

# 抽象 Coxeter 群

设 $S$ 是一个集合，一个基于 $S$ 的 Coxeter 矩阵 $M=(m_{s,t})_{s,t\in S}$ 是一个对称矩阵，其对角线上都是 1，非对角线元素取值范围为 $\{2,3,\ldots,\infty\}$。$S$ 的基数 $|S|$ 叫做 $M$ 的秩 (rank)，在本文中我们只考虑 $|S|<\infty$ 的情形。

对任一给定的 Coxeter 矩阵 $M$，$M$ 确定了一个 Coxeter 群 $W$，它具有如下的表现：
$$W = \langle s\in S\ |\ (st)^{m_{s,t}}=1\ {\rm if}\ m_{s,t}<\infty\rangle.$$

于是 $S$ 作为 $W$ 的生成元满足如下的生成关系：

{% blockquote %}

1. 对任何 $s\in S$ 有 $s^2=1$。
2. 对任何 $s\ne t, m_{s,t}<\infty$ 有辫关系 $\overbrace{sts\cdots}^{m_{s,t}}=\overbrace{tst\cdots}^{m_{s,t}}$ 成立。
   {% endblockquote %}

我们把 $(W, S)$ 叫做一个 Coxeter 系。

对 $W$ 中的任一元素 $w$，它可能有许多种不同的方式表示为 $S$ 中生成元的乘积。在 $w$ 的所有表示中，长度最短的表示叫做 $w$ 的**既约表示**：即若 $w=s_{i_1}s_{i_2}\cdots s_{i_k}$ 是一个长度为 $k$ 的乘积，且 $w$ 不存在任何长度小于 $k$ 的表示，就称 $s_{i_1}s_{i_2}\cdots s_{i_k}$ 是 $w$ 的既约表示。$w$ 的既约表示可能不唯一，但它们都具有相同的长度。$w$ 的长度 $l(w)$ 就定义为 $w$ 的任意一个既约表示的长度。

$l(w)$ 具有如下的性质：

> 1. $l(xy)\leq l(x) + l(y)$。
> 2. $l(w) = l(w^{-1})$。
> 3. $l(w)=0$ 当且仅当 $w$ 是恒等元。
> 4. $l(ws)$ = $l(w)\pm 1$，其中 $w\in W, s\in S$。

前三点都是显然的，只有 4 需要证明。显然 $|l(ws)-l(w)|\leq 1$，所以只要说明 $l(ws)$ 和 $l(s)$ 不相等即可。这一步需要用到自由群的泛性质：

设 $F$ 是由集合 $S$ 生成的自由群，定义群同态 ${\rm sgn}: F\to{\pm1}$ 如下：对自由群 $F$ 的每个生成元 $s\in S$ 定义映射 ${\rm sgn}(s)=-1$，然后将此映射扩充为 $F$ 到 ${\pm1}$ 的群同态。容易验证 $(W,S)$ 的所有生成关系都属于这个同态的核，因此根据自由群的泛性质，${\rm sgn}$ 诱导了一个从 $(W,S)$ 到 ${\pm1}$ 的群同态。在此同态下，若 $w=s_{i_1}s_{i_2}\cdots s_{i_k}$ 是 $w$ 的任一既约表示，则 $${\rm sgn}(w)={\rm sgn}(s_{i_1}){\rm sgn}(s_{i_2})\cdots{\rm sgn}(s_{i_k})=(-1)^k=(-1)^{l(w)}.$$ 从而 ${\rm sgn}(ws)={\rm sgn}(w){\rm sgn}(s)=-{\rm sgn}(w)$ 说明 $l(ws)\ne l(w)$。

# Coxeter 群的几何实现

设 $(W,S)$ 是一个 Coxeter 系，$M=(m_{s,t})_{s,t\in S}$ 是 Coxeter 矩阵。定义其 Cartan 矩阵为 $C=(c_{s,t})_{s,t\in S}$，其中

$$
c_{s,t}=c_{t,s} = \begin{cases}-2\cos\dfrac{\pi}{m_{s,t}} & m_{s,t}<\infty,\\
-2a_{s,t} & m_{s,t}=\infty.\end{cases}
$$

这里 $a_{s,t}\geq 1$。$a_{s,t}$ 的选择有一定的任意性，任何 $\geq1$ 的实数都是可以的，并且不同的 $(s,t)$ 对可以使用不同的 $a_{s,t}$。我们规定对每个 $m_{s,t}=\infty$ 都选好了一个这样的 $a_{s,t}$。

注意到 Cartan 矩阵的对角元总是等于 2，非对角元则总是 $\leq0$。

> **注**：在后面我们会看到，$a_{s,t}=1$ 对应的是两个仿射的平行镜面，$a_{s,t}>1$ 对应的是双曲空间中两个超平行的镜面。

设 $V$ 是一个维数为 $|S|$ 的实向量空间，其对偶空间为 $V^\ast$，取 $V^\ast$ 的一组基 $\{\alpha_s \mid s\in S\}$。这是一组线性无关的线性泛函，根据线性方程组解的判定定理，我们一定可以取 $V$ 中的一组向量 $\{\alpha_s^\vee\mid s\in S\}$ 使得对任何 $s,t\in S$ 有 $\lfun{\alpha_s}{\alpha_t^\vee}=c_{s,t}$ 成立。注意 $\{\alpha_s^\vee\}$ 未必构成 $V$ 的一组基。比如 Coxeter 矩阵 $\begin{bmatrix}1 & \infty\\\infty&1\end{bmatrix}$ 给出的 Cartan 矩阵是
$\begin{pmatrix}2 & -2\\-2&2\end{pmatrix}$，这时 $\alpha^\vee=-\beta^\vee$ 是线性相关的。

对任一 $s\in S$，定义 $V$ 上的反射 $\rho_s$ 为
$$\rho_s(v) = v - \lfun{\alpha_s}{v}\alpha_s^\vee,\quad v\in V.$$
显然 $\rho_s(\alpha_s^\vee) = -\alpha_s^\vee$。

$\rho_s$ 也可以作为 $V^\ast$ 中的反射：
$$\rho_s(\lambda) = v - \lfun{\lambda}{\alpha_s^\vee}\alpha_s,\quad \lambda\in V^\ast.$$
显然 $\rho_s(\alpha_s) = -\alpha_s$。

$\rho_s$ 在 $V,V^\ast$ 上的这两种作用是互相伴随的：
$$\lfun{\rho_s\cdot \lambda}{v} = \lfun{\lambda}{\rho_s\cdot v},\quad v\in V,\lambda\in V^\ast.$$

上面这些操作其实都有明确的目的：

1. 我们把 Cartan 矩阵的非对角线元素都定义为负值，并且同时为 0 或者同时不为 0。根据 [上一篇文章](/coxeter-groups-I/) 中的讨论，这样任何一对反射 $\rho_s,\rho_t$ 可以生成一个二维万花筒，其基本区域 $K_{s,t}$ 在 $\rho_s,\rho_t$ 生成的群 $W_{s,t}$ 的作用下互不重合。下面会看到，反射之间这样两两构成万花筒，就可以保证整个 $W$ 在 $V$ 上的作用也构成一个万花筒，即存在一个基本区域 $\fd$ 使得 $w\fd\cap\fd =\emptyset$ 对任何 $w\in W,w\ne1$ 成立。
2. 我们区分了 $V$ 和对偶空间 $V^\ast$。许多教材在开始的时候会采用一种简单些的做法：取 $\{\alpha_s\mid s\in S\}$ 为 $V$ 的一组基，并定义 $V$ 上的内积 $\bullet$ 为
   $$\alpha_s\bullet\alpha_t=\begin{cases}-\cos\dfrac{\pi}{m_{s,t}}&m_{s,t}<\infty,\\-1&m_{s,t}=\infty.\end{cases}$$
   并使用这个内积来定义反射。这种做法的好处是会简化一些讨论，比如可以很快证明下面要介绍的关键定理；但缺点是无法用来定义万花筒的基本区域。如果我们想把所有反射镜面的正半空间之交
   $$\bigcap_{s\in S}\{v\in V\mid\alpha_s\bullet v>0\}$$
   作为万花筒的基本区域 $\fd$，则 $\fd$ 可能会是空集。仍然以 Coxeter 矩阵 $\begin{bmatrix}1 & \infty\\\infty&1\end{bmatrix}$ 为例，它给出的内积 $\bullet$ 为
   $$
   \begin{pmatrix}\alpha_s\bullet\alpha_s & \alpha_s\bullet\alpha_t\\
   \alpha_t\bullet\alpha_t& \alpha_t\bullet\alpha_t\end{pmatrix} =\begin{pmatrix}1&-1\\-1&1\end{pmatrix}.
   $$
   假设 $v=a\alpha_s+b\alpha_t$ 满足 $v\bullet\alpha_s>0$ 且 $v\bullet\alpha_t>0$，你会发现这要求 $a>b$ 且 $b>a$，不存在这样的 $v$！但是通过区分 $V$ 和 $V^\ast$ 上的作用就可以避免这个问题。因为 $\{\alpha_s\}$ 是一组线性无关的泛函，它们的正半空间的交一定是个非空的开集。
3. 映射 $s\to\rho_s$ 给出了 $(W,S)$ 的一个线性表示 $\rho: W\to\rho(W)\leqslant{\rm GL}(V)$。后面将证明表示 $\rho$ 实际是一个同构，从而我们可以把抽象的 Coxeter 群 $W$ 与 ${\rm GL}(V)$ 的子群 $\rho(W)$ 等同起来，不再区分二者，并把 $w\in W$ 在 $V$ 上的作用记作 $wv = \rho(w)(v)$。

现在我们给出一些关键概念的定义。

定义所有线性泛函 $\{\alpha_s\}$ 的正半空间的交为 $\fd = \cap_{s\in S}\{\alpha_s > 0\}\subset V$，你可以把 $\fd$ 理解为万花筒中原像所在的房间，$\alpha_s=0$ 是房间的墙壁，$\alpha_s<0$ 是墙壁的背面。$\fd$ 必然是个非空开集，其闭包记作 $\barfd$，$\barfd$ 就是 $\fd$ 加上了房间四周的墙壁。

$\overline{\fd}$ 的另一种等价的描述方式是，取 $\{\alpha_s\}$ 的一组对偶基 $\{e_t\}$ 满足 $\lfun{\alpha_s}{e_t}=\delta_{st}$。$\{e_t\}$ 就是基本区域的顶点，即房间的“墙角”，$\{e_t\}$ 的凸包就是 $\overline{\fd}$。这件事我们后面会用到。

我们称集合
$$\Phi=\{w\alpha_s\mid w\in W, \, s\in S\}$$
为 $(W, S)$ 的**根系**，任何 $\lambda\in\Phi$ 叫做一个根向量，简称为**根**。**根都是对偶空间 $V^\ast$ 中的非零线性泛函**。我们之前选择的 $V^\ast$ 的一组基 $\Delta=\{\alpha_s\mid s\in S\}$ 叫做一组**单根系**，其中的根叫做**单根**。由于 $\Delta$ 构成 $V^\ast$ 的一组基，所以 $\Phi$ 中任何根 $\lambda$ 都是单根的线性组合：
$$\lambda = \sum_{s\in S}c_s\alpha_s,\quad c_s\in\mathbb{R}.$$
如果上面的所有系数 $c_s$ 都非负，就称 $\lambda$ 是一个**正根**；反之若所有系数 $c_s$ 都非正，就称 $\lambda$ 是一个**负根**。正根和负根组成的集合分别记作 $\Phi^+$ 和 $\Phi^-$，显然 $\Phi^+\cap\Phi^-=\emptyset$。

这里有个问题：系数 $c_s$ 一定同时非负或者同时非正吗？换句话说，是不是每个根必然是正根或者负根？

答案是肯定的，为此我们需要一个关键的定理。

## 关键定理

现在我们来证明一个非常关键的结论，它是本文的核心。不夸张的说，Coxeter 群的许多基本性质都可以从它导出。

<div id="theorem1">
{% blockquote %}
**定理 1**：设 $s\in S, w\in W$，则

1. $l(ws) > l(w)$ 当且仅当 $w\alpha_s\in\Phi^+$。
2. $l(ws) < l(w)$ 当且仅当 $w\alpha_s\in\Phi^-$。
{% endblockquote %}
</div>

这里 1 和 2 是等价的：如果 1 成立，则

$$
\begin{align*}
l(ws)<l(w)&\Leftrightarrow l((ws)s) > l(ws)\\
&\Leftrightarrow ws(\alpha_s)\in\Phi^+\\
&\Leftrightarrow w(-\alpha_s)\in\Phi^+\\
&\Leftrightarrow w\alpha_s\in\Phi^-.
\end{align*}
$$

所以只需要证明 1 即可。首先我们需要一个引理：

<div id="lemma1">
{% blockquote %}
**引理 1**：设 $T\subseteq S$ 是 $S$ 的子集，$T$ 中的生成元在 $(W,S)$ 中生成一个子群 $W_T \leqslant (W,S)$，$W_T$ 叫做**标准椭圆子群**。设 $w$ 为 $W$ 中任一元素，则存在 $x\in W$ 和 $u\in W_T$ 满足：

1. $w=xu$ 且 $l(w)=l(x)+l_T(u)$。
2. 对任何 $t\in T$ 有 $l(xt) > l(x)$。

其中 $l_T(\cdot)$ 是 $W_T$ 上的长度函数。即 $x$ 是 $w$ 在 $W/W_T$ 中长度最短的陪集代表元。

{% endblockquote %}

</div>

**引理 1 的证明**：我从 [Casselman 那里](https://personal.math.ubc.ca/~cass/coxeter/crm.html) 学到了一个直观的论证方法：

满足要求的一对 $(x, u)$ 可以通过如下算法求出来：

```
x := w
u := 1
while l(xt) < l(x) for some t in T
    x := xt
    u := tu
end
```

我们来证明这个 `while` 循环结束后得到的 $(x, u)$ 符合要求。由于循环每执行一次 $x$ 的长度都严格减少，因此这个循环必然在有限次后结束。显然每次执行循环时等式 $w=xu$ 始终保持成立，且循环结束后得到的 $(x,u)$ 满足对任何 $t\in T$ 有 $l(xt)>l(x)$，所以只剩下验证 $l(w)=l(x)+l_T(u)$ 始终成立即可。初始时 $l(w)=l(w) + l_T(1)$ 是成立的，假设某轮循环执行前 $l(w)=l(x)+l_T(u)$ 成立，我们要说明执行后 $l(w)= l(xt) + l_T(tu)$ 也成立。

注意不等式
$${\color{red} l(x)+l_T(u)}=l(w)=l(xt\cdot tu)\leq l(xt)+l(tu)\leq {\color{red} l(xt) + l_T(tu)}<l(x)+l_T(tu),$$
其中最后一个不等号是已知的 $l(xt)<l(x)$，倒数第二个不等号是因为对任何 $u\in W_T$ 总是有 $l_T(u)\geq l(u)$ 成立。现在：

1. 比较上面不等式左右两头得到 $l_T(u) < l_T(tu)$，那必须是 $l_T(u)=l_T(tu)-1$。
2. 将上面的等式代入比较标红的两项得到 $l(x)\leq l(xt)+1$，结合 $l(x)>l(xt)$ 得到 $l(x)=l(xt)+1$。
3. 将 1, 2 中的等式相加得到 $l(x)+l_T(u)=l(xt)+l_T(tu)$，引理得证。

{% blockquote %}
**注**：

1. 不难进一步得出对任何 $u\in W_T$ 有 $l_T(u)=l(u)$ 成立：取 $w=u$，则 $x$ 必然是 1，从而 $l(u)=l_T(u)$，即 $(W,S)$ 上的长度函数 $l$ 限制在 $(W_T,T)$ 上就是 $l_T$。这不是个显然的事情，因为 $T$ 中的生成元与 $S\backslash T$ 中的生成元之间存在 Coxeter 矩阵给出的辫关系，有可能 $u=t_{i_1}t_{i_2}\cdots t_{i_k}$ 作为 $T$ 上的乘积不能进一步被缩短，但作为 $S$ 上的乘积却可以进一步缩短。

2. 这个引理的含义是，对于任何 $w\in W$，我们一定可以在其所在的左陪集 $wW_T$ 中取一个长度最短的陪集代表元 $x$，使得当 $w$ 分解为 $w=xu,u\in W_T$ 时，这个分解还保持长度的加法：$l(w)=l(x)+l(u)$。
   {% endblockquote %}

**[定理 1](#theorem1) 的证明**：

我们先证明充分性：若 $l(ws)>l(w)$ 则 $w\alpha_s\in\Phi^+$。

对 $w$ 的长度 $l(w)$ 归纳：$l(w)=0$ 时 $w=1$，结论显然成立，下面设结论对 $W$ 中所有长度小于 $l(w)$ 的元素成立。

我们总是可以取 $t\ne s$ 使得 $l(wt)<l(w)$，比如 $t$ 取为 $w$ 的某个既约表达式的最后一项。令 $T=\{s,t\}$，$w=xu$ 是如 [引理 1](#lemma1) 中的分解，则 $x$ 满足 $l(xt) > l(x)$ 和 $l(xs)>l(x)$。我们来分别考察 $x$ 和 $u$ 是怎样作用在 $\{\alpha_s,\alpha_t\}$ 上的。

$x$ 的分析比较容易：显然 $l(x)<l(w)$，由归纳假设 $x\alpha_s\in\Phi^+$，$x\alpha_t\in\Phi^+$。

如果我们能够证明 $u\alpha_s$ 可以表示为 $\alpha_s$ 和 $\alpha_t$ 的非负线性组合：$u\alpha_s = p\alpha_s + q\alpha_t$，其中 $p,q\geq0$ 且不全为 0，则
$$w\alpha_s=xu\alpha_s=x(p\alpha_s + q\alpha_t)=px\alpha_s + qx\alpha_t\in\Phi^+.$$
这就证明了结论。

于是问题归结为分析在二面体群 $W_T$ 中一个元素 $u\in W_T$ 在 $\alpha_s$ 上的作用。这里要考虑 $m_{s,t}=\infty$ 和 $m_{s,t}<\infty$ 两种情形。

首先二面体群 $W_T$ 的结构是很清楚的：

1. 在 $m_{s,t}=\infty$ 时 $W_T$ 是无限二面体群，其元素为所有 $s$ 和 $t$ 交替出现的字符串，每个这样的字符串都是既约的。

2. 在 $m_{s,t}=m<\infty$ 时 $W_T$ 是二面体群 $D_m$，其 $2m$ 个元素罗列如下，每个字符串也都是既约的：$$1,\ s,\ t,\ st,\ ts,\ sts,\ tst,\ \cdots,\ \overbrace{sts\cdots}^{m}=\overbrace{tst\cdots}^{m}.$$

我们断言这两种情形下 $u$ 作为 $W_T$ 中的元素其任何既约表示不能以 $s$ 结尾，否则 $l_T(us)=l_T(u)-1$，从而

$$
\begin{align*}l(ws)&=l(xus)\\
&\leq l(x) + l(us)\\
&= l(x)+l_T(us)\\
&=l(x)+l_T(u)-1\\
&= l(w)-1.
\end{align*}
$$

这与 $l(ws) > l(w)$ 矛盾！

于是 $u$ 形如 $u=\cdots t$，这种类型的元素作用在 $\alpha_s$ 上的结果在前文中已经计算过了：

<span style="color:blue">**$m_{s,t}=\infty$ 的情形**</span>

1. $a_{s,t} = 1$ 时：
   $$\alpha_s\xrightarrow{\ t\ }\alpha_s+2\alpha_t\xrightarrow{\ s\ }3\alpha_s+2\alpha_t\xrightarrow{\ t\ }3\alpha_s + 4\alpha_t\xrightarrow{\ s\ }\cdots$$
   每一项都是 $\alpha_s,\alpha_t$ 的非负线性组合。
2. $a_{s,t} > 1$ 时：
   $$\alpha_s\xrightarrow{\ t\ }\shthe{}\alpha_s+\shthe{2}\alpha_t\xrightarrow{\ s\ }\shthe{3}\alpha_s+\shthe{2}\alpha_t\xrightarrow{\ t\ }\cdots$$
   其中 $\theta>0$，每一项仍然都是 $\alpha_s,\alpha_t$ 的非负线性组合。

<span style="color:blue">**$m_{s,t}=m\geq2\in\mathbb{Z}$ 的情形**</span>

$$\alpha_s\xrightarrow{\ t\ }\sthe{}\alpha_s+\sthe{2}\alpha_t\xrightarrow{\ s\ }\sthe{3}\alpha_s+\sthe{2}\alpha_t\xrightarrow{\ t\ }\cdots$$
其中 $\theta=\pi/m$。这个链的第 $k$ 项形如

$$
\begin{cases}
\sthe{k}\alpha_s + \sthe{(k-1)}\alpha_t & \text{$k$ odd},\\
\newline
\sthe{(k-1)}\alpha_s + \sthe{k}\alpha_t & \text{$k$ even}.
\end{cases}
$$

并不是每一项都是 $\alpha_s,\alpha_t$ 的非负线性组合，但是前 $m$ 项 $k=1,2,\ldots,m$ 都是，这就足够了：由于 $u$ 的任何既约表示不能以 $s$ 结尾，所以 $u$ 可能的取值为
$$1,\ t,\ st,\ \ldots,\ \overbrace{\ast\cdots\ast t}^{\leq m-1},$$
正好是序列的前 $m$ 项。$u$ 的长度不等于 $m$ 是因为根据辫关系会等于以 $s$ 结尾的另一个既约表示，与 $u$ 的任何既约表示不能以 $s$ 结尾矛盾。$u$ 的长度超过 $m$ 就肯定不是既约表示了。

必要性的证明：

我们要证明若 $w\alpha_s\in\Phi^+$ 则 $l(ws)>l(w)$。若不然，则 $l(w)=l(wss)>l(ws)$，从而由充分性的证明知道 $ws\alpha_s\in\Phi^+$，即 $w\alpha_s\in\Phi^-$，矛盾！

至此定理 1 得证。$\blacksquare$

## 关键定理的几何解释

上面的 [关键定理](#theorem1) 也是有明确的几何意义的，也不难理解。

我们知道基本区域 $\fd$ 这个房间是所有 $\{\alpha_s > 0\mid s\in S\}$ 的交，这个房间有 $|S|$ 个不同的墙壁，其中“墙壁 $s$”位于超平面 $\{\alpha_s=0\}$ 上。在 $w\in W$ 的作用下，这个墙壁被映射为 $w\fd$ 和 $ws\fd$ 之间标号为 $s$ 的墙壁。

<img style="margin:0px auto;display:block" src="/images/coxeter-groups/wd.svg" width="400"/>

对一个房间 $w\fd$，如果我们穿过它的标号为 $s$ 的墙壁到达相邻的房间 $ws\fd$，那么 $w\fd$ 与 $ws\fd$ 谁距离 $\fd$ 更远？注意 $\fd$ 和 $s\fd$ 位于超平面 $\alpha_s=0$ 的两侧，所以 $w\fd$ 和 $ws\fd$ 位于超平面 $w\alpha_s=0$ 的两侧。$\fd$ 站在它们俩的哪一边决定了 $l(ws)$ 和 $l(w)$ 的大小关系：

| | |
|:---:|:---:|
| $l(ws) > l(w)$ | $l(ws) < l(w)$ |
| <img style="margin:0px auto;display:block" src="/images/coxeter-groups/lws.svg" width="250"/> | <img style="margin:0px auto;display:block" src="/images/coxeter-groups/lw.svg" width="250"/> |

1. 如果 $\fd$ 站在 $w\fd$ 一边，从 $w\fd$ 穿过墙壁到达 $ws\fd$ 后变成了和 $\fd$ 异侧，这就更远了，即 $l(ws)>l(w)$；
2. 反之如果 $\fd$ 站在 $ws\fd$ 一边，从 $w\fd$ 穿过墙壁到达 $ws\fd$ 后变成了和 $\fd$ 同侧，这就更近了，即 $l(ws)<l(w)$。

$w\fd$ 和 $\fd$ 位于 $w\alpha_s=0$ 同侧要求 $\lfun{w\alpha_s}{w\fd}$ 和 $\lfun{w\alpha_s}{\fd}$ 同为正或者同为负，而 $\lfun{w\alpha_s}{w\fd}=\lfun{\alpha_s}{\fd}>0$ 是正的，所以 $\lfun{w\alpha_s}{\fd}$ 也要大于 0，这只有在 $w\alpha_s$ 是正根时才可以。异侧的情形对应 $w\alpha_s$ 是负根。这就是关键定理的几何解释。

## 一大波推论

从关键定理出发可以得到许多有用的结论。

<div id="prop1">
{% blockquote %}
**推论 1**：如果 $w\in W$ 满足对任何 $v\in V$ 有 $wv=v$，则 $w=1$。换言之，表示 $\rho: W\to{\rm GL}(V)$ 是忠实的。从而我们可以把 $W$ 和 $\rho(W)$ 等同起来。
{% endblockquote %}
</div>

这个可以从下面引理直接得出：

<div id="lemma2">
{% blockquote %}
**引理 2**：对任何 $w\ne1\in W$ 都有 $w\mathcal{D}\cap\mathcal{D}=\emptyset$。
{% endblockquote %}
</div>

用反证法，取 $s\in S$ 使得 $l(ws)<l(w)$，从而 $w\alpha_s\in\Phi^-,\,\lfun{w\alpha_s}{\fd}<0$。

另一方面 $\lfun{w\alpha_s}{w\fd}=\lfun{\alpha_s}{\fd}>0$，所以 $w\mathcal{D}\cap\mathcal{D}=\emptyset$。

<div id="prop2">
{% blockquote %}
**推论 2**：每个根不是正根就是负根，即 $\Phi=\Phi^+\cup\Phi^-$。
{% endblockquote %}
</div>

这是因为任何根 $\lambda\in\Phi$ 可以表示为 $\lambda=w\alpha_s$，其中 $w\in W, \alpha_s\in\Delta$。若 $l(ws)>l(w)$ 则 $\lambda=w\alpha_s\in\Phi^+$，否则 $l(ws)<l(w)$，$\lambda=w\alpha_s\in\Phi^-$。

<div id="prop3">
{% blockquote %}
**推论 3**：任何单反射 $s$ 置换 $\Phi^+\backslash\{\alpha_s\}$ 中的正根，同时将 $\alpha_s$ 变为 $-\alpha_s$。
{% endblockquote %}
</div>

这是因为对任何正根 $\lambda\ne\alpha_s\in\Phi^+$，由于 $\lambda\ne\alpha_s$，所以在线性组合 $\lambda=\sum_{s\in S}c_s\alpha_s$ 中至少还有一个 $s'\ne s$ 使得 $c_{s'}>0$，于是 $s\lambda=\lambda-\lfun{\lambda}{\alpha_s^\vee}\alpha_s$ 的 $s'$ 分量仍然为正，从而根据推论 2 $s\lambda$ 必须仍然是正根。

<div id="prop4">
{% blockquote %}
**推论 4**：对 $w\in W$，定义 $N(w)$ 为在 $w$ 作用下被变为负根的那些正根组成的集合：$N(w)=\{\lambda\in\Phi^+\mid w\lambda\in\Phi^-\}$，则 $|N(w)|=l(w)$。
{% endblockquote %}
</div>

证明：我们已经知道 $l(w)$ 满足如下的递推关系：

$$
l(ws) =\begin{cases}
l(w)+1,& w\alpha_s\in\Phi^+,\\
l(w)-1,& w\alpha_s\in\Phi^-.
\end{cases}
$$

只需要证明 $|N(w)|$ 也满足同样的递推关系即可：

$$
|N(ws)| =\begin{cases}|N(w)|+1,& w\alpha_s\in\Phi^+,\\
|N(w)|-1,& w\alpha_s\in\Phi^-.\end{cases}
$$

设 $\lambda\in\Phi^+$ 并观察恒等式
$$(ws)\lambda\in\Phi^- \Leftrightarrow w(s\lambda)\in\Phi^-.$$
如果我们想由此得出 $\lambda\in N(ws)\Leftrightarrow s\lambda\in N(w)$ 的话，就必须先保证 $\lambda$ 和 $s\lambda$ 均为正根，根据推论 3 这当且仅当 $\lambda\ne\alpha_s$ 时才可以。而当 $\lambda=\alpha_s$ 时，$\lambda$ 恰好属于 $N(ws)$ 和 $N(w)$ 其中之一，具体属于哪个由 $l(ws)$ 和 $l(w)$ 的大小关系决定。 当 $l(ws)<l(w)$ 时，$\alpha_s\in N(w)$，这对应递推关系中的 2；当 $l(ws) > l(w)$ 时，$\alpha_s\in N(ws)$，这对应递推关系中的 1，推论得证。

<div id="prop5">
{% blockquote %}
**推论 5**：若 $w\in W$ 把正根仍然映射为正根，即 $w(\Phi^+)\subseteq\Phi^+$，则 $w=1$。
{% endblockquote %}
</div>

根据 [推论 4](#prop4) 这个比较显然。

<div id="prop6">
{% blockquote %}
**推论 6**：$|W|<\infty$ 当且仅当 $|\Phi|<\infty$。
{% endblockquote %}
</div>

如果 $W$ 是有限群，由于 $\Phi=W\cdot \Delta$，$|\Phi|\leq |W|\cdot |\Delta|$ 也是有限的。

反之若 $|\Phi|<\infty$，则由 [推论 5](#prop5) 知道 $W$ 可以嵌入到置换群 $S_{|\Phi|}$ 中，从而也是有限的。

<div id="prop7">
{% blockquote %}
**推论 7**：若 $W$ 是一个有限群，则存在唯一的元素 $w$，$w$ 是 $W$ 中长度最大者，它交换 $\Phi^+$ 和 $\Phi^-$：$w(\Phi^+)=\Phi^-$，且 $w$ 是一个对合：$w^2=1$。
{% endblockquote %}
</div>

证明：由于 $W$ 有限，所以可以取其一个长度最大的元素 $w$。于是对任何 $s\in S$ 有 $l(ws)<l(w)$，从而 $w\alpha_s\in\Phi^-$，从而 $w$ 把单根系 $\Delta$ 都变为负根，自然也就把 $\Phi^+$ 变为 $\Phi^-$。

由于 $w^2$ 保持 $\Phi^+$ 不变，所以由 [推论 5](#prop5) 必须 $w^2=1$，因此 $w$ 是一个对合。

如果还存在其它的最长元素 $w'\ne w$ 呢？那么 $w'$ 也满足 $w'(\Phi^+)=\Phi^-$，从而 $w^{-1}w'$ 保持 $\Phi^+$ 不变，即 $w^{-1}w'=1, w=w'$。

<div id="prop8">
{% blockquote %}
**推论 8**：设 $J\subsetneqq S$ 是真子集，$\lambda\in \Phi^+\backslash \Phi^+_J$ 是正根，则有如下结论：

1. 对任何 $w\in W_J$，$w\lambda$ 都是正根。
2. 对任何 $w\in W_J$ 和 $x\in\mathcal{D}$ 都有 $\langle\lambda,\,wx\rangle>0$。
{% endblockquote %}
</div>

1 是因为 $w\lambda$ 是 $\lambda$ 和一些 $\{\alpha_t,\,t\in J\}$ 的线性组合：
$$w\lambda=\lambda + \sum_{t\in J}k_t\alpha_t.$$
由于 $\lambda\in \Phi^+\backslash \Phi^+_J$，所以其至少有一项 $\alpha_s,\,s\notin J$ 的系数大于 0，从而 $w\lambda$ 不可能是负根。

2 是 1 的直接结论。

# Tits 锥

在获得了 $V^\ast$ 中关于根系的一些知识后，我们回到空间 $V$ 中讨论万花筒的结构。

前面已经定义了基本区域 $\fd$ 为所有正半空间 $\{\alpha_s>0\mid \alpha_s\in\Delta\}$ 的交，给房间 $\fd$ 加上四周的墙壁得到 $\barfd$，于是 $\barfd$ 是一个锥，定义 **Tits 锥**为
$$\tc = \bigcup_{w\in W} w\barfd.$$
Tits 锥 $\tc$ 即为万花筒结构。

有两件值得注意的事情：

1. 我们使用了 Tits “锥” 这个称呼，但 $\tc$ 真的是一个锥吗？这可不显然。
2. 一般来说 Tits 锥的结构是很复杂的，除了知道它是一个凸锥之外，其它的信息我们所知甚少。但是在 $(W,S)$ 不可约，且内积 $\bullet$ 是有限、仿射或者双曲时，我们确实可以得出一些更多的信息，本文最后会对此进行讨论。

定义 $\plc{\Delta}$ 为单根系 $\Delta$ 的所有非负系数线性组合：
$$\plc{\Delta} = \left\{\sum_{s\in S}c_s\alpha_s,c_s\geq0\right\}.$$
显然 $\plc{\Delta}$ 是 $V^\ast$ 中的一个锥。它在 $V$ 中的对偶锥正是基本区域的闭包 $\barfd$：
$$\barfd = \{v\in V\mid \lfun{\lambda}{v}\geq0,\ \forall \lambda\in\plc{\Delta}\}.$$
对任何 $v\in V$，定义
$$\negf{v}= \{\lambda\in \Phi^+\mid \lfun{\lambda}{v}<0\}.$$
$\negf{v}$ 表示 $v$ 位于哪些镜子的背面，$\negf{v}$ 是正根 $\Phi^+$ 的一个子集，可以是有限的或者无限的。

<div id="lemma3">
{% blockquote %}
**引理**：$\overline{\mathcal{D}}=\{v\in V\mid \mathrm{Neg}(v)=\emptyset\}$。
{% endblockquote %}
</div>

这个引理是如此一目了然，因此我略过它的证明。

## Tits 锥是凸锥

要证明 Tits 锥确实是锥，我们需要它的另一种等价刻画。本小节就来处理这个问题。

<div id="theorem2">
> **定理 2**：对任何 $v\in\barfd$，记 $J=\{s\in S \mid \lfun{\alpha_s}{v}=0\}$，则
> $$\{w\in W\mid wv=v\} = W_J = \{w\in W\mid wv\in\barfd\}.$$
</div>

**定理 2 的几何直观**：对 $\barfd$ 中的一点 $v$，$v$ 在 $W$ 中的稳定化子群 $\stab{v}$ 是个标准椭圆子群，由那些包含 $v$ 的墙面 $\{\alpha_s\mid \lfun{\alpha_s}{v}=0\}$ 对应的反射组成。

1. 如果 $v$ 落在房间内部，即 $v\in\fd$，那么 $\stab{v}$ 是平凡的；
2. 如果 $v$ 落在单个墙壁 $s$ 上，则 $\stab{v}=\langle s\rangle$ 是二阶循环群；
3. 如果 $v$ 落在两个墙壁 $s,t$ 的交线上，则 $\stab{v}=\langle s,t\rangle$ 是个二面体群；
4. 如果 $v$ 恰好落在三个墙壁的墙角处，$\stab{v}$ 就是这三个墙壁给出的 rank 3 的 Coxeter 群，等等。

**[定理 2](#theorem2) 的证明**：

直观地，$J$ 由那些包含 $v$ 的墙壁组成，关于这些墙壁的反射是保持 $v$ 不动的，即对任何 $s\in J$ 有
$$s\cdot v= v-\lfun{\alpha_s}{v}\alpha_s^\vee = v.$$
即 $sv = v$ 对任何 $s\in J$ 成立，从而 $W_J\subseteq\{w\in W \mid wv=v\}$。

另一方面显然有 $\{w\in W\mid wv=v\}\subseteq \{w\in W\mid wv\in\barfd\}$ 成立，所以只要再证明 $\{w\in W\mid wv\in\barfd\}\subseteq W_J$。我们只要从 $w$ 最末一个元素开始逐个验证它们属于 $J$ 即可。

设 $w\ne1$ 的某个既约表示的结尾是 $s$，则 $l(ws)<l(w)$，于是 $w\alpha_s\in\Phi^-$。

如果 $wv\in\barfd$，则我们有
$$0\geq \lfun{w\alpha_s}{wv} = \lfun{\alpha_s}{v}\geq0.$$
其中第一个不等号是因为 $w\alpha_s$ 是负根和 $wv\in\barfd$。所以 $\lfun{\alpha_s}{v}=0$，即 $s\in J$，从而 $sv=v$，于是 $wv=w'sv=w'v\in\barfd$，从而我们可以对 $l(w')<l(w)$ 重复此论证，得到 $w$ 的乘积中所有因子都属于 $J$，从而定理得证。$\blacksquare$

上面的证明还可以换一种表述：设 $w=w^Jw_J$ 是如[引理 1](#lemma1) 中那样关于标准椭圆子群 $W_J$ 的陪集分解，$w^J$ 是长度最短的陪集代表元，于是对任何 $s\in J$ 都有 $l(w^Js)>l(w^J)$，从而 $w^J\alpha_s\in\Phi^+$ 对任何 $s\in J$ 成立。我们断言 $w^J$ 必然是单位元，从而 $w=w_J\in W_J$。否则任取单根 $\alpha_t$ 使得 $w^J\alpha_t\in\Phi^-$，则 $t\notin J$。但另一方面由 $wv=w^Jw_Jv=w^Jv\in\fd$，有
$$0\geq \lfun{w^J\alpha_t}{w^Jv} = \lfun{\alpha_t}{v}\geq0.$$
这只能是 $\lfun{\alpha_t}{v}=0$，从而 $t\in J$，矛盾！

<div id="prop9">
{% blockquote %}
**推论 9**：Tits 锥 $\mathcal{C} = \{v\in V \mid |\mathrm{Neg}(v)| < \infty\}$。
{% endblockquote %}
</div>

这个推论的几何意义是：每个镜子的正面是包含 $\fd$ 的一侧，另一侧是背面，Tits 锥就是那些只落在有限多个镜子背面的点，它们可以经过有限次反射后变换到所有镜子的正面，即 $\barfd$ 中。

**[推论 9](#prop9) 的证明**：

$\Rightarrow$: 设 $x\in\tc$，则 $x$ 可以表示为 $x=wv$，其中 $w\in W,v\in\barfd$。设 $\lambda\in\Phi^+$，则根据
$$\lfun{x}{\lambda}=\lfun{wv}{\lambda}=\lfun{v}{w^{-1}\lambda}$$
有 $\lfun{x}{\lambda}< 0\Rightarrow w^{-1}\lambda\in\Phi^-$，即 $\negf{x}\subseteq N(w^{-1})$，从而
$$|\negf{x}|\leq |N(w^{-1})|=l(w^{-1})=l(w)<\infty.$$

$\Leftarrow$: 反之若 $|\negf{x}|<\infty$，我们来论证可以选择 $w\in W,v\in\barfd$ 来使得 $x=wv$。

这里的想法是，我们每次选择一个单根 $\alpha_s$ 对应的镜面，且 $x$ 落在这个镜子的背面。将 $x$ 关于 $\alpha_s$ 反射过去，将它变到 $\alpha_s$ 的正面，这个操作会将遮挡在 $x$ 和 $\barfd$ 之间的镜子个数严格减少 1。如此这般直到 $x$ 落入 $\barfd$ 为止。

严格的论证如下：

若 $\negf{x}=\emptyset$ 这显然成立，因为这时 $x$ 本身就落在 $\barfd$ 中。当 $\negf{x}$ 不为空集时，其中一定包含一个单根 $\alpha_s\in\Delta$，于是 $\lfun{\alpha_s}{x}< 0$。考虑 $x$ 关于 $\alpha_s$ 的镜像点 $sx$，我们来分析集合 $\negf{sx}$，即那些遮挡 $sx$ 的镜子。我们断言 $\negf{sx} = s\cdot(\negf{x}-\{\alpha_s\})$，即 $\negf{sx}$ 元素个数比 $\negf{x}$ 严格减少 1。

$sx$ 位于 $\alpha_s$ 的正面，所以 $\alpha_s\notin\negf{sx}$。设 $\lambda\ne\alpha_s$ 是任一正根，则 $s\lambda$ 也是正根。于是
$$\lambda\in\negf{sx}\Leftrightarrow\lfun{sx}{\lambda}<0\Leftrightarrow\lfun{x}{s\lambda}<0\Leftrightarrow s\lambda\in\negf{x}.$$
所以 $\lambda\to s\lambda$ 给出了从 $\negf{sx}$ 到 $\negf{x}-\{\alpha_s\}$ 的一一对应，这就证明了 $\negf{sx} = s\cdot(\negf{x}-\{\alpha_s\})$。重复此过程我们最终可以取一组 $s_{i_1},\ldots,s_{i_k}$ 使得 $y=s_{i_1}\cdots s_{i_k}x=wx$ 满足 $\negf{y}=\emptyset$，从而 $y\in\barfd$，这就证明了结论。

<div id="prop10">
{% blockquote %}
**推论 10**：Tits 锥 $\mathcal{C}$ 是凸锥。
{% endblockquote %}
</div>

**证明**：只要说明当 $x, y\in\tc$ 以及 $\alpha,\beta\geq0$ 时有 $z=\alpha x+\beta y\in\tc$ 即可。但是 $\negf{z}\subseteq\negf{x}\cup\negf{y}$，根据 [推论 9](#prop9) $\negf{x},\,\negf{y}$ 都是有限集，所以 $\negf{z}$ 也有限，从而 $z\in\tc$。

### [推论 9](#prop9) 在编程中的应用

推论 9 给出了 Tits 锥的等价刻画，它不仅结论重要，证明过程也是非常有用的，是所谓 [Wythoff 构造法](https://en.wikipedia.org/wiki/Wythoff_construction) 绘制万花筒结构的理论基础，被广泛应用在 shader 渲染中。

在 shader 中绘制万花筒的步骤如下：对空间中的每个点 $p$，我们反复用 $\Delta$ 中的镜面将其反射，直到落入基本区域 $\barfd$ 内，得到对应的原像点 $q\in\barfd$。然后根据 $q$ 在 $\barfd$ 中的位置来绘制 $p$ 点对应的像素。这个反射的步骤用伪代码来写非常简单：（用 Python 演示）

```python
for step in range(30):
    for alpha_s in Delta:
        if on_negative_side(p, alpha_s):
            p = reflect(p, alpha_s)
```

我们重复了 30 次这样的操作 （30 次在绝大多数渲染场景中足够用了）：每次都依次检查 $p$ 是否落在某个 $\alpha_s$ 的背面，如果答案为是，就将其反射至 $\alpha_s$ 的正面。这个方法可以保证将任何满足 $l(w)\leq30$ 的 $w\barfd$ 中的点映射入 $\barfd$ 中。

## Tits 锥的内部

记 $\tc^{\circ}$ 为 Tits 锥的内部，我们有如下定理：

<div id="theorem3">
{% blockquote %}
**定理 3**：$x\in\mathcal{C}^\circ$ 当且仅当 $x$ 在 $W$ 中的稳定化子群是有限群。
{% endblockquote %}
</div>

这个定理的几何意义最好对照上一篇文章中的插图，仔细体会有限、仿射、双曲三种情形 Tits 锥的边界分别是什么？基本区域的各个顶点的稳定化子群分别是什么？

这里给一个 rank 3 的例子：

<img style="margin:0px auto;display:block" width=480 src="/images/hyperbolic-honeycombs/paracompact.png"/>

这是一个双曲 Coxeter 群，每个三角形都有一个位于边界上的顶点，这个顶点是两个镜面在无穷远边界上的交点，其稳定化子群由这两个镜面生成，是一个有 $\infty$ 标记的 rank 2 的仿射 Coxeter 群，所以它不属于 Tits 锥的内部。

这个定理不太好证明，我们首先处理 $x\in\barfd$ 的情形。

<div id="lemma4">
> **引理 4**：设 $x\in\barfd$，记 $J=\{s\in S\mid\lfun{\alpha_s}{x}=0\}$。则 $x\in\tc^\circ$ 当且仅当 $W_J$ 是有限群。
</div>

[引理 4](#lemma4) 的证明：

$\Rightarrow$：

> 思路：如果 $x$ 是 $\tc$ 的内点，并且经过 $x$ 的镜面有无穷多个，那么可以在 $x$ 的附近取一点 $z$，$z$ 仍然是 $\tc$ 的内点，使得这无穷多个镜子都挡在基本区域和 $z$ 之间，从而 $\negf{z}$ 是无限集，从而 $z\notin\tc$，导致矛盾。

任取 $y\in\fd$。由于 $x\in\tc^\circ$，所以在线段 $\overline{[y, x]}$ 上我们可以朝着 $x$ 的方向延伸一点点，得到点 $z$，使得 $z$ 仍然位于 $\tc^\circ$ 中。$z$ 可以表示为
$$z=(1-t)x+ty\qquad t<0,$$
于是对所有 $s\in J$ 都有 $\lfun{\alpha_s}{z}=t\lfun{\alpha_s}{y} < 0$ 成立。如果 $W_J$ 是无限群那么 $J$ 对应的根系 $\Phi_J=W_J\cdot\{\alpha_s\mid s\in J\}$ 也是无限的，从而 $\negf{z}\supseteq \Phi^+_J$ 是无限集，从而 $z\notin\tc^\circ$，矛盾！

$\Leftarrow$：

反之若 $W_J$ 是有限群，仍然任取 $y\in\fd$。

对任何镜面 $s\in S\backslash J$，由于 $x$ 不属于此镜面，所以 $\lfun{\alpha_s}{x}>0$。此外根据 [推论 8](#prop8) 对任何 $w\in W_J$ 也有 $\lfun{\alpha_s}{wy}>0$ 成立，于是
$$\delta = \min\left\{\frac{\lfun{\alpha_s}{x}}{\lfun{\alpha_s}{wy}}\,\middle|\, \alpha_s\in S\backslash J,\, w\in W_J\right\}.$$
是一个正数，将上面的分母乘到左边然后对 $w\in W_J$ 求和，我们有
$$\delta\cdot\lfun{\alpha_s}{\sum_{w\in W_J}wy}\leq \lfun{\alpha_s}{x}\cdot |W_J| < 2\lfun{\alpha_s}{x}\cdot |W_J|.$$

注意到上面这个不等式两边关于 $\alpha_s$ 都是线性的。

对任何 $\lambda\in\Phi^+\backslash\Phi_J^+$，$\lambda$ 可以表示为一些 $\{\alpha_s,\,s\in S\backslash J\}$ 和一些 $\{\alpha_t,\,t\in J\}$ 的非负线性组合。我们已经看到对 $s\in S\backslash J$ 上面的不等式成立，而对任何 $t\in J$，由于 $\sum_{w\in W_J}wy$ 在 $W_J$ 下保持不变，所以根据 [定理 2](#theorem2)，$\lfun{\alpha_{t}}{\sum_{w\in W_J}wy}=0$，所以上面的不等式两边都是 0。把这些 $s\in S\backslash J$ 中的严格不等式和 $t\in J$ 中的等式组合起来，我们得到将 $\lambda$ 代入 $\alpha_s$ 的位置上述严格不等式仍然成立。

于是对任何 $\lambda\in\Phi^+\backslash\Phi_J^+$ 有
$$\delta\cdot\lfun{\lambda}{\sum_{w\in W_J}wy}< 2\lfun{\lambda}{x}\cdot |W_J|.$$
根据 [推论 8](#prop8) 上面每一个 $\lfun{\lambda}{wy}$ 都是大于 0 的，我们可以只取 $w=1$ 的一项，其余全扔掉，得到
$$\delta\cdot\lfun{\lambda}{y}< 2\lfun{\lambda}{x}\cdot |W_J|.$$
记 $z = 2|W_J|x - \delta y$，我们得到 $\lfun{\lambda}{z}>0$ 对任何 $\lambda\in\Phi^+\backslash\Phi_J^+$ 成立。

另一方面对任何 $\mu\in\Phi_J^+$，由于 $\lfun{\mu}{x}=0$，所以 $\lfun{\mu}{z}=-\delta\lfun{\mu}{y}<0$，于是 $\negf{z}=\Phi_J^+$ 是有限集，从而 $z\in\tc$。

实际上我们有 $z\in\tc^\circ$，这是因为对任何 $\lambda\in\Phi$，$\lambda$ 必然属于 $\pm\Phi^+_J,\pm(\Phi^+\backslash\Phi^+_J)$ 之一，$\lfun{\lambda}{z}$ 总不是 0，所以设 $z=wv,\,v\in\barfd$，我们可以得到 $\lfun{\alpha_s}{v}\ne0$ 对任何 $s\in S$ 成立，所以 $v\in\fd\subset\tc^\circ$，从而 $z=wv\in w\fd\subset\tc^\circ$。

于是 $x$ 作为 $z$ 和 $y$ 的非负线性组合 $x = \tfrac{1}{2|W_J|}(z + \delta y)$ 也属于 $\tc^\circ$ [^1]，引理得证。

解决了 $x\in\barfd$ 的情形，一般的情形就好办了：对任何 $x\in\tc$，存在 $w\in W,v\in\barfd$ 使得 $x=wv$。稳定化子群 $\stab{x}$ 与 $\stab{v}$ 是共轭的关系：$\stab{x}=w\stab{v}w^{-1}$，二者同为有限或者无限群，这对应二者是否同为 $\tc^\circ$ 的内点。

## Tits 锥的对偶锥

这一节来讨论 Tits 锥的对偶锥。这部分内容会在后面介绍双曲密铺和球堆时用到。

之前已经提到了，$\barfd$ 是 $\plc{\Delta}$ 在 $V$ 中的对偶锥。但是我们还没有严格介绍什么是对偶锥，所以要补上这一课，介绍一些关于锥的预备知识。

---

### 一些关于锥的预备知识

> **注意**：本段内容中的 $V,V^\ast$ 等均代表一般的实数域上有限维向量空间及其对偶空间，结论也是针对这些一般空间的，请不要与本段之外内容中的 $V,V^\ast$ 对号入座。

在本段中，我们设 $C$ 是 $V$ 中的一个锥，定义 $C$ 的对偶锥 $C^\ast\in V^\ast$ 为
$$C^\ast = \{f\in V^\ast\mid f(v)\geq0,\ \forall v\in C\}.$$
$C^\ast$ 是对偶空间中一些线性泛函组成的集合。

不难看出 $C^\ast$ 也构成 $V^\ast$ 中的一个锥，所以我们又可以取其对偶锥 $C^{\ast\ast}\subset V$。

<div id="theorem4">
{% blockquote %}
**定理 4**：$C^{\ast\ast} = \overline{C}$。其中 $\overline{C}$ 是 $C$ 的拓扑闭包。
{% endblockquote %}
</div>

**证明**：显然 $\overline{C}\subseteq C^{\ast\ast}$，只要论证 $C^{\ast\ast} \subseteq \overline{C}$ 即可。

这个论证可以很简单：对任何 $x\notin\overline{C}$，根据凸集分离定理 [^4]，存在超平面 $H$，其法向量 $n$ 满足 $(n,C)\geq 0$ 但是 $(n,x) < 0$。于是线性泛函 $(n,\cdot)\in C^\ast$ 且由于 $(n,x)<0$ 从而 $x\notin C^{\ast\ast}$。反向包含得证。

---

### 用内积 $\bullet$ 给出对偶锥的描述

回到 Tits 锥的讨论上来。我们有如下定理：

<div id="theorem5">
> **定理 5**：Tits 锥 $\tc$ 的对偶锥为 $\tc^\ast=\bigcap_{w\in W}w(\overline{\plc{\Delta}})$。
</div>

这个定理告诉我们 Tits 锥的对偶锥同样是 $W-$ 不变的。

证明：

$$
\begin{align}
\tc^\ast &=\{f\in V^\ast \mid \lfun{f}{v}\geq 0 \text{ for all } v \in \tc\}\\
&= \{f\in V^\ast\mid \lfun{f}{wv}\geq0 \text{ for all } v\in\barfd \text{ and } w \in W\}\\
&= \{f\in V^\ast\mid \lfun{w^{-1}f}{v}\geq0 \text{ for all } v\in\barfd \text{ and } w \in W\}\\
&= \{f\in V^\ast\mid w^{-1}f\in (\barfd)^\ast \text{ for all } w \in W\}\\
&\stackrel{(\ast)}{=} \{f\in V^\ast\mid w^{-1}f\in \overline{\plc{\Delta}} \text{ for all } w \in W\}\\
&= \{f\in V^\ast\mid f\in w(\overline{\plc{\Delta}}) \text{ for all } w \in W\}.
\end{align}
$$

其中 $(\ast)$ 一步正是将上面对偶锥的结论应用在 $C=\plc{\Delta},\,C^\ast=\barfd$ 上得到的。$\blacksquare$

虽然我们得到了上述 Tits 锥的对偶锥 $\tc^\ast$ 的刻画，但是这个描述并不好用。我们下面用内积的形式给出 $\tc^\ast$ 的一个更好的刻画。

之前提到过，我们可以定义 $V^\ast$ 上的内积 $\bullet$ 为
$$\alpha_s\bullet\alpha_t=c_{s,t}/2=\begin{cases}-\cos\dfrac{\pi}{m_{s,t}}&m_{s,t}<\infty,\\-a_{s,t}&m_{s,t}=\infty.\end{cases}$$
其中 $a_{s,t}$ 是 $\geq1$ 的实数，$C$ 是 Cartan 矩阵。由于 Cartan 矩阵可能是退化的，所以用 $\bullet$ 来定义基本区域 $\cap_{\alpha_s\in\Delta}\{v\mid\alpha_s\bullet v> 0\}$ 是有问题的，但这不影响我们用 $\bullet$ 来给出对偶锥的刻画。

由 $\bullet$ 的定义可见对任何 $\alpha_s\in\Delta$ 有 $\alpha_s\bullet\alpha_s=1$ 都是单位向量。同时不难验证每个反射 $s$ 是 $\bullet$ 下的正交变换：$(s\cdot v)\bullet(s\cdot v)=v\bullet v,\,\forall v\in V$。于是整个 $W$ 也是 $\bullet$ 下的正交变换群。

<div id="prop11">
> **推论 11**：如果 $\lambda\in\plc{\Delta}$ 满足对任何 $\alpha_s\in\Delta$ 有 $\lambda\bullet\alpha_s\leq0$，则 $\lambda\in\tc^\ast$。
</div>

证明：只要证明对任何 $w$ 都有 $w\lambda\in\plc{\Delta}$ 即可。对 $w$ 的长度 $l(w)$ 归纳：$l(w)=0$ 的情形是已知，假设结论对小于 $l(w)$ 的情形已经成立，对 $l(w)$ 的情形可以设 $w=w's$，其中 $l(w')<l(w)$，则 $w'\alpha_s\in\Phi^+$。于是

$$
\begin{align}w\lambda &= w's\lambda\\
&=w'(\lambda - 2(\lambda\bullet\alpha_s)\alpha_s)\\
&=w'\lambda - 2(\lambda\bullet\alpha_s)w'\alpha_s.\end{align}
$$

根据归纳假设 $w'\lambda\in\plc{\Delta}$，以及 $w'\alpha_s\in\Phi^+\subset\plc{\Delta}$，所以结论成立。

<div id="prop12">
> **推论 12**：对任何 $\lambda\in\tc^\ast$ 有 $\lambda\bullet\lambda\leq 0$。
</div>

> 思路：由于 $\tc^\ast$ 是 $W-$ 不变的，以及 $W$ 保持内积 $\bullet$，所以如果某个 $\lambda\in\tc^\ast$ 满足 $\lambda\bullet\lambda>0$，我们就可以将其无限反射下去，并始终保持其内积为正。我们要说明这不可能。

证明：对任何 $v\in V^\ast$，由于 $\Delta=\{\alpha_s\}$ 构成 $V^\ast$ 的一组基，所以 $v$ 可以表示为 $\Delta$ 的线性组合：$v = \sum_{s\in\Delta}c_s\alpha_s$。定义 $S(v)=\sum_{s\in\Delta}c_s$ 为此线性组合中所有系数的和。

下面用反证法，设 $\lambda\in\tc^\ast$ 满足 $\lambda\bullet\lambda>0$，不妨设 $\lambda\bullet\lambda=1$。设 $\lambda=\sum_{s\in\Delta}c_s\alpha_s$，由于 $\lambda\in\tc^\ast\subset\plc{\Delta}$，所以每个 $c_s\geq 0$。取 $M$ 为任一大于等于 $\max\limits_{s\in\Delta}c_s$ 的正数，并记 $|\Delta|=n$。

由于 $1=\lambda\bullet\lambda=\sum_{s\in\Delta}c_s(\lambda\bullet\alpha_s)$，所以至少有一个 $s$ 满足 $\lambda\bullet\alpha_s\geq1/nM$。将 $s$ 作用在 $\lambda$ 上：

$$
s\lambda = \lambda - 2(\lambda\bullet\alpha_s)\alpha_s=(c_s-2(\lambda\bullet\alpha_s))\alpha_s + \sum_{t\ne s}c_{t}\alpha_{t}.
$$

由于 $\tc^\ast$ 是 $W-$ 不变的，所以 $s\lambda\in\tc^\ast$，上面的各项系数仍然非负，其中第一项系数 $0\leq c_s-2(\lambda\bullet\alpha_s)\leq M-2/nM$，其它系数不变。

于是 $s\lambda$ 的各项系数和 $S(s\lambda)\leq S(\lambda)-2/nM$，并且 $s\lambda$ 仍然满足

1. $s\lambda\in\tc^\ast$。
2. $(s\lambda)\bullet(s\lambda)=1$。
3. 其作为 $\{\alpha_s\}$ 的线性组合的所有系数最大值仍然不超过 $M$。

所以我们可以对 $S(s\lambda)$ 重复上面的操作，每次都将系数的和减少至少一个固定的正数 $2/nM$，从而必然在有限次后使得所有系数的和为负数，这就导致了矛盾。

### 有限、仿射、双曲三种几何的 Tits 锥

现在我们用上面得到的对偶锥的结论来分析有限、仿射、双曲三种几何的 Tits 锥结构。

首先我们注意对一个非零向量 $x$，$x$ 和 $-x$ 不能同时属于 Tits 锥的对偶锥 $\tc^\ast$，这是因为 $\tc$ 显然包含 $\Delta$ 的一组对偶基 $\{e_s\}$（即基本区域的顶点集），其中 $\lfun{\alpha_s}{e_t}=\delta_{st}$。$x$ 和 $-x$ 都属于 $\tc^\ast$ 将导致对任何 $s$ 都有 $\lfun{x}{e_s}=0$，这只能是 $x=0$，即 $\tc^\ast\cap(-\tc^\ast)=\{0\}$，于是 $\tc^\ast$ 是一个严格的点锥（pointed cone，即不包含任何一维直线）。

假设 Coxeter 群 $(W, S)$ 是不可约的，那么：

1. 在有限的情形，内积 $\bullet$ 是正定的，满足 $v\bullet v\leq 0$ 的只能是零向量，所以 $\tc^\ast=\{0\}$，这时 Tits 锥是全空间。

2. 在仿射的情形，内积 $\bullet$ 的符号是 $(n-1,0)$，可以证明这时 $\tc\cap -\tc=\{0\}$，于是 $\tc^\ast$ 非空，从而包含某个非零向量 $\lambda$。根据[推论 12](#prop12)，再结合 $\bullet$ 是半正定的，只能是 $\lambda\bullet\lambda=0$。由于 ${\rm rad}(\bullet)$ 是一维的，其它任何 $\tc^\ast$ 中的向量必然与 $\lambda$ 共线，所以 $\tc$ 包含在半空间 $\{\lambda\geq0\}$ 中，且闭包就是 $\{\lambda\geq0\}$。

3. 在双曲的情形，内积 $\bullet$ 的符号是 $(n-1,1)$，这时满足 $v\bullet v\leq0$ 的点构成所谓的光锥，光锥有上下两个分支 $L^+,\,L^-$ 且 $L^+=-L^-$，这两个分支互为对偶锥。$\tc^\ast$ 必然属于其中一个，不妨设为 $\tc^\ast\subseteq L^+$，取对偶以后我们得到 $\overline{\tc}=\tc^{\ast\ast}\supseteq L^-$，即 Tits 锥的闭包 $\overline{\tc}$ 包含 $L^-$。而 $\tc$ 是凸集，所以它包含 $\overline{\tc}$ 的内点 [^3]，从而包含 $L^-$ 的内点 $\{v\in L^- \mid v\bullet v<0\}$。注意 $\tc$ 未必包含 $L^-$ 的边界 $\{v\in L^-\mid v\bullet v=0\}$，这一点从上一篇中 rank 2 时双曲的情形就可以看出来。

# 参考文献

1. [Casselman](https://personal.math.ubc.ca/~cass/) 的一些文章。
2. [Introduction to Coxeter groups](https://www.maths.usyd.edu.au/u/ResearchReports/Algebra/How/1997-6.html). Robert B. Howlett.
3. Howlett, R.B., Rowley, P.J. & Taylor, D.E. On outer automorphism groups of coxeter groups.

[^1]: 对任何 $0<t<1$，$t\tc^\circ$ 和 $(1-t)\tc^\circ$ 都是开集，而两个开集的和还是开集（$A+B = \cup_{a\in A}(a+B)$），所以 $\tc^\circ$ 也是凸集。
[^3]: 一个凸集的内点集和它的闭包的内点集是一样的，网上有很多证明，例如参考 [这里](/papers/sCONVs.pdf)。
[^4]: 对不熟悉凸集分离定理的读者，下面是一点细节补充：设 $u\in\overline{C}$ 是 $\overline{C}$ 中与 $x$ 距离最近的点：$|x-u|=\inf_{z\in \overline{C}}|x-z|$。对任何 $z\in\overline{C}$，考虑线段 $[u,z]$ 上的点与 $x$ 的距离 $$f(t) = |u + t(z-u) - x|,\quad 0\leq t\leq1.$$
$f$ 在 $t=0$ 时取得最小值： $$ |u-x|^2 \leq |u-x|^2 + 2t(u-x, z-u) + t^2|z-u|^2.$$ 即 $$0\leq t\cdot\left(2(u-x,z-u) + t|z-u|^2\right)\leq 2(u-x,z-u) + t|z-u|^2.$$ 令 $t\to0^+$ 可得 $(u-x,z-u)\geq 0$。 这个式子对任何 $z\in\overline{C}$ 成立，特别地取 $z=tu$ 代入有 $$(1-t)\cdot(u-x, u)\geq0.$$ 上式对任何 $t\geq0$ 成立必须只能是 $(u-x, u)=0$。于是不等式 $$(u-x,z-u)\geq 0$$ 可以改写为 $$(u-x,z)\geq0$$ 对任何 $z\in\overline{C}$ 成立。而 $(u-x,x)=-(u-x,u-x)<0$。所以 $u-x$ 即为所求的分离超平面。
