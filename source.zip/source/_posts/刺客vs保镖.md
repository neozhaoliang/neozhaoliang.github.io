---
title: "刺客 vs 保镖"
date: 2019-07-19
categories: [pywonderland 项目]
tags:
  - Billiard ball
  - Dynamic system
  - Reflection
  - Affine Weyl group
  - Lattice
url: "assassin-vs-bodyguards"
---
\newcommand{\barfd}{\overline{D}}

Maryam Mirzakhani 在 2014 年的 [一次报告](https://www.youtube.com/watch?v=tprlQMClSYQ) 中提出了如下的问题：（问题大约在视频的 25 分 50 秒处）

> **问题**：假设平面上有一个正方形的房间，房间的四面墙壁都是光滑的反射镜子，即子弹在碰到墙壁时会按照入射角等于出射角的规律一直反射下去。房间中有一位政要和一个刺客。能否在房间中放置若干名（数目有限）保镖，使得这些保镖可以封死刺客的所有射击角度，从而保护政要不被子弹击中？
>
> 政要和刺客的位置是固定的，但可能是房间中任何两点。

据 [考据](http://www.numdam.org/item/10.5802/aif.2124.pdf)，这个问题曾经在 1989 年列宁格勒的数学竞赛中出现过。不久前通过 [PBS](https://www.youtube.com/watch?v=a7gp9c2p0UQ) 和 [math3ma 的博客](https://www.math3ma.com/blog/is-the-square-a-secure-polygon) 的科普，这个问题又被更多人所了解。如果你还没有看过这个视频和博客的话，我强烈建议你先去观看它们，然后再阅读本文。因为她们讲的真的非常棒，而且是真正面向一般大众的科普！

Greg Egan [进一步讨论了](https://gregegan.net/SCIENCE/Lattices/Lattices.html) 当房间是正三角形和正六边形的情况。他给出的答案是正确的，但是我感觉他对正六边形情形的解释有点让人难懂（Greg Egan 的一贯风格）。

本文是对 math3ma 和 Greg Egan 博客文章的补充。也就是说，我这里不会再给出正方形情形的解答，math3ma 的博客文章已经解释的很好了。但是如果你看完 Greg Egan 的文章以后对正三角形和正六边形的情形还有疑问，这篇文章也许可以帮助你。

本文的代码在 [Github 上](https://github.com/neozhaoliang/pywonderland/tree/master/src/assassin_vs_bodyguards)。这个项目包含了一个交互式的脚本，你可以在窗口中点击并拖拽鼠标来查看刺客射击的轨迹以及保镖的位置：

|   |    |    |
|:---:|:---:|:---:|
| 正方形 | 正三角形 |正六边形|
| <img style="margin:0px auto;display:block" src="/images/polygon-billiard/square_guards.png" height="200"/>   | <img style="margin:0px auto;display:block" src="/images/polygon-billiard/triangle_guards.png" height="200"/>    |  <img style="margin:0px auto;display:block" src="/images/polygon-billiard/hexagon_guards.png" height="200"/>     |

<!--more-->

# 反射和平移

在照镜子的时候，你和自己在镜子中的像的左右是相反的。即镜面反射会改变“手性”。所以任何人不可能经过平移和旋转之后与自己在镜子中的像重合。

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/inception.jpg" width="500"/>

然而不管是旋转还是平移，它们都可以分解成两个反射变换的复合：

1. 两个夹角为 $\theta$ 的镜面反射的复合是一个角度为 $2\theta$ 的旋转。
2. 两个平行且距离为 $d$ 的镜面反射的复合是一个距离为 $2d$ 的平移。

所以偶数次反射等同于若干次旋转和平移，手性不变；奇数次反射等同于若干次旋转和平移后再附加一次反射，手性相反。

观察上面盗梦空间的剧照，小李子位于两个平行的镜子中间，他有无穷多个虚像。这些像是交错出现的：正对着他的像是经过奇数次反射得到的，这些像和他的手性是相反的，它们构成集合 $L_1$；背对着他的像是经过偶数次反射得到的（小李子本人看作 $0$ 次反射的像），这些像和他是可以经过平移以后重合的，它们构成集合 $L_2$。假设两个镜子的距离为 $d$，则同一 $L_i$ 中的像以 $2d$ 为间隔均匀分布在一条直线上。

如果我们想在两个镜子中间放置若干保镖，挡住摄像师从任何角度拍摄到小李子的话，则恰好需要 4 名保镖。他们需要分别挡住小李子本人、小李子在两个镜子中的一次虚像，以及某个二次虚像。

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/parallel.svg" height="400"/>

为什么是 4 呢？假设一个保镖 $G$ 挡住了小李子的某个虚像 $A\in L_i$，$i$ 可以是 1 或者 2。$G$ 的所有虚像也由两个格点组成，每个格点也都是间隔 $2d$ 均匀排列的。根据三角形的相似原理，$G$ 的偶数次反射构成的格点在 $L_i$ 上的投影间距是 $4d$，这些偶数次虚像能挡住 $L_i$ 中一半的格点。另一方面 $G$ 的奇数次反射构成的格点一般来说是无用的（除非狗仔和明星恰好位于某些特殊位置）。所以一个保镖只能挡住 1/4 比例的小李子的虚像。


# 正方形 | 正三角形 | 正六边形

理解正多边形房间情形的第一个关键，是要知道刺客的任何射击轨迹都可以展开为平面上的一条射线。刺客可以击中目标当且仅当这条射线经过政要的某个虚像。这个操作叫做展开 (unfolding)。

反之，我们可以用所谓的折叠 (folding) 操作将从刺客发出的任何射线折叠回房间变成一条射击轨迹。

在讨论数学时，我们用展开操作来将轨迹转化为更容易处理的直线；在编程时，我们用折叠操作来计算任何射线对应的射击轨迹。

当房间是正方形时，政要的所有虚像由 4 个不同的二维格点组成：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/square_lattice.svg" height="350"/>

对于刺客来说，只要朝着任何一个虚像开枪他就能击中目标。因为他和任何虚像之间的连线都可以通过折叠操作变成一条子弹的反射路径：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/square_lattice_with_targets.svg" height="350"/>

在 math3ma 的博客中已经证明了封锁一个二维格点需要 4 名保镖，所以一共需要 4x4=16 名保镖。

当房间是正三角形时，目标的所有虚像由 6 个不同的二维格点组成：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/triangle_lattice.svg" height="350"/>

狗仔队与任何虚像之间的连线都对应一条反射路径：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/triangle_lattice_with_targets.svg" height="350"/>

同样地，封锁每个二维格点需要 4 个保镖，所以总共需要 4x6 = 24 名保镖。

房间是正六边形是一个非常容易产生迷惑的情形。注意到将一个房间绕着一个顶点反射三次回到自身，房间被翻转了，而且标记被移动到了相邻的三角形中：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/chirality.svg" height="350"/>

换句话说，（镜面反射生成的）对称群可以在保持房间本身不变的同时将房间内的点移动到房间中其它的位置，这一点与前面平行镜面、正方形、正三角形的情形是不同的。在那些情形中，任何保持房间不变的群元素必然保持房间中每一个点都不变。

这就导致房间中的一点，在其它房间中可以有 6 个不同的虚像。这取决于射线的方向，沿着不同的射线看过去，可以看到不同的虚像：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/chirality-2.svg" height="350"/>

用群论的语言解释，就是存在多个不同的群元素 $w$ 可以将房间 $H$ 映射为另一个房间 $H'$：$wH=H'$。每一条从 $H$ 到 $H'$ 的射线都给出一个这样的 $w$。不同的 $w$ 可能会导致 $H'$ 中 6 个虚像的排列发生变化。

正六边形有这个不同，是因为正六边形并不是对称群作用下的“基本区域”，相反它包含基本区域（正三角形）的 6 个拷贝。注意到正六边形的镜面集合和正三角形的情形是一样的，都由三组夹角为 120 度的、间隔为 1 的平行线组成。所以它们给出的对称群是一样的这个群实际上是仿射 Weyl 群 $\widetilde{A}_2$。但是每个正六边形的内部会被三个镜面“穿过”，切成 6 个小三角形。所以正六边形的情形基本区域还是正三角形。于是房间中每个点 $p$ 在平面上的像仍然由 6 个不同的二维格点构成 [^1]：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/hexagon_lattice.svg" height="350"/>

在上图中，相同颜色的三角形构成一个格点。

我解释一下图中标号的含义：如果一个正三角形被映射到了另一个具有同样颜色的正三角形，那么它们的标号必然一致。

所以一般情形下目标的虚像仍然由 6 个二维格点组成。封锁每个格点需要 4 名保镖，所以我们仍然需要 4x6=24 名保镖，是这样吗？请看下图：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/24_guards_each_lattice.svg" height="350"/>

我选择了明星的 6 个虚像格点中的一个，用黄色的点标记；刺客与每个虚像连线的中点有一个虚拟保镖，这个虚拟保镖是房间中某个真实保镖（用青色的点标记）的虚像，把这个射线折叠回房间我们可以得到保镖的真实位置。然而即便对同一个保镖，随着他的虚像变化，这个真实位置也可能不同，有 6 种可能，所以封锁这个格点需要 4x6=24 个保镖，封锁全部 6 个格点需要 24x6=144 个保镖！

为什么保镖的数目增加了 6 倍？这是因为每一个虚拟保镖的原像可能来自房间中 6 个位置中的任何一个。即如果我们固定一个保镖 $G$ 并考虑他的所有（偶数次反射）给出的虚像集合 $X$，每条从刺客到某个 $x\in X$ 的射线对应一个群元素 $w_x\in\widetilde{A}_2$，$w_x$ 将 $x$ 映射回真实的房间。当 $x$ 变化时，最终的位置 $w_x\cdot x$ 有 6 种不同的可能。所以保镖的数目要增加 6 倍。

在前面正三角形等情形中，所有 $w_x\cdot x$ 对应的是真实房间中同一个位置。


# 仿射 Weyl 群

利用仿射 Weyl 群的知识，我们可以给出答案背后更准确的解释。

正三角形、正方形、正六边形房间的共同之处，是房间的所有虚像可以密铺整个平面。关于房间墙壁的镜面反射生成的群是一个仿射 Weyl 群 $W$：

1. 在正方形的情形，$W=\widetilde{A}_1\times \widetilde{A}_1$。
2. 在正三角形和六边形的情形，$W=\widetilde{A}_2$。

这两种情形下仿射 Weyl 群可以表示为一个有限二面体群 $D_n$ 和一个格点群 $L$ 的半直积：

1. 在正方形的情形，$\widetilde{A}_1\times\widetilde{A}_1\cong D_2\rtimes\mathbb{Z}^2$。$D_2$ 是两个夹角为 90 度的镜面生成的 4 阶二面体群，也叫做 Klein 群。假设房间是单位正方形，则格点群 $L=\mathbb{Z}^2$ 对应所有房间的顶点，它们到所有镜子的距离都是整数。

2. 在正三角形和正六边形的情形，$\widetilde{A}_2\cong D_3\rtimes L(\Phi^\vee)$。$D_3$ 是正三角的对称群，格点群 $L(\Phi^\vee)$ 是一个记号 (coroot lattice)，表示所有正三角形的顶点。假设所有平行线间距是 1 的话，这些点到所有镜面的距离都是整数。

假设真实房间的对称中心位于原点。任何虚像房间可以按照如下方式得到：首先将有限 Weyl 群作用在真实房间上，把房间原地反射或者旋转一下，然后用格点中的元素平移过去。由于 $D_2$ 和 $D_3$ 分别是 4 阶 和 6 阶群，所以虚像可以分成 4 个或者 6 个格点。

在正四边形或者正三角形的情形，所有房间与 $W$ 的群元素是一一对应的。但是在正六边形的情形，群元素和房间是 6 对 1 的关系：任何 $D_3$ 中的元素作用在真实房间上都保持真实房间不变（非恒等元会变动房间中的点）。然后有一个唯一的平移将它们的中心重合。


[^1]: 严格地说应该是至多 6 个格点。在特殊情况下，比如 $p$ 位于两个正三角形相邻的边上，那么它的虚像由 3 个不同的格点组成。如果 $p$ 位于正六边形的中心，那么它的虚像只构成一个格点。
