---
title: "刺客 vs 保镖"
date: 2019-07-19
categories: [pywonderland 项目]
tags:
  - Billiard ball
  - Dynamic system
  - Reflection
  - Affine Weyl group
  - Lattice
  - Finite blocking property
url: "assassin-vs-bodyguards"
---
\newcommand{\barfd}{\overline{D}}

Maryam Mirzakhani 在 2014 年的 [一次报告](https://www.youtube.com/watch?v=tprlQMClSYQ) 中提出了如下的问题：（问题大约在视频的 25 分 50 秒处）

:::{.question .unnumbered}
假设平面上有一个正方形的房间，房间的四面墙壁都是光滑的反射镜子。子弹在碰到墙壁时会遵循入射角等于出射角的规律无限反射下去。房间中有一位政要和一个刺客，他们的位置是固定的，但可能是房间中任何两点。能否在房间中放置有限数量的保镖，使得这些保镖可以封锁刺客的所有射击角度，从而确保政要不被子弹击中？
:::

根据 [这篇论文](http://www.numdam.org/item/10.5802/aif.2124.pdf) 的考据，这个问题曾经在 1989 年列宁格勒的数学竞赛中出现过。最近，通过 [PBS](https://www.youtube.com/watch?v=a7gp9c2p0UQ) 和 [math3ma 的博客](https://www.math3ma.com/blog/is-the-square-a-secure-polygon) 的科普推广，这个问题又引起了不少人的兴趣。我强烈建议读者在深入阅读本文之前，先观看这些视频和博客。它们的讲解非常通俗易懂，对于普通读者来说非常友好。

Greg Egan 在[他的博客中](https://gregegan.net/SCIENCE/Lattices/Lattices.html) 进一步讨论了房间是正三角形和正六边形的情况。虽然他给出的答案是正确的，但是他对正六边形情形的解释有点让人难以理解（Greg Egan 的一贯风格）。

正方形、正三角形和正六边形是仅有的三种可以用有限多个保镖保护目标的情形，对其它正 $N\,(N\ne3,4,6)$ 边形房间，有限数量的保镖是不行的。（不要问我怎么证，我也不知道）

本文是对 math3ma 和 Greg Egan 博客文章的补充，我将主要针对正六边形的情况进行详细解释。我觉得从仿射 Weyl 群的角度来看这个情形最方便，但这对大多数读者来说可能是个陌生的概念。我还是假定读者知道群的概念，并尽量结合直观的图形来解释。如果读者对深入了解仿射 Weyl 群感兴趣，可以参考 [@Humphreys90 chapter 4]。

本文的代码在 [Github 上](https://github.com/neozhaoliang/pywonderland/tree/master/src/assassin_vs_bodyguards)。这个项目包含了一个交互式的脚本，你可以在窗口中点击并拖拽鼠标来查看刺客射击的轨迹以及保镖的位置：

|   |    |    |
|:---:|:---:|:---:|
| 正方形 | 正三角形 |正六边形|
| <img style="margin:0px auto;display:block" src="/images/polygon-billiard/square_guards.svg" height="200"/>   | <img style="margin:0px auto;display:block" src="/images/polygon-billiard/triangle_guards.svg" height="200"/>    |  <img style="margin:0px auto;display:block" src="/images/polygon-billiard/hexagon_guards.svg" height="200"/>     |

<!--more-->

# 反射和平移

在照镜子的时候，你和自己在镜子中的像的左右是相反的，即镜面反射会改变“手性”。因此无论怎么平移或者旋转，你都无法与自己在镜子中的像完全重合。

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/inception.jpg" width="500"/>

但是如果把镜子中的虚像通过另一面镜子再作一次反射，得到一个二次虚像，那么通过适当的平移或者旋转，你是可以和这个二次虚像完全重合的。这是因为两个反射变换的复合是一个平移或者旋转。具体取决于两个镜子的夹角：

1. 两个相交且夹角为 $\theta$ 的镜面反射的复合是一个角度为 $2\theta$ 的旋转。
2. 两个平行且距离为 $d$ 的镜面反射的复合是一个距离为 $2d$ 的平移。

所以偶数次反射等同于若干次旋转和平移的叠加，手性不变；奇数次反射等同于若干次旋转和平移后再附加一次反射，手性相反。

观察上面盗梦空间的剧照，小李子位于两个平行的镜子中间，他有无穷多个虚像。这些虚像是交错出现的：那些面对他的虚像是经过奇数次反射得到的，这些虚像的手性和他相反，它们构成了集合 $L_1$；那些背对他的虚像是经过偶数次反射得到的（小李子本人看作 $0$ 次反射的像），这些虚像可以经过平移以后和他重合，它们构成了集合 $L_2$。假设两个镜子的距离为 $d$，则每个 $L_i$ 中的虚像以 $2d$ 为间隔均匀分布在一条直线上。

如果我们想在两个镜子中间放置若干保镖，以防止摄像师从任何角度拍摄到小李子，则我们恰好需要 4 名保镖。他们需要分别挡住小李子本人、小李子在两个镜子中的一次虚像，以及某个二次虚像。

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/parallel.svg" height="400"/>

为什么需要 4 名保镖呢？假设一个保镖 $G$ 挡住了小李子的某个虚像 $A$，不妨设 $A$ 来自小李子的奇数次虚像组成的格点 $L_1$。保镖 $G$ 的所有虚像也由两个格点组成，每个格点也都是间隔 $2d$ 均匀排列的。根据三角形的相似原理，$G$ 的奇数次反射构成的格点在 $L_1$ 上的投影间隔是 $4d$，这些投影覆盖了 $L_1$ 中一半的格点。另一方面 $G$ 的偶数次反射构成的格点一般来说是无用的（除非狗仔和明星恰好位于某些特殊位置）。所以保镖 $G$ 只能挡住小李子的所有虚像的 1/4。

同理如果 $G$ 挡住的是小李子的某个偶数次虚像，那么 $G$ 和他的偶数次虚像只能挡住 $L_2$ 中一半的虚像，并且 $G$ 的奇数次虚像是无用的。

# 正方形 | 正三角形 | 正六边形

理解正多边形房间情形的第一个关键，是要知道刺客的任何射击轨迹都可以展开为平面上的一条射线。刺客可以击中目标当且仅当这条射线经过目标的某个虚像。这个操作叫做展开 (unfolding)。

与展开相对的操作是折叠 (folding) ，我们可以用折叠操作将刺客发出的任何射线折叠回房间变成一条射击轨迹。具体做法如下：假设刺客位于点 $p$，虚像位于点 $q$，则线段 $\overline{pq}$ 连接 $p$ 所在的真实房间和 $q$ 所在的虚像房间，并且穿过若干房间的墙壁。记 $\overline{pq}$ 穿过的墙壁依次为 $l_1,\ldots,l_m$，则将 $q$ 依次沿着墙壁 $l_m,\ldots,l_1$ 反射就可以将 $q$ 映射回真实房间。

当房间是正方形时，目标的所有虚像由 4 个不同的二维格点组成，如下图所示：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/square_lattice.svg" height="350"/>

对于刺客来说，他只要朝着目标的任何一个虚像开枪就能击中目标。因为他和任何虚像之间的连线都可以通过折叠操作变成一条子弹的反射路径。

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/square_lattice_with_targets.svg" height="350"/>

在上图中，刺客用红点表示，目标和他的虚像用空心圆表示，保镖是灰色的点。

在 math3ma 的博客中已经证明了封锁一个二维格点需要 4 名保镖，所以一共需要 4 x 4=16 名保镖。

当房间是正三角形时，目标的所有虚像由 6 个不同的二维格点组成：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/triangle_lattice.svg" height="350"/>

同样，刺客与目标的任何虚像之间的连线都对应一条房间内的射击路径：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/triangle_lattice_with_targets.svg" height="350"/>

封锁每个二维格点需要 4 个保镖，所以正三角形的情形总共需要 4 x 6 = 24 名保镖。

正六边形是一个容易产生迷惑的情形。这时目标的虚像仍然由 6 个不同的二维格点构成：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/hexagon_lattice.svg" height="350"/>

所以我们很容易猜测这时仍然需要 4 x 6 = 24 名保镖。

但是注意，沿着不同的路径反射，目标的虚像可以出现在另一个房间中不同的位置：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/chirality-2.svg" height="350"/>

由于光路的可逆性，这个话也可以反过来说，即对虚像房间中的一点，它的原像可能来自真实房间中 6 个不同的位置。具体是哪个位置和反射路径有关，即和刺客与保镖虚像的连线有关。因为沿着每一个这样的连线把保镖的虚折叠回真实房间，保镖最终的位置可能不同。所以保镖数目要乘以 6，即总共需要 4 x 6 x 6 = 144 名保镖。

下图也验证了这一点：

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/24_guards_each_lattice.svg" height="350"/>

我选择了明星的 6 个虚像格点中的一个，用黄色的点标记；刺客与每个虚像连线的中点有一个保镖的虚像，这个虚像来自房间中某个真实的保镖（用青色的点标记）。把射线折叠回房间我们可以得到真实保镖的位置。然而即便对同一个保镖，随着他的虚像变化，这个位置也可能不同，有 6 种可能，所以封锁一个格点就需要 4 x 6 = 24 个保镖，封锁全部 6 个格点需要 144 个保镖！

# 仿射 Weyl 群

从群论的角度可以更好的解释上面的现象。

首先介绍一个记号：设 $\alpha\in\mathbb{R}^2$ 是一个单位向量，我们用 $H_{\alpha,k}$ 表示仿射直线
$$H_{\alpha,k}= \{x\in\mathbb{R}^2\mid (x,\alpha)=k\},\quad k\in\mathbb{Z}.$$
并用 $s_{\alpha,k}$ 表示关于 $H_{\alpha,k}$ 的反射。当 $k=0$ 时我们把 $H_{\alpha,0}$ 简写为 $H_\alpha$，把 $s_{\alpha,0}$ 简写为 $s_{\alpha}$。

正三角形、正方形、正六边形房间的共同之处，是房间的所有虚像可以密铺整个二维平面。而且它们是仅有的具有此性质的正多边形。这背后的原因是，这三种情形下，关于房间墙壁的反射生成的群 $W$ 都是 [仿射 Weyl 群](https://en.wikipedia.org/wiki/Coxeter_group#Affine_Coxeter_groups)。仿射 Weyl 群总是无限群，每个虚像房间都是通过将群元素作用在真实房间上得到的。

1. 在正方形的情形，$W=\widetilde{A}_1\times\widetilde{A}_1$。
2. 在正三角形和正六边形的情形，$W=\widetilde{A}_2$。

实际上在两个平行镜面的情形，尽管房间不是封闭多边形，$W$ 也是仿射 Weyl 群 $\widetilde{A}_1$。

一个重要的事实是，$W$ 总可以分解为一个有限二面体群 $D_n$ 和一个格点群 $L$ 的半直积：
$$W = D_n\ltimes L.$$
其中的 $D_n$ 也是一个有限 Weyl 群，它有一个有限的根系 $\Phi$；$L$ 是 $\Phi$ 的余根格点。

我们分别来考察它们：

在正方形的情形，假设房间 $C=[0,1]\times[0,1]$ 是单位正方形。它的四面墙由两组平行的镜面组成，每组平行镜面生成的反射群是无穷二面体群 $\widetilde{A}_1$。由于这两组镜面互相垂直，所以它们共同生成的反射群是两个 $\widetilde{A}_1$ 的直积，即 $W=\widetilde{A}_1\times\widetilde{A}_1$。

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/a1xa1.svg" height="500"/>

我们来看看怎样把 $W$ 拆成 $W=D_n\ltimes L$ 的形式。

设 $\alpha_1=(1,0),\alpha_2=(0,1)$ 是过原点的两个墙壁的法向量，记 $\alpha_1^\vee=2\alpha_1$ 和 $\alpha_2^\vee=2\alpha_2$。在数学术语中，$\alpha_1^\vee$ 和 $\alpha_2^\vee$ 被称为 $\alpha_1$ 和 $\alpha_2$ 的余根 (coroot)。

记 $s=s_{\alpha_1},t=s_{\alpha_2}$，则反射 $s,t$ 生成的二面体群是 $D_2=\{1,s,t,st\}$。$D_2$ 也叫做 Klein 群 $K_4$。它就是上面直积分解中的 $D_n$。

设 $L=\mathbb{Z}\alpha_1^\vee + \mathbb{Z}\alpha_2^\vee$ 是由余根 $\alpha_1^\vee$ 和 $\alpha_2^\vee$ 生成的二维格点群。在这个正方形的情形，$L$ 就是 $2\mathbb{Z}$。它就是直积分解中的 $L$。

于是我们有
$$\widetilde{A}_1\times\widetilde{A}_1 = D_2\ltimes 2\mathbb{Z}.$$

从而 $W$ 在真实房间 $C$ 上的作用可以分成两步：首先将 $D_2$ 中的某个元素作用在 $C$ 上，得到 $\{C,sC,tC,stC\}$ 之一，然后分别在 $x,y$ 方向上平移偶数的距离。由于 $D_2$ 是 4 阶群，这解释了为什么目标虚像由 4 个格点组成。

正三角形房间的情形是类似的。设经过原点的两面墙的法向量是 $\alpha_1$ 和 $\alpha_2$，它们的夹角是 $-\pi/3$。设 $s=s_{\alpha_1},t=s_{\alpha_2}$ 是它们给出的反射，$\alpha_1^\vee=2\alpha_1$ 和 $\alpha_2^\vee=2\alpha_2$ 分别是 $\alpha_1$ 和 $\alpha_2$ 的余根。则 $W$ 可以表示为 $s,t$ 生成的有限二面体群 $D_3$ 和余根格点 $L=\mathbb{Z}\alpha_1^\vee + \mathbb{Z}\alpha_2^\vee$ 的半直积
$$W=\widetilde{A}_2=D_3\ltimes L.$$
$W$ 在 $C$ 上的作用可以分成两步，首先用 $D_3$ 中的某个元素作用在 $C$ 上，得到环绕原点的 6 个房间 $\{C,sC,tC,stC,tsC,stsC\}$ 之一，然后再将其沿着 $L$ 中的一个格点进行平移。由于 $D_3$ 是 6 阶群，所以目标虚像由 6 个不同的格点组成。

<img style="margin:0px auto;display:block" src="/images/polygon-billiard/a2.svg" height="500"/>

对正六边形的情形，我们可以继续使用上图来分析。注意到正六边形房间给出的反射群和正三角形的情形一样，都是 $\widetilde{A}_2$，因为它们都是由关于所有网格线的反射生成的。所以目标虚像也由 6 个不同的格点组成。任何虚像房间也可以分两步得到：先用 $D_3$ 中的某个元素作用在房间上，再沿着余根格点中的一个向量平移过去。但是，由于房间是正六边形的，而 $D_3$ 保持真实房间不变，只是置换其内部的 6 个正三角形，所以群元素和房间是 6 对 1 的关系！这是一个非常重要的不同，在正方形和正三角形房间的情形，群元素和房间都是一一对应的。

这会导致什么后果呢？我们作如下分析：设 $p$ 是真实房间内的一点，$q$ 是 $p$ 的某个虚像，从而存在 $x\in D_3$ 和 $t\in L$ 使得 $q=x\cdot p + t$。于是 $q$ 所在的格点是
$$q+L=q+\mathbb{Z}\alpha_1^\vee+\mathbb{Z}\alpha_2^\vee.$$
$p$ 并不是真实房间中唯一可以生成 $q+L$ 的点。考虑集合 $S=\{y\cdot p\mid y\in D_3\}$，由于 $D_3$ 保持真实房间不变，所以 $S$ 都是真实房间中的点。对任何 $y\cdot p\in S$，我们用 $xy^{-1}\in D_3$ 作用在上面，得到 $x\cdot p$，然后按照 $L$ 进行平移，就可以得到格点 $q+L$。这就证明了 $p$ 的一个虚像格点**可能** [^1] 来自房间内 6 个不同的位置。所以对一个保镖来说，把刺客和他的虚像格点构成的连线折叠回房间时，随着虚像不同，有 6 个可能的位置。我们需要在每个位置上都放置一名保镖才能保证目标安全。这就是为什么保镖数目要乘以 6。

[^1]: 注意我的用词！我使用的词是**可能**，我想表达的意思是，虽然对任何虚像 $q$，一定有 6 个不同的群元素将 $p$ 映射为 $q$，但是这 6 个群元素未必都能给出实际的光线反射路径，最简单的反例就是绕着一个顶点的三次反射，虽然作为群元素它可以将 $p$ 映射为房间中另一个虚像，但是它并不对应任何实际的光线，因为没有任何光线可以依次穿过这个顶点处的三条边（我们不允许光线经过顶点）。

    <img style="margin:0px auto;display:block" src="/images/polygon-billiard/chirality.svg" height="350"/>
