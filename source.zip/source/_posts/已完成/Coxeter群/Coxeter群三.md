---
title: "Coxeter 群笔记（三）：Tits 锥和它的对偶锥"
categories: [Coxeter Groups]
date: 2021-12-06
url: "coxeter-groups-tits-cone"
---

\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\R}{\mathbb{R}}
\newcommand{\gl}{\mathrm{GL}}
\newcommand{\inn}{(\cdot,\cdot)}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\cone}[1]{\mathrm{cone}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\bartc}{\overline{\tc}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}
\newcommand{\span}{\mathrm{span}}

# Tits 锥

在获得了 $V$ 中关于根系的一些知识后，我们下面转移到 $V$ 的对偶空间 $V^\ast$ 中讨论万花筒的结构。

设 $V^\ast$ 是 $V$ 的对偶空间，我们有一个自然的双线性映射
$$V\times V^\ast\to\R: \lfun{v}{f}= f(v).$$
注意 $\lfun{\,}{}$ 和内积 $\inn$ 的区别：$\lfun{\,}{}$ 是 $V\times V^\ast$ 的自然配对，用尖括号表示；$\inn$ 是 $V$ 上的内积。

$V$ 上的可逆线性变换 $g\in\gl(V)$ 同样作用在 $V^\ast$ 上：对 $f\in V^\ast$，线性泛函 $g\cdot f$ 定义为
$$(g\cdot f)(v) = f(g^{-1} v).$$
为了简便我们省略 $g\cdot f$ 中的 $\cdot$，把它写作 $gf$。

这样定义的目的是为了让 $g$ 保持双线性映射 $\lfun{\,}{}$ 不变：
$$\lfun{gv}{gf} = \lfun{v}{f}.$$
用 $g^{-1}f$ 代替 $f$，我们得到
$$\lfun{gv}{f} = \lfun{v}{g^{-1}f}.$$
特别当 $g=s$ 是一个反射时，由于 $s=s^{-1}$ 所以
$$\lfun{sv}{f} = \lfun{v}{sf}.$$
这种将单个反射在 $\inn{\,}{}$ 两边「跳来跳去」的技巧后面会经常用到。

由于 $V$ 和 $V^\ast$ 互为对偶空间，所以 $\Delta=\{\alpha_s\}$ 是 $V^\ast$ 上的一组线性无关的泛函，定义它们的正半空间的交为
$$\fd = \bigcap_{s\in S}\{x\in V^\ast\mid \lfun{\alpha_s}{x} > 0\}.$$
$\fd$ 总是 $V^\ast$ 中的非空开集，其闭包记作 $\barfd$。你可以把 $\fd$ 理解为万花筒中原像所在的房间，超平面的集合 $\{\alpha_s=0\}$ 是房间的墙壁。$\barfd$ 就是 $\fd$ 加上了房间四周的墙壁。

$W$ 同样作用在 $V^\ast$ 上：
$$\lfun{v}{w f} = \lfun{w^{-1}v}{f}.\quad v\in V,\,f\in V^\ast.$$
在 [上文](/coxeter-groups-root-system/#faithful) 中我们已经证明了 $W$ 忠实地作用在 $V$ 上。不难验证在此定义下，$W$ 也忠实地作用在 $V^\ast$ 上，即如果 $wf=f$ 对任何 $f\in V^\ast$ 成立，则 $w=1$。

::: definition
定义 **Tits 锥**为
$$\tc = \bigcup_{w\in W} w\barfd.$$
Tits 锥 $\tc$ 即为万花筒，它是 $W$- 不变的。
:::

读者可能有疑问为什么 Tits 锥是位于对偶空间中的。一个看起来更自然的想法是，直接把 $V$ 中所有以 $\Delta$ 为法向量的正半空间之交
$$\bigcap_{s\in S}\{v\in V\mid(\alpha_s, v)>0\}$$
作为基本区域 $\fd$。在内积 $\inn$ 非退化时，这样做是可以的，但是在 $\inn$ 退化时，可能会出现 $\fd$ 是空集的问题。我们以仿射 $\widetilde{A_1}$ 为例，它的 Coxeter 矩阵是
$$\begin{pmatrix}1 & \infty\\\infty&1\end{pmatrix}.$$
在 $a_{s,t}=1$ 时它给出的内积的 Gram 矩阵是
$$\begin{pmatrix}(\alpha_s,\alpha_s) & (\alpha_s,\alpha_t)\\(\alpha_t,\alpha_t)& (\alpha_t,\alpha_t)\end{pmatrix} =\begin{pmatrix}1&-1\\-1&1\end{pmatrix}.$$
假设 $v=a\alpha_s+b\alpha_t\in\fd$ 满足 $(v,\alpha_s)>0$ 且 $(v,\alpha_t)>0$，你会发现这要求 $a>b$ 且 $b>a$，不存在这样的 $v$！但是通过区分 $V$ 和 $V^\ast$ 上的作用就可以避免这个问题。因为 $\Delta$ 是一组线性无关的泛函，它们在对偶空间中正半空间的交一定是个非空的拓扑开集。

读者可能注意到了：我们使用了 Tits 锥这个称呼，但 $\tc$ 真的是一个锥吗？这可不显然。要证明 Tits 锥确实是锥，我们需要它的另一种等价刻画。

我们先回顾一下锥的概念：

::: definition
设 $C$ 是某实向量空间的子集。如果对任何 $x\in C$ 和实数 $\alpha\geq0$ 都有 $\alpha x\in C$，就称 $C$ 是一个**锥**。如果 $C$ 还是凸集，就称 $C$ 是**凸锥**。凸锥满足对任何 $x,y\in C$ 和非负实数 $\alpha,\beta\geq0$，$\alpha x + \beta y$ 仍然属于 $C$。
:::

设 $X=\{x_1,\ldots,x_n\}$ 是某实向量空间的有限子集，我们用记号 $\cone{X}$ 表示 $X$ 中元素的所有非负线性组合：
$$\cone{X} = \left\{\sum_{i=1}^n c_ix_i,\, c_i\geq0\right\}.$$
显然 $\cone{X}$ 总是凸锥，并且它还是包含 $X$ 的最小凸锥。

::: {.definition #fundamental-weights}
设 $\Delta^\ast=\{\omega_t\}\subset V^\ast$ 是 $\Delta$ 的一组对偶基，满足 $\lfun{\alpha_s}{\omega_t}=\delta_{st}$，$\Delta^\ast$ 叫做**基本权**。记
$$\Omega=\bigcup_{w\in W}w\Delta^\ast.$$
$\Omega$ 中的元素叫做**权**。
:::

::: {.proposition #fund-cone}
$\barfd=\cone{\Delta^\ast}$。
:::

**证明**：对 $x\in V^\ast$，设 $x=\sum_{t\in S}c_t\omega_t$，注意到对任何 $s\in S$ 有 $\lfun{\alpha_s}{x} = c_s$，所以
$$x\in\cone{\Delta^\ast}\Leftrightarrow c_s\geq0 \text{ for all } s \in S \Leftrightarrow \lfun{\alpha_s}{x}\geq 0 \text{ for all } s\in S \Leftrightarrow x\in\barfd.
$$
$\blacksquare$

:::{.definition}
对任一 $x\in V^\ast$，定义
$$\negf{x}= \{\lambda\in \Phi^+\mid \lfun{\lambda}{x}<0\}.$$
$\negf{x}$ 是正根 $\Phi^+$ 的子集，表示 $x$ 位于哪些「镜子」的背面。
:::

一个显然的事实是，$\barfd$ 位于所有镜子的正面，即 $\barfd=\{x\in V^\ast\mid\negf{x}=\emptyset\}$。房间 $\barfd$ 和它在镜子中的所有虚像构成了 Tits 锥 $\tc$。$\tc$ 中每个点都是 $\barfd$ 中某个点经过有限次反射后得到的。这样我们就得到了 $\tc$ 的另一种刻画：

:::{.theorem #tits-neg-finite}
Tits 锥 $\tc = \{x\in V^\ast \mid |\negf{x}| < \infty\}$。
:::

::: note
这个定理的几何意义是，每个镜子的正面是包含 $\fd$ 的一侧，另一侧是背面，Tits 锥就是那些只落在有限多个镜子背面的点，它们一定经过有限次单反射后变换到 $\barfd$ 中。换言之，Tits 锥中的点使得下面的 `while` 循环可以在有限次后结束：

```python
while dot(x, alpha_s) < 0 for some s in S:
    x = reflect(x, alpha_s)
```

下面的动画展示了 $\Gamma=\Delta(3,3,7)$ 对应的双曲 Coxeter 群的 Tits 锥中反射次数不超过 10 的点：

![](/images/coxeter/337-anim.gif){width=400 .fig}
:::

**证明**：

$\Rightarrow$: 设 $x\in\tc$，则 $x$ 可以表示为 $x=wv$，其中 $w\in W,v\in\barfd$。设 $\lambda\in\Phi^+$，由恒等式
$$\lfun{\lambda}{x}=\lfun{\lambda}{wv}=\lfun{w^{-1}\lambda}{v}$$
有 $\lfun{\lambda}{x}< 0\Rightarrow \lfun{w^{-1}\lambda}{v}<0\Rightarrow w^{-1}\lambda\in\Phi^-$，即 $\negf{x}\subseteq N(w^{-1})$，从而
$$|\negf{x}|\leq |N(w^{-1})|=l(w^{-1})=l(w)<\infty.$$

$\Leftarrow$: 反之若 $|\negf{x}|<\infty$，我们来论证存在 $w\in W$ 使得 $wx\in\barfd$。这里的想法是，每次选择一个单根 $\alpha_s$ 对应的镜面，使得 $x$ 落在这个镜子的背面，然后将 $x$ 关于 $\alpha_s$ 反射过去变到 $\alpha_s$ 的正面，这个操作会将遮挡在 $x$ 和 $\barfd$ 之间的镜子个数严格减少 1。如此这般直到 $x$ 落入 $\barfd$ 为止。

严格的论证如下：

若 $\negf{x}=\emptyset$ 这显然成立，因为这时 $x$ 本身就落在 $\barfd$ 中。当 $\negf{x}\ne\emptyset$ 时，其中一定包含一个单根 $\alpha_s\in\Delta$，于是 $\lfun{\alpha_s}{x}< 0$。考虑 $x$ 关于 $\alpha_s$ 的镜像点 $sx$，$sx$ 位于 $\alpha_s$ 的正面，所以 $\alpha_s\notin\negf{sx}$，从而对任何 $\lambda\in\negf{sx}$，$s\lambda$ 仍然是正根。于是
$$\lambda\in\negf{sx}\Rightarrow\lfun{sx}{\lambda}<0\Rightarrow\lfun{x}{s\lambda}<0\Rightarrow s\lambda\in\negf{x}.$$
$s\lambda\ne\alpha_s$，否则 $\lambda=-\alpha_s$ 与 $\lambda$ 是正根矛盾，所以上式说明$$s\cdot\negf{sx}\subseteq\negf{x}\setminus\{\alpha_s\}.$$
从而 $\negf{sx}$ 的元素个数严格小于 $\negf{x}$。

重复此过程我们可以取一组 $s_{i_1},\ldots,s_{i_k}$ 使得 $y=s_{i_1}\cdots s_{i_k}x$ 满足 $\negf{y}=\emptyset$，从而 $y\in\barfd$，这就证明了结论。$\blacksquare$

:::{.corollary #tits-convex}
Tits 锥 $\tc$ 是凸锥。
:::

**证明**：设 $x, y\in\tc$ 和 $\alpha,\beta\geq0$，我们需要证明 $z=\alpha x+\beta y$ 也属于 $\tc$。但是
$$\negf{z}\subseteq\negf{x}\cup\negf{y},$$
根据 @Pre:tits-neg-finite $\negf{x},\,\negf{y}$ 都有限，所以 $\negf{z}$ 也有限，从而 $z\in\tc$，即 $\tc$ 是凸锥。$\blacksquare$

::: {.corollary}
$\tc=\cone{\Omega}$。
:::

**证明**：由于 $\cone{\Omega}\supset\cone{\Delta^\ast}=\barfd$，以及 $\cone{\Omega}$ 是 $W$- 不变的，所以它包含 $\bigcup_{w\in W}w\barfd=\tc$。

另一方面根据 @Pre:fund-cone，$\tc\supset\barfd\supset\Delta^\ast$，以及 $\tc$ 是 $W$- 不变的，所以
$$\tc\supset\bigcup_{w\in W}w\Delta^\ast=\Omega.$$
而 @Pre:tits-convex 证明了 $\tc$ 是凸锥，所以 $\tc\supset\cone{\Omega}$。$\blacksquare$

接下来我们来讨论 $\tc$ 的内点集 $\tc^\circ$。我们将证明 $\tc^\circ$ 由那些稳定化子群有限的点组成：
$$\tc^\circ = \{x\in V^\ast \mid |\stab{x}| < \infty\}.$$

分两步，我们首先来证明标准椭圆子群 $W_J$ 对应的是 $J$ 中镜面交点的稳定化子群：

:::{.theorem #stabilizer-parabolic-subgroup}
对任何 $x\in\barfd$，记 $J=\{s\in S \mid \lfun{\alpha_s}{x}=0\}$，则 $\stab{x} = W_J$。
:::

::: note
这个定理的含义是，对 $\barfd$ 中的一点 $x$，其稳定化子群 $\stab{x}$ 是一个标准椭圆子群，由那些包含 $x$ 的镜子 $\{\alpha_s\in\Delta \mid \lfun{\alpha_s}{x}=0\}$ 对应的反射生成。
:::

**证明**：

对任何 $s\in J$ 和 $v\in V$ 我们有
$$\lfun{v}{sx} = \lfun{sv}{x}=\lfun{v-2(v,\alpha_s)\alpha_s}{x}=\lfun{v}{x},$$
由 $v$ 的任意性可得 $sx=x$，从而 $W_J\subseteq\stab{x}$。

为了证明反向的包含关系，设 $w\in\stab{x}$，我们从 $w$ 的（任何表达式）最末一个元素开始逐个验证它们属于 $J$。

设 $w=w's$，其中 $s\in S,\,l(w')<l(w)$。则 $l(ws)<l(w)$，于是 $w\alpha_s\in\Phi^-$。我们有
$$0\geq \lfun{w\alpha_s}{x} = \lfun{w\alpha_s}{wx} = \lfun{\alpha_s}{x}\geq0.$$
其中第一个不等号是因为 $w\alpha_s$ 是负根和 $x\in\barfd$。所以 $\lfun{\alpha_s}{x}=0$，即 $s\in J\subset W_J$，从而 $sx=x$，于是 $w'$ 也满足 $w'x=x$。对 $w'$ 重复此论证，便得到 $w$ 的乘积中所有因子都属于 $J$，从而定理得证。$\blacksquare$

:::{.theorem #tits-int-finite-stabilizer}
$x\in\tc^\circ$ 当且仅当 $x$ 在 $W$ 中的稳定化子群是有限群。
:::

**证明**：由于任何 $y\in\tc$ 可以写成 $y=wx$ 的形式，其中 $w\in W,\,x\in\barfd$，所以 $x$ 和 $y$ 的稳定化子群是共轭的：${\rm Stab}(y)=w{\rm Stab}(x)w^{-1}$，二者同为有限群或者无限群；而且 $x,y$ 同时属于或者同时不属于 $\tc^\circ$。所以我们只要论证 $x\in\barfd$ 的情形即可。

而根据 @Pre:stabilizer-parabolic-subgroup，$\stab{x}=W_J$，其中 $J=\{s\in S\mid\lfun{\alpha_s}{x}=0\}$，所以只要证明如下命题即可：

::: {.proposition #fd-finite-stabilizer}
设 $x\in\barfd$，则 $x\in\tc^\circ$ 当且仅当 $W_J$ 是有限群。
:::

**@Pre:fd-finite-stabilizer 的证明**：

$\Rightarrow$：我们的思路是，如果 $x$ 是 $\tc$ 的内点，并且经过 $x$ 的镜面有无穷多个，那么可以在 $x$ 的附近取一点 $z$，$z$ 仍然是 $\tc$ 的内点，使得这无穷多个镜子都挡在基本区域和 $z$ 之间，从而 $\negf{z}$ 是无限集，从而 $z\notin\tc$，导致矛盾。

任取 $y\in\fd$。由于 $x\in\tc^\circ$，所以在线段 $\overline{[y, x]}$ 上我们可以朝着 $x$ 的方向延伸一点点，得到点 $z$，使得 $z$ 仍然位于 $\tc^\circ$ 中。$z$ 可以表示为
$$z=(1-t)x+ty\qquad t<0,$$
于是对所有 $s\in J$ 都有 $\lfun{\alpha_s}{z}=t\lfun{\alpha_s}{y} < 0$ 成立。如果 $W_J$ 是无限群那么标准椭圆子群 $W_J$ 的根系 $\Phi_J=W_J\cdot\{\alpha_s\mid s\in J\}$ 也是无限的，从而 $\negf{z}\supseteq \Phi^+_J$ 是无限集，从而 $z\notin\tc^\circ$，矛盾！

$\Leftarrow$：反之若 $W_J$ 是有限群，仍然任取 $y\in\fd$。

对任何镜面 $s\in S\setminus J$，由于 $x$ 不属于此镜面，所以 $\lfun{\alpha_s}{x}>0$。另一方面对任何 $w\in W_J$，根据 [前文中的结论](/coxeter-groups-root-system#remain-positive-root) $w^{-1}\alpha_s$ 仍然是正根，所以也有 $\lfun{\alpha_s}{wy}=\lfun{w^{-1}\alpha_s}{y}>0$ 成立，于是
$$\delta = \min\left\{\frac{\lfun{\alpha_s}{x}}{\lfun{\alpha_s}{wy}}\,\middle|\, \alpha_s\in S\setminus J,\, w\in W_J\right\}>0$$
是一个正数，将上面的分母乘到左边然后对 $w\in W_J$ 求和，我们有
$$\delta\cdot\lfun{\alpha_s}{\sum_{w\in W_J}wy}\leq \lfun{\alpha_s}{x}\cdot |W_J| < 2\lfun{\alpha_s}{x}\cdot |W_J|.$$

注意到上面这个不等式两边关于 $\alpha_s$ 都是线性的。

对任何 $\lambda\in\Phi^+\setminus\Phi_J^+$，$\lambda$ 可以表示为一些 $\{\alpha_s,\,s\in S\setminus J\}$ 和一些 $\{\alpha_t,\,t\in J\}$ 的非负线性组合。我们已经看到对 $s\in S\setminus J$ 上面的不等式成立，而对任何 $t\in J$，由于 $\sum_{w\in W_J}wy$ 在 $W_J$ 下保持不变，所以根据 @Pre:stabilizer-parabolic-subgroup 可得 $\lfun{\alpha_{t}}{\sum_{w\in W_J}wy}=0$，从而上面的不等式变成了等式（两边都是 0）。把这些 $s\in S\setminus J$ 中的严格不等式和 $t\in J$ 中的等式相加，我们得到将 $\lambda$ 代入 $\alpha_s$ 的位置上述严格不等式仍然成立。

于是对任何 $\lambda\in\Phi^+\setminus\Phi_J^+$ 有
$$\delta\cdot\lfun{\lambda}{\sum_{w\in W_J}wy}< 2\lfun{\lambda}{x}\cdot |W_J|.$$
上面每一个 $\lfun{\lambda}{wy}$ 都是大于 0 的，我们可以只取 $w=1$ 的一项，其余全扔掉，得到
$$\delta\cdot\lfun{\lambda}{y}< 2\lfun{\lambda}{x}\cdot |W_J|.$$
记 $z = 2|W_J|x - \delta y$，我们得到 $\lfun{\lambda}{z}>0$ 对任何 $\lambda\in\Phi^+\setminus\Phi_J^+$ 成立。

另一方面对任何 $\mu\in\Phi_J^+$，由于 $\lfun{\mu}{x}=0$，所以 $\lfun{\mu}{z}=-\delta\lfun{\mu}{y}<0$，于是 $\negf{z}=\Phi_J^+$ 是有限集，从而 $z\in\tc$。

实际上我们有 $z\in\tc^\circ$，这是因为对任何 $\lambda\in\Phi$，$\lambda$ 必然属于 $\pm\Phi^+_J,\pm(\Phi^+\setminus\Phi^+_J)$ 之一，$\lfun{\lambda}{z}$ 总不是 0，所以 $z$ 不落在任何镜面上。设 $z=wv,\,v\in\barfd$，那么
$$\lfun{\alpha_s}{v}=\lfun{w\alpha_s}{wv}=\lfun{w\alpha_s}{z}\ne0$$
对任何 $\alpha_s\in\Delta$ 成立，所以 $v\in\fd\subset\tc^\circ$，从而 $z=wv\in w\fd\subset\tc^\circ$。

现在 $x$ 是 $z$ 和 $y$ 的线性组合 $x = \frac{1}{2|W_J|}(z + \delta y)$。我们来说明 $x$ 也属于 $\tc^\circ$。由于 $z,y\in\tc^\circ$，所以 $\frac{1}{2|W_J|}z, \frac{\delta}{2|W_J|}y\in\tc^\circ$，即存在开集 $A,B$ 满足 $\frac{1}{2|W_J|}z\in A\subset\tc^\circ$，$\frac{\delta}{2|W_J|}y\in B\subset \tc^\circ$，于是 $x\in A+B=\cup_{p\in B}(A+p)$，这是一组开集的并，所以 $x\in\tc^\circ$，@Pre:fd-finite-stabilizer 得证，从而 @Pre:tits-int-finite-stabilizer 得证。$\blacksquare$

# Tits 锥的对偶锥

这一节来讨论 Tits 锥的对偶锥。研究对偶锥对理解 Tits 锥本身的结构也很有帮助。

:::{.definition #dual-cone}
设 $C$ 是 $V$ 中的一个锥，定义 $C$ 的对偶锥 $C^\ast\in V^\ast$ 为
$$C^\ast = \{f\in V^\ast\mid f(v)\geq0,\ \forall v\in C\}.$$
即 $C^\ast$ 是对偶空间中那些在 $C$ 上取值均非负的线性泛函组成的集合。
:::

不难看出 $C^\ast$ 也构成 $V^\ast$ 中的一个锥，所以我们又可以取其对偶锥 $C^{\ast\ast}\subset V$。

:::{.theorem #dual-dual-cone}
$C^{\ast\ast} = \overline{C}$。其中 $\overline{C}$ 是 $C$ 的拓扑闭包。
:::

**证明**：显然 $\overline{C}\subseteq C^{\ast\ast}$，只要论证 $C^{\ast\ast} \subseteq \overline{C}$ 即可。

对任何 $x\notin\overline{C}$，根据凸集分离定理，存在超平面 $H$，其法向量 $n$ 满足 $(n,C)\geq 0$ 但是 $(n,x) < 0$。于是线性泛函 $(n,\cdot)\in C^\ast$ 且由于 $(n,x)<0$ 从而 $x\notin C^{\ast\ast}$。反向包含得证。$\blacksquare$

:::note
对不熟悉凸集分离定理的读者，下面是一点细节补充：设 $u\in\overline{C}$ 是 $\overline{C}$ 中与 $x$ 距离最近的点：$|x-u|=\inf_{z\in \overline{C}}|x-z|$。对任何 $z\in\overline{C}$，考虑线段 $[u,z]$ 上的点与 $x$ 的距离 $$f(t) = |u + t(z-u) - x|,\quad 0\leq t\leq1.$$
$f$ 在 $t=0$ 时取得最小值： $$ |u-x|^2 \leq |u-x|^2 + 2t(u-x, z-u) + t^2|z-u|^2.$$ 即 $$0\leq t\cdot\left(2(u-x,z-u) + t|z-u|^2\right)\leq 2(u-x,z-u) + t|z-u|^2.$$ 令 $t\to0^+$ 可得 $(u-x,z-u)\geq 0$。 这个式子对任何 $z\in\overline{C}$ 成立，特别地取 $z=tu$ 代入有 $$(1-t)\cdot(u-x, u)\geq0.$$ 上式对任何 $t\geq0$ 成立必须只能是 $(u-x, u)=0$。于是不等式 $$(u-x,z-u)\geq 0$$ 可以改写为 $$(u-x,z)\geq0$$ 对任何 $z\in\overline{C}$ 成立。而 $(u-x,x)=-(u-x,u-x)<0$。所以 $u-x$ 即为所求的法向量 $n$。
:::

定义 $\cone{\Delta}$ 为单根系 $\Delta$ 的所有非负系数线性组合：
$$\cone{\Delta} = \left\{\sum_{s\in S}c_s\alpha_s,c_s\geq0\right\}.$$
显然 $\cone{\Delta}$ 是 $V$ 中的一个闭凸锥，它在 $V^\ast$ 中的对偶锥正是基本区域的闭包 $\barfd$：
$$\barfd = \{x\in V^\ast\mid \lfun{v}{x}\geq0,\ \forall v\in\cone{\Delta}\}.$$

回到 Tits 锥 $\tc$ 的讨论上来。由于 $\tc\in V^\ast$ 所以 $\tc^\ast\in V$。我们有如下定理：

:::{.theorem #tits-cone-dual}
Tits 锥 $\tc$ 的对偶锥为 $\tc^\ast=\bigcap\limits_{w\in W}w(\cone{\Delta})$。
:::

:::note
由定理结论可见 Tits 锥的对偶锥同样是 $W$- 不变的。
:::

**证明**：

$$
\begin{align}
\tc^\ast &=\{v\in V \mid \lfun{v}{x}\geq 0 \text{ for all } x \in \tc\}\\
&= \{v\in V \mid \lfun{v}{wz}\geq0 \text{ for all } z\in\barfd \text{ and } w \in W\}\\
&= \{v\in V \mid \lfun{w^{-1}v}{z}\geq0 \text{ for all } v\in\barfd \text{ and } w \in W\}\\
&= \{v\in V \mid w^{-1}v\in (\barfd)^\ast \text{ for all } w \in W\}\\
&\stackrel{(\ast)}{=} \{v\in V \mid w^{-1}v\in \cone{\Delta} \text{ for all } w \in W\}\\
&= \{v\in V \mid v\in w(\cone{\Delta}) \text{ for all } w \in W\}.
\end{align}
$$

其中 $(\ast)$ 一步正是将 @Pre:dual-dual-cone 应用在 $C=\cone{\Delta},\,C^\ast=\barfd$ 上得到的。注意我们使用了 $\cone{\Delta}$ 是闭集这一点：$\cone{\Delta}=\overline{\cone{\Delta}}$。$\blacksquare$

虽然我们得到了上面关于 $\tc^\ast$ 的刻画，但是它并不好用。我们下面用内积的形式给出 $\tc^\ast$ 的一个更好的刻画。

:::{.proposition #dual-cone-dot-neg}
如果 $v\in\cone{\Delta}$ 满足对任何 $\alpha_s\in\Delta$ 有 $(v,\alpha_s)\leq0$，则 $v\in\tc^\ast$。
:::

**证明**：只要证明对任何 $w$ 都有 $wv\in\cone{\Delta}$ 即可。对 $l(w)$ 归纳：$l(w)=0$ 的情形是已知，假设结论对小于 $l(w)$ 都成立，对 $l(w)$ 的情形设 $w=w's$，其中 $l(w')<l(w)$，则 $w'\alpha_s\in\Phi^+$。于是

$$
\begin{align}wv &= w'sv\\
&=w'(v - 2(v,\alpha_s)\alpha_s)\\
&=w'v - 2(v,\alpha_s)w'\alpha_s.
\end{align}
$$

根据归纳假设 $w'v\in\cone{\Delta}$，再结合 $w'\alpha_s\in\Phi^+\subset\cone{\Delta}$，所以结论成立。

:::{.proposition #dual-cone-nonspace}
对任何 $u,v\in\tc^\ast$ 有 $(u,v)\leq 0$。
:::

:::{.note}
我是通过与 [Bob Howlett](https://www.maths.usyd.edu.au/u/bobh/) 的邮件交流学到这个结论的。
:::

**证明**：由于 $\Delta$ 构成 $V$ 的一组基，所以任何 $v\in V$ 可以表示为 $\Delta$ 的线性组合：$v = \sum_{s\in S}c_s\alpha_s$。定义 $S(v)=\sum_{s\in S}c_s$ 为所有系数的和。特别地，当 $v\in\tc^\ast\subset\cone{\Delta}$ 时，每个 $c_s$ 都是非负的，所以 $S(v)\geq0$。

用反证法，设 $u,v\in\tc^\ast$ 满足 $(u,v)>0$，不妨设 $(u,v)=1$。记 $n=|S|$ 和 $M=S(u)$。定义

$$X=\{x\in\tc^\ast\mid S(x)\leq S(v) \text{ and $(z,x)\geq1$ for some $z\in\tc^\ast$ with $S(z)\leq M$}\}.$$

显然 $v\in X$。

记 $\epsilon=2/(nM)$，我们将证明对任何 $x\in X$，都存在 $y\in X$ 使得 $S(y)\leq S(x)-\epsilon$。

对 $x\in X$，设 $z=\sum_{s\in S}z_s\alpha_s\in\tc^\ast$ 满足 $S(z)\leq M$ 和 $(z,x)\geq1$，则
$$(z,x)=\sum_{s\in S}z_s(\alpha_s, x)\geq1.$$
所以必有某个 $\alpha_s$ 使得 $z_s(\alpha_s,x)\geq 1/n$。由于 $z_s\leq S(z)\leq M$，我们有 $(\alpha_s,x)\geq 1/(nz_s)\geq 1/(nM)=\epsilon/2$。

考察
$$y=sx=x-2(x,\alpha_s)\alpha_s.
$$
由于 $x\in\tc^\ast$ 以及 $\tc^\ast$ 是 $W-$ 不变的所以 $y\in\tc^\ast$。又注意到 $S(y)=S(x)-2(x,\alpha_s)\leq S(x)-\epsilon$，所以要证明 $y$ 符合要求，只要再找到某个 $z'\in\tc^\ast$ 满足 $S(z')\leq M$ 和 $(z',y)\geq1$ 即可。

如果 $(z,\alpha_s)<0$，那么 $z'=z$ 就满足要求，因为这时
$$(z,y)=(z,x-2(x,\alpha_s)\alpha_s)=(z,x)-2\underbrace{(x,\alpha_s)}_{\geq\epsilon/2}\underbrace{(z,\alpha_s)}_{<0}>(z,x)\geq1.$$

反之如果 $(z,\alpha_s)>0$，我们来验证 $z'=sz=z-2(z,\alpha_s)\alpha_s$ 满足要求：由于 $z\in\tc^\ast$ 所以 $z'\in\tc^\ast$，并且 $S(z')=S(z)-2(z,\alpha_s)<S(z)$，以及
$$(z', y)=(sz, sx)=(z,x)\geq1.$$

所以从 $v=x$ 开始出发，我们经过有限次后取到 $y\in X$ 使得 $S(y)$ 是负数，这与 $y\in\tc^\ast$ 矛盾。$\blacksquare$

