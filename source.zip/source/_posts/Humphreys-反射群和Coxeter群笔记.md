---
title: "Humphreys《反射群与 Coxeter 群》的一些注解"
categories: [代数]
tags:
  - Humphreys
  - Coxeter group
date: 2023-12-10
urls: "Humphreys-coxeter-notes"
---
\newcommand{\vol}{\mathrm{Vol}}
\newcommand{\L}{\mathcal{L}}
\newcommand{\neg}{\mathrm{Neg}}

@Humphreys90 是学习反射群和 Coxeter 群的标准入门教材，书写的很棒，但是个别地方不太好懂。这里整理了我学习时写的一些注解，希望帮到后来人。

<!--more-->


# 1.5 Generation by simple reflections

这一节证明了整个反射群 $W$ 可以由单反射 $\{s_\alpha\mid\alpha\in\Delta\}$ 生成。

:::{.theorem .unnumbered}
$W$ 可以由 $\{s_\alpha\mid\alpha\in\Delta\}$ 生成。
:::

**证明**：设 $W'$ 是 $\{s_\alpha\mid\alpha\in\Delta\}$ 生成的群。目标是证明 $W'=W$。我们来一步步推理：

1. $W$ 是由全体镜面 $\{s_\beta\mid \beta\in\Phi\}$ 生成的，所以只要证明任何 $s_\beta\in W'$ 即可。
2. 要证明 1，只要证明任何 $\beta\in\Phi$ 可以写成 $\beta=w'\alpha$ 的形式，其中 $w'\in W',\,\alpha\in\Pi$。这样 $s_\beta=w's_\alpha w'^{-1}\in W'$。
3. 要证明 2，只需要分析 $\beta$ 是正根且不是单根的情形，因为 $-\beta = w's_\alpha\alpha$。
4. 如果 $\beta>0$ 但不是单根，设 $\beta=\sum c_s\alpha_s$，那么 $0<(\beta,\beta)=\sum c_s(\beta, \alpha_s)$ 说明一定存在单根 $\alpha_s$ 满足 $(\beta,\alpha_s)>0$。考察 $\gamma=s\beta$。
5. $\gamma$ 仍然是正根，并且 ${\rm ht}(\gamma) < {\rm ht}(\beta)$。如果 $\gamma$ 不是单根，那就一直重复此步骤直到 $\gamma$ 变成单根为止。这个操作一定会在有限次后终止，否则我们会得到一个无穷的、高度严格降低、从而互不相同的正根序列，这与根系是有限集矛盾。
6. 设 $\gamma=s_1\cdots s_r\beta\in\Delta$ 是最终得到的单根，则 $\beta\in W'\Delta$，结论成立。


# 1.6 The length function

设 $\neg(w)$ 是那些被 $w$ 变成负根的正根的集合：
$$\neg(w)=\{\lambda>0\mid w\lambda<0\}.$$
并记 $n(w)=|\neg(w)|$。这一节证明了 $n(w)$ 满足的递推关系。

:::{.note}
在后面 5.4 节中，针对一般的 Coxeter 群证明了长度函数 $l(w)$ 也满足同样的递推关系，从而 $l(w)=n(w)$。但是那里的证明要复杂一些。
:::

首先注意到任何单根 $\alpha\in\Delta$ 必然恰好属于 $\neg(w)$ 或者 $\neg(ws_\alpha)$ 之一，这取决于 $w\alpha$ 是正根还是负根：

+ $w\alpha<0\Rightarrow \alpha\in\neg(w)$。
+ $w\alpha>0\Rightarrow ws_\alpha\alpha<0\Rightarrow \alpha\in \neg(ws_\alpha)$。

另一方面对任何正根 $\gamma\ne\alpha$，$s_\alpha\gamma$ 仍然是正根。从恒等式
$$(ws_\alpha)\gamma < 0\Longleftrightarrow w(s_\alpha\gamma)<0$$
可见 $\gamma\in\neg(ws_\alpha)$ 当且仅当 $\gamma\in\neg(w)$，所 $\gamma\leftrightarrow s_\alpha\gamma$ 给出了 $\neg(ws_\alpha)$ 和 $\neg(w)$ 中除 $\alpha$ 之外的正根的一一对应，所以

$$
n(ws_\alpha)=\begin{cases}n(w)+1 & \alpha\in \neg(ws_\alpha),\\
n(w)-1 & \alpha\in \neg(w).\end{cases}
$$

# 1.7 Deletion and Exchange Conditions

这一节证明了有限反射群必然满足 deletion 和 exchange 条件。开头的定理乍看起来非常不直观，包含了一大堆下标。我来解释下背后的几何直观。

设 $w=s_1\cdots s_r$ 是 $W$ 的任一元素。从基本区域 $C$ 出发，我们有一个 gallery，即一列两两相邻的房间

$$C,\, s_1C,\, s_1s_2C,\, \ldots,\, s_1\cdots s_rC.$$

可以这样理解：记 $w_i=s_1\cdots s_i$，则 $w_{i-1}$ 将相邻的两个房间 $C$ 和 $s_iC$ 映射为另外两个相邻的房间 $w_{i-1}C$ 和 $w_iC$。

不仅如此，由于 $C$ 和 $s_iC$ 之间的墙壁是超平面 $H_i = H_{s_i}$，它在 $w_{i-1}$ 作用下被映射为超平面 $w_{i-1}H_i$，所以 $w_{i-1}C$ 和 $w_iC$ 之间的墙壁是 $w_{i-1} H_i$。即

$$C\stackrel{H_1}{\bigl\lvert} s_1C \stackrel{s_1H_2}{\bigl\lvert} s_1s_2C\stackrel{\quad}{\bigl\lvert}\cdots\stackrel{w_{r-1}H_r}{\bigl\lvert} w_{r}C.$$

:::{.lemma .unnumbered}
表达式 $w=s_1s_2\cdots s_r$ 是既约的，当且仅当上述镜面集合
$$\{H_1,s_1H_2,\ldots,s_1\cdots s_{r-1}H_r\}$$
互不相同。
:::

这个引理的含义是，任何既约单词对应的 gallery 不能两次跨越同一个超平面。

证明见 4.5 小节 simple transitivity。那里仿射的情形和这里的证明是一样的。

如果一个镜子在上述集合中出现两次会发生什么？设 $1\leq i<j\leq r$ 使得
$$s_1\cdots s_{i-1}H_i = s_1\cdots s_{j-1}H_j.$$
两边消去 $s_1\cdots s_{i-1}$ 得到
$$H_i = s_i\cdots s_{j-1}H_j.$$
即
$$s_i = (s_i\cdots s_{j-1})s_j(s_{j-1}\cdots s_i)=(s_i\cdots s_{j})(s_{j-1}\cdots s_i).$$
把右边的 $s_{j-1}\cdots s_i$ 挪到左边来得到
$$s_{i+1}\cdots s_{j-1} = s_i\cdots s_j.$$
这意味着 $s_i\cdots s_j$ 这一段可以用更短的 $s_{i+1}\cdots s_{j-1}$ 来代替，这就是定理 1.7 中的 (c)。

# 1.9 Generators and relations

这一节证明了满足 deletion 条件的群一定是 Coxeter 群。即任何形如
$$s_1s_2\cdots s_r=1$$
的关系，都可以通过形如 $(s_\alpha s_\beta)^{m_{\alpha,\beta}}=1$ 的关系转化为恒等式 $1=1$。

若不然设
$$s_1s_2\cdots s_r=1,\quad r=2q$$
是一个长度最短的反例。这里 $r$ 必须是偶数，因为每个 $\det s_i=-1$。

我们将证明有 $s_1=s_3=\cdots$ 以及 $s_2=s_4=\cdots$ 成立，把上述关系变成 $(s_1s_2)^q=1$，从而得出矛盾。

+ 我们只要证明 $s_1=s_3$ 即可。然后将结论用在 $s_2s_3\cdots s_rs_1=1$ 上得到 $s_2=s_4$；再进一步用在 $s_3s_4\cdots s_rs_2s_1=1$ 上得到 $s_3=s_5$，等等。

+ 为此我们只要证明如下两个等式：

  (I).  $s_1s_2\cdots s_q=s_2s_3\cdots s_{q+1}$.

  (II).  $s_3s_2\cdots s_q=s_2s_3\cdots s_{q+1}$.

  这两个式子几乎是一样的，只有最左边一个是 $s_1$，另一个是 $s_3$。所以如果它们都成立，就有 $s_1=s_3$。

+ 为了证明 I，我们把 $s_1\cdots s_r=1$ 改写为
  $$s_1\cdots s_{q+1} = s_r\cdots s_{q+2}.$$
  左边是 $q+1$ 项的乘积，右边是 $q-1$ 项的乘积，所以 $l(s_1\cdots s_{q+1})\leq q-1$。根据删除条件，存在 $1\leq i<j\leq m+1$ 使得有
  $$s_i\cdots s_j = s_{i+1}\cdots s_{j-1}. \tag{$\ast$}$$
  我们希望说明有 $i=1,j=q+1$ 成立。若不然，则上式至多包含 $2q-2=r-2$ 项，从而可以由 Coxeter 关系 $\{(s_\alpha s_\beta)^{m_{\alpha,\beta}}=1\mid \alpha,\beta\in\Delta\}$ 表达出来。当然和 $(\ast)$ 式等价的
  $$s_1\cdots s_r = s_1\cdots\hat{s_i}\cdots\hat{s_j}\cdots s_r.$$
  也可以从 Coxeter 关系表达出来。但是我们已知
  $$s_1\cdots s_r = s_1\cdots\hat{s_i}\cdots\hat{s_j}\cdots s_r=1.$$
  根据 $r$ 的选取 $s_1\cdots\hat{s_i}\cdots\hat{s_j}\cdots s_r=1$ 可以由 Coxeter 关系得出，从而 $s_1\cdots s_r =1$ 也可以，这导致了矛盾，从而 I 得证。

+ 为了证明 II，将 $s_1\cdots s_r =1$ 改写为 $s_2\cdots s_rs_1=1$，仿照 I 的证明，我们可以得到
  $$s_2\cdots s_{q+1} = s_3(s_4\cdots s_{q+2}).$$
  把 $s_3$ 挪到左边的前面，把 $s_4\cdots s_{q+2}$ 挪到左边的后面，得到
  $$s_3s_2\cdots s_{q+1}s_{q+2}\cdots s_4 = 1.$$
  仍然和 I 的证明同理，我们可以得到
  $$s_3s_2\cdots s_q = s_2\cdots s_{q+1}.$$
  这就是 II 中的等式。

# 4.9 A formula for the order of $W$

从前面的学习中我们知道，一个仿射 Weyl 群 $W_a$ 总是可以写成一个有限 Weyl 群 $W$ 和一个格点群 $L$ 的半直积：$W_a=W\ltimes L$。这里的 $L$ 实际上是 $W$ 的余根格点：$L=L(\Phi^\vee)$。这一节介绍了怎样计算 $W$ 的阶 $|W|$。

我们以 $\widetilde{B}_2$ 为例来说明。$\Delta$ 包含两个单根 $\alpha_1=e_1-e_2,\,\alpha_2=e_2$。最高根 $\widetilde{\alpha}=\alpha_1+2\alpha_2$，于是 $c_1=1,c_2=2$。

<img style="margin:0px auto;display:block" width="500" src="/images/humphreys/b2.svg" />

+ 图中**黄色**区域是由所有的房间 $\{wA_o\mid w\in W\}$ 组成。即 $\Pi=\bigcup_{w\in W}wA_o$。另一个等价的描述是
  $$ \Pi = \{x\in V\mid -1 < (x,\alpha) < 1 \text{ for all } \alpha\in\Phi^+\}.$$
  所以 $\vol(\Pi)= |W|\cdot\vol(A_o)$。$\Pi$ 是余根格点 $L(\Phi^\vee)$ 的基本区域，因为书中已经证明了 $W_a=W\ltimes L$，并且 $A_o$ 是 $W_a$ 作用下的基本区域，所以 $\Pi$ 在 $L$ 的作用下互不相交，并且密铺了整个平面。
+ 图中**绿色**区域是余权格点 $\hat{L}(\Phi^\vee)$ 的基本区域 $\hat{\Pi}$，它是一个平行多面体，由基本余权 $\{\omega_1,\ldots,\omega_n\}$ 张成，并且 $\dfrac{ \vol(\Pi)}{\vol(\hat{\Pi}) } = f$。
+ 基本区域 $A_o$ 是由 $\left\{0,\dfrac{\omega_1}{c_1},\ldots,\dfrac{\omega_n}{c_n}\right\}$ 生成的单纯形，它和 $\{\omega_1,\ldots,\omega_n\}$ 生成的平行多面体 $\hat{\Pi}$ 的体积关系为
  $$\vol(\hat{\Pi}) = n!c_1\cdots c_n\cdot\vol(A_o).$$
+ 综上可得
  $$\dfrac{ \vol(\Pi)}{\vol(\hat{\Pi}) } = \frac{|W|\vol(A_o)}{n!c_1\cdots c_n\cdot\vol(A_o)}=f.$$
  即 $|W| = n!c_1\cdots c_n f$。