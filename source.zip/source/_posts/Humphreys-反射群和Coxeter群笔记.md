---
title: "Humphreys《反射群与 Coxeter 群》的一些注解"
categories: [代数]
tags:
  - Humphreys
  - Coxeter groups
date: 2023-12-10
urls: "Humphreys-coxeter-notes"
---
\newcommand{\vol}{\mathrm{Vol}}
\newcommand{\L}{\mathcal{L}}
\newcommand{\neg}{\mathrm{Neg}}

@Humphreys90 是学习反射群和 Coxeter 群的标准入门教材，书写的很棒，但是个别地方不太好懂。这里整理了我学习时写的一些注解，希望帮到后来人。

<!--more-->


# 1.6 The length function

设 $\neg(w)$ 是那些被 $w$ 变成负根的正根的集合：
$$\neg(w)=\{\lambda>0\mid w\lambda<0\}.$$
并记 $n(w)=|\neg(w)|$。这一节证明了 $n(w)$ 满足的递推关系。这个递推关系和 $l(w)$ 是一样的。

首先注意到任何单根 $\alpha\in\Delta$ 必然恰好属于 $\neg(w)$ 或者 $\neg(ws_\alpha)$ 之一，这取决于 $w\alpha$ 是正根还是负根：

+ $w\alpha<0\Rightarrow \alpha\in\neg(w)$。
+ $w\alpha>0\Rightarrow ws_\alpha\alpha<0\Rightarrow \alpha\in \neg(ws_\alpha)$。

另一方面对任何正根 $\gamma\ne\alpha$，$s_\alpha\gamma$ 仍然是正根。从恒等式
$$(ws_\alpha)\gamma < 0\Longleftrightarrow w(s_\alpha\gamma)<0$$
我们看到 $\gamma\in\neg(ws_\alpha)$ 当且仅当 $\gamma\in\neg(w)$，所 $\gamma\leftrightarrow s_\alpha\gamma$ 给出了 $\neg(ws_\alpha)$ 和 $\neg(w)$ 中不等于 $\alpha$ 的正根之间的一一对应，所以

$$
n(ws_\alpha)=\begin{cases}n(w)+1 & \alpha\in \neg(ws_\alpha),\\
n(w)-1 & \alpha\in \neg(w).\end{cases}
$$

# 4.9 A formula for the order of $W$

从前面的学习中我们知道，一个仿射 Weyl 群 $W_a$ 总是可以写成一个有限 Weyl 群 $W$ 和一个格点群 $L$ 的半直积：$W_a=W\ltimes L$。这里的 $L$ 实际上是 $W$ 的余根格点：$L=L(\Phi^\vee)$。这一节介绍了怎样计算 $W$ 的阶 $|W|$。

我们以 $\widetilde{B}_2$ 为例来说明。$\Delta$ 包含两个单根 $\alpha_1=e_1-e_2,\,\alpha_2=e_2$。最高根 $\widetilde{\alpha}=\alpha_1+2\alpha_2$，于是 $c_1=1,c_2=2$。

<img style="margin:0px auto;display:block" width="500" src="/images/humphreys/b2.svg" />

+ 图中**黄色**区域是由所有的房间 $\{wA_o\mid w\in W\}$ 组成。即 $\Pi=\bigcup_{w\in W}wA_o$。另一个等价的描述是
  $$ \Pi = \{x\in V\mid -1 < (x,\alpha) < 1 \text{ for all } \alpha\in\Phi^+\}.$$
  所以 $\vol(\Pi)= |W|\cdot\vol(A_o)$。$\Pi$ 是余根格点 $L(\Phi^\vee)$ 的基本区域，因为书中已经证明了 $W_a=W\ltimes L$，并且 $A_o$ 是 $W_a$ 作用下的基本区域，所以 $\Pi$ 在 $L$ 的作用下互不相交，并且密铺了整个平面。
+ 图中**绿色**区域是余权格点 $\hat{L}(\Phi^\vee)$ 的基本区域 $\hat{\Pi}$，它是一个平行多面体，由基本余权 $\{\omega_1,\ldots,\omega_n\}$ 张成，并且 $\dfrac{ \vol(\Pi)}{\vol(\hat{\Pi}) } = f$。
+ 基本区域 $A_o$ 是由 $\left\{0,\dfrac{\omega_1}{c_1},\ldots,\dfrac{\omega_n}{c_n}\right\}$ 生成的单纯形，它和 $\{\omega_1,\ldots,\omega_n\}$ 生成的平行多面体 $\hat{\Pi}$ 的体积关系为
  $$\vol(\hat{\Pi}) = n!c_1\cdots c_n\cdot\vol(A_o).$$
+ 综上可得
  $$\dfrac{ \vol(\Pi)}{\vol(\hat{\Pi}) } = \frac{|W|\vol(A_o)}{n!c_1\cdots c_n\cdot\vol(A_o)}=f.$$
  即 $|W| = n!c_1\cdots c_n f$。