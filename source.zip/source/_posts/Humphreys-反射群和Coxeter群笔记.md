---
title: "Humphreys《Reflection groups and Coxeter groups》笔记"
categories: [Coxeter 群]
date: 2020-03-11
url: humphreys-coxeter-notes
---

这个网页是我念 [@Humphreys90] 时的笔记。我会保持更新。