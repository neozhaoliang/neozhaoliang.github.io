---
title: "Humphreys《Reflection groups and Coxeter groups》笔记"
categories: [Coxeter 群]
date: 2020-03-11
url: humphreys-coxeter-notes
---

[@Humphreys90] 是学习反射群和 Coxeter 群的标准入门教材，书写的很棒，但是个别地方不太好懂。本文整理了我学习时的一些注解。本文的记号与 Humphreys 书中保持一致。

<!--more-->