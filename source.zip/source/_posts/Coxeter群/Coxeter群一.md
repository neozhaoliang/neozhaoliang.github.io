---
title: "从 Coxeter 群到双曲球堆（一）：抽象 Coxeter 群与几何实现"
categories: [Coxeter Groups]
date: 2021-12-04
tags:
  - Coxeter group
  - Coxeter matrix
  - Coxeter diagram
  - Vinberg notation
  - Reflection
  - Geometric realization
url: "coxeter-groups-geometric-realization"
---

\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\bartc}{\overline{\tc}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}
\newcommand{\inn}{(\cdot,\cdot)}
\newcommand{\gl}{\mathrm{GL}}

# 抽象 Coxeter 群

设 $S$ 是一个集合，一个基于 $S$ 的 Coxeter 矩阵 $M=(m_{s,t})_{s,t\in S}$ 是一个对称矩阵，其对角线上都是 1，非对角线元素取值范围为 $\{2,3,\ldots,\infty\}$。$|S|$ 叫做 $M$ 的秩 (rank)，在本文中我们只考虑 $|S|<\infty$ 的情形。

任一 Coxeter 矩阵 $M$ 都确定了一个有限表现群 $W$，其生成元为集合 $S$，表现如下：
$$W = \langle s\in S\ |\ (st)^{m_{s,t}}=1\ {\rm if}\ m_{s,t}<\infty\rangle.$$

即 $S$ 作为 $W$ 的生成元，其元素满足的生成关系是：

1. 对任何 $s\in S$ 有 $s^2=1$。
2. 对任何 $s\ne t, m_{s,t}<\infty$ 有**辫关系** (braid relation) $\overbrace{sts\cdots}^{m_{s,t}}=\overbrace{tst\cdots}^{m_{s,t}}$ 成立。（当 $m_{s,t}=\infty$ 时的关系是无用的）

我们称 $(W, S)$ 是一个 **Coxeter 系**，$W$ 是一个**有限生成 Coxeter 群**。

用 Coxeter 矩阵或者群表现的形式来描述一个 Coxeter 群有点不太方便。我们可以用一个有限图 $\Gamma$ 更直观地表示一个 Coxeter 群 $(W,S)$，$\Gamma$ 叫做 $(W,S)$ 的 Coxeter 图：$\Gamma$ 的顶点集就是 $S$，两个顶点 $s,t\in S$ 之间连一条边当且仅当 $m_{s,t}\ne 2$，并且这条边的标号是 $m_{s,t}$。在 $m_{s,t}=3$ 时这个标号通常省略不写。如果 $\Gamma$ 是连通的，就称 $(W,S)$ 是**不可约的**。

::: example
Coxeter 矩阵
$$\begin{pmatrix}1 & 3 & 4\\3&1&\infty\\4&\infty&1\end{pmatrix}$$
对应的 Coxeter 图 $\Gamma$ 是

<img style="margin:0px auto;display:block" width="120" src="/images/coxeter/3-4-inf.svg"/>

$\Gamma$ 是连通的，从而 $W$ 是不可约的。
:::

::: example
Coxeter 矩阵
$$\begin{pmatrix}1 & m & 2\\m&1&2\\2&2&1\end{pmatrix}$$
对应的 Coxeter 图 $\Gamma$ 是

<img style="margin:0px auto;display:block" width="120" src="/images/coxeter/prism.svg"/>

$\Gamma$ 有两个连通分支，从而 $W$ 是可约的。
:::

我们主要关心的是 $\Gamma$ 不可约的情形。这是因为，如果 $\Gamma$ 包含的连通分支个数大于 1，则 $\Gamma$ 可以写成若干连通分支的并： $\Gamma=\Gamma_1\cup\cdots\cup\Gamma_k$，其中任何 $\Gamma_i$ 和 $\Gamma_j$ 之间互相没有边相连，即对任何 $s\in\Gamma_i$ 和 $t\in\Gamma_j$ 有 $m_{s,t}=2$，从而 $st=ts$，于是 $\Gamma_i$ 中的生成元与 $\Gamma_j$ 中的生成元两两交换，这时 $W$ 有直积分解
$$W=W_1\times\cdots\times W_k.$$
其中 $W_1,\ldots,W_k$ 分别是 $\Gamma_1,\ldots,\Gamma_k$ 对应的 Coxeter 群。所以我们只要研究 $\Gamma$ 不可约的情形即可。

还有一种给 $\Gamma$ 的边标号的方式，叫做 Vinberg 记号，允许给 $m_{s,t}=\infty$ 的那些边用 $\leq-1$ 的实数作为标号。比如像下面这样：

<img style="margin:0px auto;display:block" width="120" src="/images/coxeter/level2.svg"/>

作为抽象 Coxeter 群，它和

<img style="margin:0px auto;display:block" width="120" src="/images/coxeter/3-4-inf.svg"/>

是同一个群，但是前者的 $\infty$ 边的标号是 $-1.1$。我们后面会解释，这样做相当于指定了这条边的两个顶点在几何实现中的镜面夹角。在后文中我们也会采用这种记号。

对 $W$ 中的任一元素 $w$，它可能有许多种不同的方式表示为 $S$ 中生成元的乘积。在 $w$ 的所有表示中，长度最短的表示叫做 $w$ 的**既约表示**：即若 $w=s_1s_2\cdots s_k$ 是一个长度为 $k$ 的乘积，且 $w$ 不存在任何长度小于 $k$ 的表示，就称 $s_1s_2\cdots s_k$ 是 $w$ 的既约表示。$w$ 的既约表示可能不唯一，但它们都具有相同的长度。$w$ 的长度 $l(w)$ 就定义为 $w$ 的任意一个既约表示的长度。

$l(w)$ 具有如下的性质：

1. $l(xy)\leq l(x) + l(y)$。
2. $l(w) = l(w^{-1})$。
3. $l(w)=0$ 当且仅当 $w=1$。
4. $l(ws)=l(w)\pm 1$，其中 $w\in W, s\in S$。

前三点都是显然的，只有 4 需要证明。显然 $|l(ws)-l(w)|\leq 1$，所以只要说明 $l(ws)$ 和 $l(s)$ 不相等即可。这一步需要用到自由群的泛性质：

设 $F$ 是由集合 $S$ 生成的 [自由群](https://en.wikipedia.org/wiki/Free_group)，定义群同态 ${\rm sgn}: F\to{\pm1}$ 如下：对自由群 $F$ 的每个生成元 $s\in S$ 定义映射 ${\rm sgn}(s)=-1$，然后将此映射扩充为 $F$ 到 ${\pm1}$ 的群同态。容易验证 $(W,S)$ 的所有生成关系都属于这个同态的核，因此根据 [自由群的泛性质](https://en.wikipedia.org/wiki/Free_group#Universal_property)，${\rm sgn}$ 诱导了一个从 $(W,S)$ 到 ${\pm1}$ 的群同态。在此同态下，若 $w=s_1s_2\cdots s_k$ 是 $w$ 的任一既约表示，则 $${\rm sgn}(w)={\rm sgn}(s_1){\rm sgn}(s_2)\cdots{\rm sgn}(s_k)=(-1)^k=(-1)^{l(w)}.$$ 从而 ${\rm sgn}(ws)={\rm sgn}(w){\rm sgn}(s)=-{\rm sgn}(w)$ 说明 $l(ws)\ne l(w)$。

# 几何实现

抽象 Coxeter 群是用生成元和生成关系定义的，直接从这种定义出发研究群结构是非常困难的。在这一节中，我们将介绍如何将抽象的 Coxeter 群实现为一个内积空间中的正交反射群，从而可以使用几何、线性代数等多种工具来研究它。

设 $(W,S)$ 是一个 Coxeter 系，$M=(m_{s,t})_{s,t\in S}$ 是 Coxeter 矩阵，$V$ 是一个维数为 $n=|S|$ 的实向量空间，其一组基为 $\{\alpha_s \mid s\in S\}$。我们规定 $V$ 上的一个内积 $\inn$ 如下：

$$(\alpha_s,\alpha_t)=\begin{cases}-\cos\frac{\pi}{m_{s,t}}&m_{s,t}<\infty,\\-a_{s,t}&m_{s,t}=\infty.\end{cases}$$

这里 $a_{s,t}\geq 1$，不同的 $(s,t)$ 对可以使用不同的 $a_{s,t}$。

根据定义 $(\alpha_s,\alpha_s)=-\cos\frac{\pi}{1}=1$，即每个 $\alpha_s$ 都是单位向量。

::: note
$a_{s,t}=1$ 表示 Euclidean 空间中两个平行的镜面（或者双曲空间中两个平行的镜面）；$a_{s,t}>1$ 表示双曲空间中两个超平行的镜面；$m_{s,t}<\infty$ 表示两个相交的镜面。

下图显示了对同一个抽象 Coxeter 群

<img style="margin:0px auto;display:block" width="120" src="/images/coxeter/3-4-inf.svg"/>

对标号为 $\infty$ 的边选择 $a_{s,t}=1$ 和 $a_{s,t}=1.15$ 时给出的效果：

| 平行 $a_{s,t}=1$ | 超平行  $a_{s,t}=1.15$ |
|:---:|:---:|
|<img style="margin:0px auto;display:block" width="250" src="/images/coxeter/parallel.png"/>|<img style="margin:0px auto;display:block" width="250" src="/images/coxeter/hypparallel.png"/>|
:::

上面定义的 $\inn$ 未必是通常所指的 Euclidean 内积，而且不同的 $W$ 给出的 $\inn$ 的符号可能是不同的。但我们最关心的情形有三种：

1. 如果 $\inn$ 是正定的，就称 $\inn$ 是有限型的；
2. 如果 $\inn$ 是半正定的，但不是正定的，就称 $\inn$ 是仿射型的；
3. 如果 $\inn$ 的符号是 $(n-1, 1)$，就称 $\inn$ 是双曲型的。

不属于以上三种类型的一律称为不定的。

正如名字所暗示的那样，$\inn$ 是有限型的当且仅当 $W$ 是有限反射群，这时 $W$ 给出的万花筒是球面上的密铺；$\inn$ 是仿射型的当且仅当 $W$ 可以实现为 Euclidean 空间上的仿射 Weyl 群，这时 $W$ 给出的万花筒是 Euclidean 空间中的密铺；$\inn$ 是双曲型的意味着 $W$ 给出的是双曲空间中的密铺。这些我们会在后面进行仔细的讨论。

对任何 $s\in S$，定义 $V$ 上的反射 $\rho_s$ 为
$$\rho_s(v) = v -2(v,\alpha_s)\alpha_s ,\quad v\in V.$$

我们来证明 $s\to\rho_s$ 实际上是从 $(W,S)$ 到 $\gl(V)$ 的群同态，从而
$$\rho: W\to\rho(W)\leqslant\gl(V)$$
是一个线性表示。为此只要证明：

::: Proposition
$(\rho_s\rho_t)^{m_{s,t}}=1$ 对任何 $s,t\in S$ 成立。
:::

这个结论的证明在 [@Humphreys90 section 5.3] 和 @Howlett-note 中都可以找到，但我更喜欢 Howlett 的做法，把 rank 2 情形的根系具体的算出来。因为这是最简单，但又非平凡的根系的例子，熟悉它的重要性怎么强调也不为过。

**证明**：当 $s=t$ 时所证即为 $\rho_s^2=1$，由于 $\rho_s$ 是反射这当然是成立的。

下设 $s\ne t$，令 $V_{s,t}={\rm span}\{\alpha_s,\alpha_t\}$ 是 $\alpha_s,\alpha_t$ 张成的二维子空间，并记 $V_{s,t}^\bot$ 是 $V_{s,t}$ 在 $\inn$ 下的正交补空间。不难验证 $\rho_s$ 和 $\rho_s$ 限制在 $V_{s,t}^\bot$ 上都是恒等变换。

注意不一定有 $V=V_{s,t}\oplus V_{s,t}^\bot$ 成立，因为 $\inn$ 有可能是退化的。但是只要 $\inn$ 非退化，或者 $\inn\mid_{V_{s,t}}$ 是非退化的，那么 $V=V_{s,t}\oplus V_{s,t}^\bot$ 就成立。

我们来计算 $\sigma=\rho_s\rho_t$ 的阶。记 $m=m_{s,t}$，分情况讨论：

:::{.plain #rank2-roots}
:::

1. $m<\infty$。这时 $\inn$ 限制在 $V_{s,t}$ 上的 Gram 矩阵是
$$\begin{pmatrix}1&-\cos\theta\\-\cos\theta&1\end{pmatrix},\qquad \theta=\frac{\pi}{m}.$$
这个矩阵是正定的，从而 $\inn\mid_{V_{s,t}}$ 非退化，这时 $V=V_{s,t}\oplus V_{s,t}^\bot$ 是成立的，而 $\sigma$ 限制在 $V_{s,t}^\bot$ 上是恒等变换，所以 $\sigma$ 在 $V$ 上的阶就等于它在 $V_{s,t}$ 上的阶。我们有 $\rho_s(\alpha_s)=-\alpha_s$ 和 $\rho_s(\alpha_t)=2\cos\theta\alpha_s+\alpha_t$，以及关于 $\rho_t$ 的类似表达式。不难验证有
$$\begin{align*}&\alpha_s\xrightarrow{\ \rho_t\ }\sthe{}\alpha_s+\sthe{2}\alpha_t\xrightarrow{\ \rho_s\ }\sthe{3}\alpha_s+\sthe{2}\alpha_t\xrightarrow{\ \rho_t\ }\sthe{3}\alpha_s+\sthe{4}\alpha_t\xrightarrow{\ \rho_s\ }\cdots\\
&\alpha_t\xrightarrow{\ \rho_s\ }\sthe{2}\alpha_s+\sthe{}\alpha_t\xrightarrow{\ \rho_t\ }\sthe{2}\alpha_s+\sthe{3}\alpha_t\xrightarrow{\ \rho_s\ }\sthe{4}\alpha_s+\sthe{3}\alpha_t\xrightarrow{\ \rho_t\ }\cdots\end{align*}
$$
这两个链的周期都是 $2m$，因为它们的第 $2m+1$ 项分别是
$$\sthe{(2m+1)}\alpha_s+\sthe{(2m)}\alpha_t=\alpha_s$$
和
$$\sthe{(2m)}\alpha_s+\sthe{(2m+1)}\alpha_t=\alpha_t.$$
又回到了各自的第一项。所以 $\sigma$ 的阶等于 $m$。

2. $m=\infty$。这时未必有 $V=V_{s,t}\oplus V_{s,t}^\bot$。但我们可以论证 $\sigma$ 在 $V_{s,t}$ 上的阶是无穷，那么自然它在 $V$ 上的阶也是无穷。
设 $\theta\geq0$ 使得 $a_{s,t}=\cosh\theta$，不难验证有
$$\begin{align*}&\alpha_s\xrightarrow{\ \rho_t\ }\shthe{}\alpha_s+\shthe{2}\alpha_t\xrightarrow{\ \rho_s\ }\shthe{3}\alpha_s+\shthe{2}\alpha_t\xrightarrow{\ \rho_t\ }\shthe{3}\alpha_s+\shthe{4}\alpha_t\xrightarrow{\ \rho_s\ }\cdots\\
&\alpha_t\xrightarrow{\ \rho_s\ }\shthe{2}\alpha_s+\shthe{}\alpha_t\xrightarrow{\ \rho_t\ }\shthe{2}\alpha_s+\shthe{3}\alpha_t\xrightarrow{\ \rho_s\ }\shthe{4}\alpha_s+\shthe{3}\alpha_t\xrightarrow{\ \rho_t\ }\cdots\end{align*}
$$（当 $a_{s,t}=1$ 时 $\theta=0$，$\shthe{k}$ 应当理解为 $k$）

   这两个链条都是永不重复的，所以 $\sigma$ 的阶是无穷。

至此命题得证。$\blacksquare$

:::{.note}
我知道你肯定不喜欢看到这种涉及繁琐计算的证明。但我的经验是，慢就是快。花大量时间在掌握例子上是值得的。
:::


后面我们会看到 $\rho$ 实际是一个同构，这样就把抽象的 Coxeter 群 $W$ 实现为具体的反射群 $\rho(W)$。

最后是一个记号的简化：我们把 $w\in W$ 在 $V$ 上的作用简写为 $wv=\rho(w)(v)$。