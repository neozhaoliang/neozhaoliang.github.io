---
title: "Birkhoff 遍历定理"
date: 2013-04-21
tags:
  - 遍历论
  - Durrett 概率论
  - Ergodic theorem
categories: [Durrett 概率论]
url: "Birkhoff-ergodic-theorem"
---
\newcommand{\ind}{\mathbb{1}}
\newcommand{\F}{\mathcal{F}}
\newcommand{\R}{\mathbb{R}}
\newcommand{\B}{\mathcal{B}}
\newcommand{\E}{\mathbb{E}}
\newcommand{\I}{\mathcal{I}}

这个系列整理自我念 Durrett 的 "Probability: Theory and Examples" 时的笔记。Durrett 的书很棒，但缺点也有，就是证明总是缺少一些为什么要这样处理的解释，看起来很头大。


Birkhoff 遍历定理最初由 Birkhoff 本人在 1931 年发表，原文长达 50 页。随后在 1939 年 K.Yosida (吉田耕作) 和 S.Kakutani (角谷) 利用极大遍历定理给出了一个 10 页的简洁证明，不过他们关于极大遍历定理的证明还是啰嗦了点，后来 Garsia 给出了极大遍历定理的一个仅有寥寥数行的惊人证明，这也是当前大多数教材采用的途径，本文就来介绍这一证明。

<!-- more -->

# 记号与约定


给定一个概率空间 $(\Omega,\mathcal{F},\mu)$，$T:\Omega\rightarrow \Omega$ 是一个可测变换，即对任何 $E\in\mathcal{F}$ 有 $T^{-1}E\in\mathcal{F}$。


{% blockquote %}
**定义 1**： 如果一个可测集 $E$ 满足 $T^{-1}E=E$，就称 $E$ 是一个 $T-$ 不变集合。这里集合的相等指的是不计一个零测集的意义下的相等。不难验证所有的 $T-$ 不变集合
$$\mathcal{I}=\{E\in\mathcal{F}\ |\ T^{-1}E=E\ \}$$
构成 $\mathcal{F}$ 的一个子 $\sigma-$ 代数。
{% endblockquote %}

{% blockquote %}
**定义 2**： 如果对任何可测集 $E\in\mathcal{F}$ 有 $\mu(T^{-1}E)=\mu(E)$，就称 $T$ 是一个保测变换。
{% endblockquote %}

在本文中，$T$ 始终代表一个保测变换。

保测变换有如下性质：

{% blockquote %}
**引理 1**：如果 $f\in L^1(\Omega)$ 是一个可积的随机变量，则
$$\int_\Omega f\,\mathrm{d}\mu=\int_\Omega f\circ T\,\mathrm{d}\mu.$$
{% endblockquote %}

证明就是从集合的示性函数出发：若 $E\in\mathcal{F}$，由于 $\omega\in T^{-1}E\Leftrightarrow T(\omega)\in E\Leftrightarrow(\ind_E\circ T) (\omega)=1$，所以 $\ind_{E}\circ T=\ind_{\{T^{-1}E\}}$，因此
$$\int_\Omega \ind_E\,\mathrm{d}\mu=\mu(E)=\mu(T^{-1}E)=\int_\Omega \ind_{\{T^{-1}E\}}\,\mathrm{d}\mu=\int_\Omega \ind_E\circ T\,\mathrm{d}\mu.$$
从而结论对集合的示性函数成立，进一步由积分的线性性质对任何简单函数也成立，再取极限即得对一般的可积函数结论成立。

{% blockquote %}
**引理 2**： 一个 $\Omega$ 上的随机变量 $X$ 关于 $\mathcal{I}$ 可测，当且仅当有
$$X\circ T=X\quad \text{a.e.}$$
成立。这时我们称 $X$ 是 $T-$ 不变的随机变量。
{% endblockquote %}

这是 Durrett 书中的一道习题，我之前一直觉得它很平凡，其实处理的有问题。这个结论还是需要论证一番的。

证明：$\Rightarrow$: 如果 $X$ 关于 $\mathcal{I}$ 可测，则对任何 $B\in\B(\R^1)$ 有 $X^{-1}B\in\mathcal{I}$，即 $T^{-1}(X^{-1}B) = X^{-1}B$。特别地取 $B$ 形如 $(-\infty, t)$ 我们得到 $\{X\circ T<t\}$ 与 $\{X<t\}$ 是两个在几乎处处意义下相同的集合。所以只要证明如果 $\xi,\,\eta$ 是两个可测函数且对任何实数 $t$，$\{\xi<t\}$ 和 $\{\eta<t\}$ 是两个几乎处处相同的集合，则 $\xi=\eta,\,\mathrm{a.e.}$。若不然，不妨设 $\{\xi>\eta\}$ 具有正测度，则存在有理数 $c$ 使得集合 $\{\xi>c>\eta\}$ 具有正测度，这个集合在 $\{\eta<c\}$ 中，但是不在 $\{\xi<c\}$ 中，这与 $\{\eta<c\}$ 和 $\{\xi<c\}$ 只差一个零测集矛盾。

$\Leftarrow$：如果 $X\circ T=X$ 几乎处处成立，则对任何 $B\in\B(\R^1)$ 有 $X^{-1}B=T^{-1}X^{-1}B$ 几乎处处成立，这说明 $X^{-1}B\in\mathcal{I}$，即 $X$ 关于 $\mathcal{I}$ 可测。

# Birkhoff 遍历定理


设 $f$ 是 $\Omega$ 上的随机变量，对每个整数 $n\geq 1$，令
$$S_n(\omega)= \sum_{k=0}^{n-1} f(T^k(\omega)).$$
我们有如下的定理：

{% blockquote %}
**Birkhoff 遍历定理**：设 $T$ 是概率空间 $(\Omega,\mathcal{F},\mu)$ 上的保测变换，则对任何 $f\in L^1(\Omega)$ 有
$$\lim_{n\to\infty}\frac{S_n}{n}\rightarrow \mathbb{E}[f\,|\,\mathcal{I}]\quad\text{a.e.}$$
{% endblockquote %}

证明 Birkhoff 遍历定理定理的关键是证明如下的极大遍历定理：

{% blockquote %}
**极大遍历定理**：定义极大算子
$$M_f(\omega)=\sup_{n\geq 1}\frac{1}{n}S_n(\omega),$$
则对 $f\in L^1(\Omega)$ 和任一 $a\in\mathbb{R}$，有
$$\int_{\{M_f>a\}} f\,\mathrm{d}\mu\geq a\mu(\{M_f>a\}).$$
{% endblockquote %}

极大遍历定理这个名字来源于分析中的 Hardy - Littlewood 极大函数，这一类的不等式统称为极大不等式。我们把极大遍历定理的证明放在最后，先用它来证明 Birkhoff 遍历定理。


# Birkhoff 遍历定理的证明


首先可以假定 $\E[f\,|\,\I]=0$，若不然，我们可以以 $f-\E[f\,|\,\I]$ 代替 $f$，注意到 $\E[f\,|\,\I]$ 是 $T-$ 不变的，所以根据上面的引理 2 有 $\E[f\,|\,\I]\circ T^k = \E[f\,|\,\I],\mathrm{a.e.}$ 对所有的正整数 $k$ 都成立，这时定理的命题左边 $S_n$ 中每一项都会多出来一个 $\E[f\,|\,\I]$，除以 $n$ 正好和右边的 $\E[f\,|\,\I]$ 抵消掉。

这样问题变成在 $\E[f\,|\,\I]=0$ 的条件下证明
$$\lim\limits_{n\to\infty}\frac{S_n}{n}=0.\quad \text{a.e.}$$
设 $a$ 是任一正数，考虑集合
$$A= \{\omega\ |\ \varlimsup_{n\to\infty}\frac{S_n}{n}>a\}.$$
我们想证明 $\mu(A)=0$。若真如此，则有 $\varlimsup\limits_{n\to\infty}S_n/n\leq a$ 几乎处处成立，根据 $a$ 的任意性就得到 $\varlimsup\limits_{n\to\infty}S_n/n\leq 0$ 几乎处处成立。再把这个结果用在 $-f$ 上就得到 $\varliminf\limits_{n\to\infty}S_n/n\geq 0$ 也几乎处处成立，这样就证明了 $\lim\limits_{n\to\infty}S_n/n=0$ 几乎处处成立。

但是请注意 $\varlimsup\limits_{n\to\infty}$ 和 $\sup\limits_{n\geq 1}$ 的区别，它们定义的是两个不同的随机变量。我们要估计的 $A$ 是用 $\varlimsup\limits_{n\to\infty}$ 定义的，而极大遍历定理中说的是 $\sup\limits_{n\geq 1}$。注意到
$$A=\{\varlimsup_{n\to\infty}\frac{S_n}{n}>a\}\subseteq \{ \sup_{n\geq 1}\frac{S_n}{n}>a\}= \{M_f>a\},$$
所以只要证明这样一个结论就好了：

> 设 $A\subseteq \{M_f>a\}$ 而且 $A$ 是一个 $T-$ 不变集合，那么极大遍历定理仍然成立：
$$\int_A f\,\mathrm{d}\mu\geq a\mu(A).$$

而这只要对函数 $g=f\cdot\ind_A$ 应用极大遍历定理即可：
$$\int_{\{M_g>a\}} f\cdot\ind_A\,\mathrm{d}\mu\geq a\mu(\{M_g>a\}).$$
但是 $M_g=M_f\cdot\ind_A$，这一点要用到 $A$ 是 $T-$ 不变集合这个条件，请自行验证，因此
$$\{M_g>a\}=\{M_f>a\}\cap A =A.$$因此确实有
$$\int_A f\,\mathrm{d}\mu\geq a \mu(A),$$
这样就证明了 Birkhoff 遍历定理。

实际上定理中的收敛也是一个依 $L^1$ 范数的收敛，这点的证明相比几乎处处收敛就容易多了，这里不再赘述。

最后来证明极大遍历定理。


# 极大遍历定理的证明


只要证明 $a=0$ 的情形，然后对一般的 $a$，将结论应用在函数 $f-a$ 上即可。定义 $S_0=0$ 以及 $M_n =\max\{S_0,S_1,\cdots,S_n\}$。对每个 $k=1,\ldots,n$ 有
$$S_k=f+S_{k-1}\circ T\leq f+M_n \circ T.$$
从而
$$\max_{1\leq k\leq n}S_k\leq f+M_n \circ T.$$

但是在集合 $\{M_n>0\}$ 上，$M_n$ 作为 $S_0,S_1,\ldots,S_n$ 中的最大者肯定不能来自 $S_0=0$，所以 $M_n=\max\limits_{1\leq k\leq n}S_k$，因此
$$M_n\leq f+M_n \circ T,\quad \omega\in \{M_n>0\}.$$
注意 $M_n$ 总是非负的随机变量，从而
$$\begin{align*}\int_{\{M_n>0\}} f &\geq \int_{\{M_n>0\}}M_n -\int_{\{M_n>0\}}M_n\circ T\\ & = \int_\Omega M_n- \int_{\{M_n>0\}}M_n\circ T\\&\geq \int_\Omega M_n-\int_\Omega M_n\circ T\\&=0.\end{align*}$$
最后由于 $\{M_n>0\}\uparrow \{M_f>0\}$，所以由控制收敛定理即可得到
$$\int_{\{M_f>0\}}f\geq 0,$$
极大遍历定理得证。