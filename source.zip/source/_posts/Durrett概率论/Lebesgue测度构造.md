---
title: "Lebesgue-Stieltjes 测度的构造"
date: 2010-09-08
tags:
  - Durrett probability
  - Lebesgue-Stieltjes measure
  - measure extension
categories: [Durrett 概率论]
url: "lebesgue-stieltjes measure"
---
\newcommand{\ind}{\mathbb{1}}
\newcommand{\F}{\mathcal{F}}
\newcommand{\R}{\mathbb{R}}
\newcommand{\B}{\mathcal{B}}
\newcommand{\D}{\mathcal{D}}
\newcommand{\E}{\mathbb{E}}
\newcommand{\I}{\mathcal{I}}
\newcommand{\aeq}{\stackrel{\mathrm{a.e.}}{=}}

这篇文章我想谈谈 Lebesgue-Stieltjes 测度的构造。这是测度论中的基本内容，这方面的文章在网上俯拾皆是，所以写这种内容的时候我都会很小心，一定要在开头说明为什么我也要来上一篇，并且尽量和其它人的讲述有所区别，避免变成抄书。

我写本文的主要原因是，Lebesgue-Stieltjes 测度的构造过程没有那么复杂，但是网上绝大多数文章都又臭又长，先罗列一堆 $\pi$ 系，半代数，代数和 $\sigma$ 代数的定义，中间塞上一大堆命题，人为把过程拉的很长。要是再遇上爱用花体字的作者，那感觉真是酸爽。

另一个原因是，绝大多数文章都把测度构造的最后一步，Carathéodory 定理作为重点来讲。我不否认这个定理的重要意义，而且它证明起来确实挺长。但是我认为，同样重要的事情是说清楚 Carathéodory 定理所依赖的前提 --- 代数上的可数可加测度是怎么来的。这个据我所见大部分文章这一点上做的都不太好。@Durrett2019 的书虽然写了这一步的证明，但是我认为他在启发性上做的并不好。

没有必要搞得那么正式，我们直接开始。

<!--more-->

# 目标

设 $F$ 是 $\R$ 上的任一**单调递增**、**右连续**的函数，我们将在 $\R$ 上构造一个测度 $(\R,\F,\mu)$，使得它满足对任何左开右闭区间 $(a,b]$ 有
$$\mu((a,b])=F(b)-F(a),\quad -\infty \leq a \leq b \leq \infty.$$

$\F$ 是 Lebesgue 可测集，$\mu$ 是 $\F$ 上的可数可加测度。$(\R,\F,\mu)$ 叫做 Lebesgue-Stieltjes 测度。由于 Lebesgue 可测集是 Borel 可测集加上零测集，所以我们只要在 $\B(\R)$ 上构造 $\mu$ 即可。


# 第一步：左开右闭区间族

我们记 $\I$ 是所有左开右闭的区间构成的集合：

$$\I = \{ (a,b] \mid -\infty\leq a \leq b \leq \infty\}.$$

并定义函数 $\mu:\I\to\R$ 为
$$\mu((a,b])=F(b)-F(a),\quad (a,b]\in\I.$$

现在 $\mu$ 只是一个函数，它还远远不是一个测度。

对任何 $I_1,I_2\in\I$，显然 $I_1\cap I_2\in I$，即 $\I$ 对交运算是封闭的，满足这种条件的集合族叫做 **$\pi$ 系**。

$\I$ 还满足两个性质：对任何 $I_1,I_2\in\I$，$I_1\setminus I_2$ 可以表示为 $\I$ 中若干区间的不交并（实际是至多两个）。

# 第二步：左开右闭区间族的有限不交并

我们考虑从 $\I$ 中取有限多个互不相交的区间，然后求并集得到的所有可能的集合构成的集合族：

$$\D=\{I_1\uplus I_2\uplus\cdots\uplus I_n\mid I_1,I_2,\ldots,I_n\in \I\}.$$

显然 $\I\subset \D$。

我们可以将 $\mu$ 进一步扩张为 $\D$ 上的函数：对任一 $D=\uplus_{i=1}^n I_i$，定义
$$\mu(D) = \sum_{i=1}^n \mu(I_i).$$

这个定义的问题在于合理性：因为 $D$ 可以有多种不同的方式表示成 $\I$ 中区间的不交并。设 $D=\uplus_{k=1}^m J_k$ 是另一种表示方式，我们来说明有
$$ \sum_{i=1}^n \mu(I_i) =  \sum_{k=1}^m \mu(J_k).$$
从而 $\mu$ 在 $\D$ 上的定义是合理的。为此只要注意到
$$I_i = I_i\cap D = \uplus_{k=1}^m I_i\cap J_k.$$