---
title: "Coxeter 群笔记（四）：有限、仿射、双曲三种情形的 Tits 锥"
categories: [Coxeter Groups]
date: 2021-12-07
url: "coxeter-groups-three-cases"
---

\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\R}{\mathbb{R}}
\newcommand{\gl}{\mathrm{GL}}
\newcommand{\inn}{(\cdot,\cdot)}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\cone}[1]{\mathrm{cone}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\bartc}{\overline{\tc}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}
\newcommand{\span}{\mathrm{span}}
\newcommand{\rad}{\mathrm{rad}}
\newcommand{\Q}{\mathcal{Q}}
\newcommand{\N}{\mathcal{N}}
\newcommand{\cl}[1]{\overline{ #1 }}

书接 [上回](coxeter-groups-tits-cone)，本文来研究当 $W$ 分别是有限、仿射和双曲三种情形时，其 Tits 锥 $\tc$ 和对偶锥 $\tc^\ast$ 的结构。我们约定 $(W,S)$ 总是一个有限生成、不可约的 Coxeter 系。

# 有限

关于 Coxeter 群的一个熟知的结论是，$W$ 是有限群当且仅当内积 $\inn$ 是正定的 [见 @Humphreys90 section 6.4]。我这里略过对此结论的证明（否则会让我们的篇幅拉的太长）。我们来证明这还等价于 $\tc=V^\ast$：

:::{.theorem #finite-tits-V}
Tits 锥 $\tc=V^\ast$ 当且仅当 $W$ 是有限群。
:::

:::{.example}
在下图中，$W$ 是正二十面体群 $H_3$，红色的锥是基本区域，它在 $W$ 的作用下铺满了整个空间，所以 $\tc=\mathbb{R}^3$。$\tc$ 与球面的交给出球面上的密铺。

![](/images/coxeter/Tits_finite.png){.fig width=350}
:::

**证明**：

$\Rightarrow$: $\tc=V^\ast$ 当然可以推出 $-\fd\in\tc$（$\fd$ 是基本区域），而对任何 $x\in-\fd$ 都有 $\Phi^+\subseteq \negf{x}$，根据前文得到的 [Tits 锥的刻画](/coxeter-groups-tits-cone/#tits-neg-finite)，$|\Phi^+|=|\negf{x}|<\infty$，从而 $\Phi^+$ 是有限集，从而 $\Phi$ 也是有限集。根据我们在根系一文中证明过的另一个 [结论](/coxeter-groups-root-system/#w-phi-both-finite-infinite)，$W$ 是有限群。

$\Leftarrow$: $W$ 是有限群说明 $\Phi$ 也是有限的，从而对任何 $x\in V^\ast$ 都有 $|\negf{x}|\leq |\Phi^+|<\infty$，从而 $x\in\tc$。$\blacksquare$

我们还需要另一种 $W$ 有限的刻画方式，它在后面分析仿射和双曲的情形时会用到。

:::{.proposition #phi-J-finite}
设 $W$ 是不可约 Coxeter 群。如果存在 $J\subsetneqq S$ 使得 $\Phi\setminus\Phi_J$ 是有限集，则 $W$ 必然是有限群。
:::

**证明**：由于 $J\subsetneqq S$ 所以 $\Phi\setminus\Phi_J$ 是非空的。我们考虑 $W$ 的 Coxeter 图 $\Gamma$：由于 $W$ 不可约，所以对任何 $s\in S$ 都存在一条连接 $s$ 和 $S\setminus J$ 的路径：即存在 $s_0,s_1,\ldots,s_m$ 使得
$$s_0=s\sim s_1\sim\cdots\sim s_m\in S\setminus J.$$
我们称 $m$ 为这条路径的长度。所有这样的路径的最短长度是 $s$ 和 $S\setminus J$ 之间的图距离，记作 $d(s)$。于是 $d(s)=0$ 当且仅当 $s\in S\setminus J$。

我们按照 $d(s)$ 的升序对 $S$ 重新排序，得到 $S=\{s_1,s_2,\ldots,s_n\}$，使得对任何 $i<j$ 都有 $d(s_i)\leq d(s_j)$。于是 $S\setminus J$ 中的顶点都排在最前面，即存在 $1\leq r<n$ 使得 $$S\setminus J=\{s_1,\ldots,s_r\}.$$
然后把 $\Phi^+$ 拆成 $n$ 个不相交集合的并：记 $\Phi_i^+$ 是所有可以由 $\{\alpha_i,\ldots,\alpha_n\}$ 张成，且 $\alpha_i$ 项系数不为 0 的正根组成的集合：
$$\Phi_i^+=\{\lambda\mid \lambda\in\Phi^+,\ \lambda=\sum_{j=i}^nc_j\alpha_j,\ c_i\ne 0\}.$$
则不难看出有 $\Phi^+=\Phi_1^+\cup\cdots\cup\Phi^+_n$，以及 $\Phi^+\setminus\Phi_J^+=\Phi_1^+\cup\cdots\cup\Phi^+_r$。由于假设了 $\Phi\setminus\Phi_J$ 是有限的，所以 $\Phi_1^+,\ldots,\Phi^+_r$ 都是有限的。

我们用归纳法依次论证 $\Phi^+_{r+1},\ldots,\Phi^+_{n}$ 也都是有限集：设 $r+1\leq i\leq n$ 且已知对所有 $j<i$，$\Phi_1^+,\ldots,\Phi^+_j$ 都是有限集，
现在观察 $\Phi^+_i$，注意必然有 $d(s_i)\geq1$，所以存在 $j<i$ 使得 $d(s_j)<d(s_i)$ 且 $s_j\sim s_i$。集合 $s_j\Phi_i^+$ 仍然都是正根，并且它们的 $\alpha_j$ 项系数都不是 0，从而 $s_j\Phi_i^+\subset\Phi^+_j$，于是 $|\Phi_i^+|\leq |\Phi^+_j|$ 从而也是有限集。

于是所有 $\Phi^+_1,\ldots,\Phi^+_n$ 都是有限集，从而 $\Phi$ 也是有限的。由于 [$W$ 和 $\Phi$ 同为有限或者无限](/coxeter-groups-root-system/#w-phi-both-finite-infinite)，所以 $W$ 是有限群，命题得证。$\blacksquare$

@Pre:phi-J-finite 有如下的推论：

:::{.corollary #tits-cone-pointed}
如果 $W$ 不可约且是无限群，则 Tits 锥 $\tc$ 满足 $\tc\cap-\tc=\{0\}$，从而 $\tc$ 是一个点锥 (pointed cone)。
:::

**证明**：由于
$$\tc\cap-\tc=\bigcup_{w_1,w_2\in W}w_1\barfd\cap w_2(-\barfd),$$
所以若 $\tc\cap-\tc\ne\{0\}$ 则存在非零向量 $x\in\barfd$ 和 $w\in W$ 满足 $-wx\in\barfd$。令
$$J=\{s\in S\mid \lfun{\alpha_s}{x}=0\},$$
则 $x\ne 0$ 说明 $J\subsetneqq S$ 是真子集，且对任何 $\lambda\in\Phi^+\setminus\Phi^+_J$ 都有 $\lfun{\lambda}{x}>0$，并且对这样的 $\lambda$ 有
$$\lfun{w\lambda}{-wx} = \lfun{\lambda}{-x}<0.$$
而 $-wx\in\barfd$，所以 $w\lambda$ 是负根，从而 $\Phi^+\setminus\Phi^+_J\subset\negf{w}$，从而
$$|\Phi^+\setminus\Phi^+_J|\leq |\negf{w}|=l(w)<\infty.$$
由 @Pre:phi-J-finite $W$ 是有限群，这与已知矛盾。$\blacksquare$

:::{.corollary #dual-cone-non-trivial}
如果 $W$ 不可约且是无限群，则对偶锥 $\tc^\ast\ne\{0\}$。
:::

**证明**：用反证法，若不然，则 $\bartc=\tc^{\ast\ast}=V^\ast$ 是全空间。由于一个凸集的内点和它的闭包的内点集相同（证明见这个 [附件](/papers/sCONVs.pdf)），所以 $\tc=V$，这与 @Pre:tits-cone-pointed 的结论 $\tc$ 是点锥矛盾。$\blacksquare$

# 仿射

在本节中，我们需要如下关于不可约仿射 Coxeter 群的事实 [见 @Humphreys90 section 2.6, 6.5]。

::: {.simple #affine-facts}
设 $W$ 是不可约、仿射 Coxeter 群，则：

1. $\rad(V)$ 的维数是 1，它由一个向量 $\delta=\sum_{s\in S}z_s\alpha_s$ 生成，其中每个 $z_s>0$。
2. $\delta$ 的坐标 $z=(z_1,\ldots,z_s)^T$ 满足 $Az=z^TAz=0$，其中 $A=((\alpha_s, \alpha_t))_{s,t\in S}$ 是内积 $\inn$ 的 Gram 矩阵。
3. $w\delta=\delta$ 对所有 $w\in W$ 成立。
4. $A$ 的任何 $\leq n-1$ 阶主子式都是正定的。
:::

我们花点笔墨解释一下这几个事实的含义。回忆 $W$ 称作仿射是指内积 $\inn$ 是半正定但不是正定的。这个定义中没有要求 $\inn$ 的符号中有几个 0，但是上面的结论 1, 2 告诉我们，在 $W$ 不可约的前提下，$\inn$ 的符号中有且只有一个 0，并且 $\rad(V)$ 由一个向量 $\delta$ 生成。$\delta$ 的所有系数都非零并且同号，并且 $W$ 保持 $\delta$ 不动。

我们可以利用 1, 2 来快速验证一下 3。由 $z^TA=0$ 可得对任何 $t\in S$ 有
$$\sum z_s(\alpha_s,\alpha_t)=(\delta,\alpha_t)=0.$$
从而 $t(\delta)=\delta-2(\delta,\alpha_t)\alpha_t=\delta$，即任何单反射保持 $\delta$ 不动，从而 $W$ 保持 $\delta$ 不动。

4 说的是对任何 $I\subsetneqq S$，标准椭圆子群 $W_I$ 都是有限群；或者等价地，从 $W$ 的 Coxeter 图 $\Gamma$ 中删去至少一个顶点以后，剩下的子图是有限的。

:::{.theorem #tits-cone-affine}
在仿射的情形 $\tc^\ast$ 是一条射线：$\tc^\ast=\{c\delta\mid c\geq0\}$，Tits 锥是以 $\delta$ 为法向量的半空间加上原点：$\tc=\{0\}\cup\{\delta > 0\}$。
:::

:::{.example}
在下图中，$W$ 是仿射 $\widetilde{A}_2$，红色的锥是基本区域，它在 $W$ 的作用下铺满了整个上半空间，所以 $\tc=\{z>0\}\cup\{0\}$。$\tc$ 与平面 $z=1$ 的交给出二维的 Euclidean 密铺。

![](/images/coxeter/Tits_affine.png){.fig width=350}
:::

**证明**：我们已经知道 $\rad(V)=\R\delta$。根据 @Pre:dual-cone-non-trivial，$\tc^\ast$ 包含非零向量，且对任何这样的非零向量 $v$，由于 $\tc^\ast$ 中的向量 [满足 $(v,v)\leq0$](/coxeter-groups-tits-cone/#dual-cone-nonspace)，以及 $\inn$ 半正定，所以 $(v,v)=0$，即 $v\in\rad(V)$，从而 $v$ 与 $\delta$ 共线，从而 $\{0\}\ne\tc^\ast\subseteq\mathbb{R}\delta$。即 $\tc^\ast$ 包含在 $\delta$ 生成的一维直线中。

另一方面从 [对偶锥的定义](/coxeter-groups-tits-cone/#dual-cone) 易见 $\tc^\ast\cap-\tc^\ast=\{0\}$，所以 $\tc^\ast$ 要么等于射线 $\{c\delta\mid c\geq0\}$，要么等于射线 $\{c\delta\mid c\leq0\}$。结合 $\delta$ 是 $\Delta$ 的正线性组合，以及 $\tc^\ast\subset\cone{\Delta}$，这只能是 $\tc^\ast=\{c\delta\mid c\geq0\}$。这就给出了对偶锥 $\tc^\ast$ 的刻画。

再来分析 Tits 锥 $\tc$。取对偶我们得到 $\overline{\tc}=\tc^{\ast\ast}=\{\delta\geq0\}$。我们将证明 $\tc$ 不包含超平面 $\{\delta=0\}$ 的除去 0 以外的任何点，但是包含开的半空间 $\{\delta>0\}$，这就证明了 $\tc=\{0\}\cup\{\delta > 0\}$。
结合fun{\alpha_s}{y}.$$
即 $0=\sum_{s\in S}z_s\lfun{\alpha_s}{y}$。然而每个 $z_s>0$，并且由于 $y\in\barfd$ 所以每个 $\lfun{\alpha_s}{y}\geq0$，这只能是 $\lfun{\alpha_s}{y}=0$ 对所有 $s\in S$ 成立。结合 $\{\alpha_s\}$ 是 $V$ 的一组基，这导致 $y=0$，从而 $x=0$，所以超平面 $\{\delta=0\}$ 中属于 $\tc$ 的只有 0。

由于一个凸集的内点和它的闭包的内点集相同，所以 $\tc^\circ=\{\delta>0\}$，于是 $\{\delta>0\}\subset\tc$，这就证明了 $\tc=\{0\}\cup\{\delta>0\}$。$\blacksquare$


# 双曲

我们已经给出了有限和仿射的情形 Tits 锥和对偶锥的完整刻画，但对双曲的情形，Tits 锥的结构要复杂许多，一般来说没有完整的刻画。

我们首先来介绍一些关于 Lorentzian 内积的基本知识。这些内容在 [@ratcliffe, chapter 3] 中都可以找到。

设 $V$ 是一个 $n$ 维实向量空间，其上有一个内积 $\inn$。我们分别用 $p,q$ 表示 $\inn$ 的正负惯性指数。当 $(p,q)=(n-1,1)$ 时，$V$ 在此内积下成为一个 Lorentzian 空间。我们称 $v\in V$ 是

1. space-like 的，如果 $(v,v)>0$；
2. light-like 的，如果 $(v,v)=0$；
3. time-like 的，如果 $(v,v)<0$。

:::{.note}
space-like, light-like, time-like 这三个术语我不作翻译，保持英文原样似乎更容易理解？
:::

这个概念也可以推广到 $V$ 的子空间中：如果 $U\subset V$ 是一个子空间，我们称 $U$ 是

1. space-like 的，如果 $\inn\mid_U$ 是正定的；
2. light-like 的，如果 $\inn\mid_U$ 是半正定的，但不是正定的；
3. time-like 的，如果 $\inn\mid_U$ 不属于以上两种情形，即 $U$ 包含 time-like 的向量。

由于 Lorentzian 内积是非退化的，所以对任何子空间 $U$ 都有 $\dim U + \dim U^\bot=n$ 成立。

下面的命题是关于二次型知识的简单练习，所以我省略它们的证明。

::: {.proposition #orth-complement-lorentzian}
1. $U$ 是 space-like 的当且仅当 $U^\bot$ 是 time-like 的；
2. $U$ 是 light-like 的当且仅当 $U^\bot$ 是 light-like 的。
:::

::: example
1. 如果 $v$ 是 space-like 的向量，那么 $(\R v)^\bot$ 是 $n-1$ 维的 time-like 的子空间，符号为 $(p,q)=(n-2, 1)$，并且 $V=\R v\oplus (\R v)^\bot$。
2. 如果 $v$ 是 time-like 的向量，那么 $(\R v)^\bot$ 是 $n-1$ 维的 space-like 的子空间，符号为 $(p,q)=(n-1, 0)$，并且 $V=\R v\oplus(\R v)^\bot$。
3. 如果 $v$ 是 light-like 的向量，那么 $(\R v)^\bot$ 是 $n-1$ 维的 light-like 的子空间，符号为 $(p,q)=(n-2,0)$。这时 $V\ne \R v\oplus(\R v)^\bot$，因为 $v\in\R v\cap(\R v)^\bot$。
:::

:::{#lorentzinian-decomposition}
:::

取 $z$ 是任一满足 $(z,z)=-1$ 的 time-like 的向量，记 $U=\R z$，则 $U^\bot$ 是 space-like 的并且有 $V=U\oplus U^\bot$ 成立。于是任何 $v\in V$ 可以写成 $v = x + cz$ 的形式，这里 $x\in U^\bot$ 是一个 Euclidean 空间中的向量，$c\in\R$ 是实数，$x$ 和 $z$ 是正交的。

记
$$\Q=\{v\in V\mid (v,v)\leq 0\}$$
是所有非 space-like 的向量组成的集合，则 $v=x+cz\in\Q$ 当且仅当 $(x,x)-c^2\leq0$。

在除去原点以后，$\Q-\{0\}$ 由两个连通分支 $\Q_+,\,\Q_-$ 组成，它们分别由 $\Q$ 中满足 $c>0$ 和 $c<0$ 的点组成，并且 $\Q_+=-\Q_-$。

![](/images/coxeter/hyperboloid.svg){.fig width=350}

:::{.note}
$\Q$ 是包含原点的，但是 $\Q_+$ 和 $\Q_-$ 都不包含原点。
:::

在本文中我们用记号 $u\sim v$ 来表示 $u,v$ 属于同一个连通分支，$u\not\sim v$ 表示 $u,v$ 属于不同的连通分支。

::: {.proposition #connected-component-dot}
设 $u,v\in \Q-\{0\}$。

1. 如果 $u\sim v$ 则 $(u,v)\leq0$。
2. $(u,v)=0$ 当且仅当 $u,v$ 是 light-like 的向量。
:::

**证明**：

1. 不妨设 $u,v$ 都属于 $\Q_+$。记 $u=x+cz,\, v=y+dz$，其中 $x,y$ 是 space-like 的向量，$c,d>0$。记 $|x|=\sqrt{(x,x)}$ 是 $x$ 的 Euclidean 范数，$|y|$ 同理，则 $|x|\leq c,\, |y|\leq d$。由 Cauchy-Schwartz 不等式有
$$(u,v)=(x,y) - cd\leq |x| |y| - cd\leq cd-cd=0.$$
此即为所证。

2. 由 $(u,v)=0$ 可得 $(x,y)=cd$。结合 $|(x,y)|\leq |x| |y|$ 可得 $|cd|\leq |x||y|$。然而 $|x|\leq |c|,\, |y|\leq |d|$，所以所有的等号都成立，从而 $|x|=|c|,\, |y|=|d|$。即 $u,v$ 都是 light-like 的向量。由 $|(x,y)|=|x||y|$ 可得 $x,y$ 共线，设 $x=\lambda y$，代入 $(x,y)=cd$ 可得 $c=\lambda d$，从而 $u=\lambda v$。

$\blacksquare$

这个命题有显然的推论是：

::: {.corollary #suff-for-equiv}
设 $u,v\in\Q-\{0\}$。

1. 若 $(u,v)>0$ 则 $u\not\sim v$。
2. 若 $(u,v)\leq0$，且 $u,v$ 中至少有一个是 time-like 的，则 $u\sim v$。
:::

为了简化记号，我们记 $\Q_+$ 和 $\Q_-$ 的内点分别为 $\N_+$ 和 $\N_-$，即 $\N_+$ 和 $\N_-$ 分别是 $\N=\{v\in V\mid (v,v)<0\}$ 的两个连通分支。

在双曲的情形，由于内积 $\inn$ 非退化，所以我们可以把 $V$ 和 $V^\ast$ 等同起来，从而根系 $\Phi$ 和 Tits 锥 $\tc$ 都在 $V$ 中。

我们将证明在双曲的情形，Tits 锥的闭包 $\cl{\tc}$ 必然包含 $\Q_+,\,\Q_-$ 中的一个，同时与另一个的交为空。

::: {.proposition #dual-cone-trivial-intersection}
在 $W$ 不可约且双曲的情形，$\tc^\ast\cap \Q_+,\,\tc^\ast\cap\Q_-$ 中必有一个是空集。
:::

**证明**：若 $u\in\tc^\ast\cap\Q_+,\,u'\in \tc^\ast\cap\Q_-$，设 $u=x+cz,\,u'=y+dz$ 是 [如前面讨论的分解](#lorentzinian-decomposition)，则 $c>0,\,d<0$。考察 $v=cu'-du=cy-dx\in(\R z)^\bot$，由于 $(\R z)^\bot$ 是 space-like 的子空间，所以 $(v,v)\geq0$。但是 $v$ 是 $u$ 和 $u'$ 的非负线性组合，所以 $v\in\tc^\ast$，从而 [必须有 $(v,v)\leq0$](/coxeter-groups-tits-cone/#dual-cone-nonspace)，从而由正定性得到 $v=0$，于是 $cu'=du$。再结合 $c,d$ 异号可得 $u$ 和 $-u$ 同时属于 $\tc^\ast$，从而同时属于 $\cone{\Delta}$。这只能导致 $u=0$，矛盾。所以 $\tc^\ast\cap\Q_+$ 和 $\tc^\ast\cap\Q_-$ 中必有一个是空集。$\blacksquare$

::: {.corollary #dual-cone-belongs-branch}
在双曲的情形，必有 $\tc^\ast\subset\Q_+\cup\{0\}$ 和 $\tc^\ast\subset\Q_-\cup\{0\}$ 之一成立。
:::

**证明**：结合 @Pre:dual-cone-trivial-intersection 和 [对偶锥中的向量之间内积非正](/coxeter-groups-tits-cone/#dual-cone-nonspace) 即得。$\blacksquare$

::: {.corollary #tits-closure}
在双曲的情形，Tits 锥 $\tc$ 包含 $\N_+$ 或者 $\N_-$ 之一。
:::

:::{.example}
在下图中，$W$ 是双曲群 $(7,3)$，红色的锥是射影模型下的基本区域，它在 $W$ 的作用下得到的 Tits 锥 $\tc$ 是光锥内部的一个点锥。取 $\tc$ 与 hyperboloid 的交给出双曲密铺。

![](/images/coxeter/Tits_hyperbolic.png){.fig width=350}
:::


**证明**：首先注意到对任何 $x\in\Q_+$ 和 $y\in\Q_-$ 有 $(x,y)\geq0$，所以 $\Q_+$ 和 $\Q_-$ 互相包含在对方的对偶锥中。

由 @Pre:dual-cone-belongs-branch，不妨设 $\tc^\ast\subseteq\Q_+\cup\{0\}$，[取对偶以后有](/coxeter-groups-tits-cone/#dual-dual-cone) $\overline{\tc}=\tc^{\ast\ast}\supseteq \Q_+^\ast\supseteq\Q_-$，即 $\overline{\tc}\supset\Q_-$。由于凸集的内点等于其闭包的内点，即得 $\tc\supset\Q_-^\circ=\N_-$。$\blacksquare$

:::note
注意 $\tc$ 未必包含 $\Q_+$ 或者 $\Q_-$ 的边界。例如对 $(3,3,7)$ 类型的双曲密铺，理想边界上的点无法经过有限次反射变换到基本区域中，所以边界不属于 $\tc$。

![](/images/coxeter/compact.png){.fig width=350}
:::