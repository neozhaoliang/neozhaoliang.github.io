---
title: "对称平面分拆的 Macdonald 公式"
date: 2016-02-13
categories: [计数组合学]
tags:
  - Plane partitions
  - Schur polynomials
  - Macdonald's formula
  - Weyl character formula
  - Simple Lie algebra
  - Symmetric plane partitions
url: symmetric-plane-partitions
---
今天要介绍的问题是 Weyl 特征公式在组合数学中的一个精彩应用。

设 $\lambda$ 是一个整数分拆，在一个形状为 $\lambda$ 的 Young 图 $T$ 中填入正整数，使得每一行从左到右，每一列从上到下都是递减的，这样得到的二维数组 $\pi$ 叫做平面分拆 (plane partition)。如果 $\pi$ 关于其对角线还是反射对称的，就称其是一个对称平面分拆。例如下图是一个形状为 $\lambda=(5, 4, 3, 2, 1)$ 的对称平面分拆：

|   |   |   |   |   |
|:-:|:-:|:-:|:-:|:-:|
| 6  | 4  | 3  | 3  | 1 
| 4  | 3  | 2  | 2
| 3  | 2  | 1
| 3  | 2
| 1

平面分拆更直观的描述方式是画出其 3D “鸟瞰图”，对于一个有 $r$ 行 $r$ 列，最大元素不超过 $t$ 的平面分拆 $\pi$，其对应的鸟瞰图是在一个底面为 $r\times r$，高度不超过 $t$ 的房间中堆箱子，且每一摞箱子的高度从墙根的方向向外是依次递减的，从而你可以完整看到每一摞箱子的顶部，不存在遮挡的现象。$\pi$ 对应的鸟瞰图如下：

<img style="margin:0px auto;display:block" width=350 src="/images/macdonald/symmetric-pp-example.svg"/>

房间的示意图如下，上面的鸟瞰图是这个平行六边形的一个菱形密铺，且关于中轴线是对称的：

<img style="margin:0px auto;display:block" width=350 src="/images/macdonald/hexagon.svg"/>

用 $|\pi|$ 表示 $\pi$ 的所有元素之和，记 $\mathcal{B}(r,r, t)$ 为所有体积不超过 $r\times r\times t$ 的*对称平面分拆* $\pi$ 组成的集合，问题来了：

{% blockquote %}
**问题**：求 $q-$ 计数
$$\sum_{\pi\in\mathcal{B}(r,r, t)}q^{|\pi|}.$$
{% endblockquote %}

这个问题最初是 MacMahon 在其 1898 的文章 "Partitions of numbers whose graphs possess symmetry" 中作为猜想提出，但是 Macmahon 本人没能解决这个问题。George E. Andrews 在 1978 年和 Ian G. Macdonald 在 1979 年分别独立解决了这个问题，本文要介绍的是 Macdonald 的解法 [^1]，这个解法的关键在于使用了 $B_n$ 型李代数的特征公式。

<!-- more -->


# $\mathfrak{so}_{2n+1}(\mathbb{C})$ 的 Weyl 特征公式





[^1]: I. G. Macdonald, Symmetric Functions and Hall Polynomials. Oxford University Press, 2 ed., 1995.