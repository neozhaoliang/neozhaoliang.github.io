---
title: "Artinian 环与 Wedderburn-Artin 定理"
date: "2010-10-22"
categories: ["有限群表示与结合代数"]
tags:
  - representation theory
  - associative algebra
  - Wedderburn-Artin theorem
  - Artinian rings
  - simple rings
url: "wedderburn-artin-theorem"
---
\newcommand{\rad}[1]{\mathrm{rad}(#1)}


讲述 Wedderburn-Artin 定理的教材已经非常多了，在介绍群表示论或者非交换环的书里通常都可以找到，证明途径也大同小异。据我个人的体会，讲群表示论的书往往只介绍有限维群代数的情形，显得不太够用；而讲非交换环的书则喜欢从 Jacobson 根和密度定理讲起，念起来很让人劝退。我觉得 Artinian 环情形的 Wedderburn-Artin 定理还是非常有用的。我打算仿照 @curtis-reiner 的方式，按照当年 Wedderburn 的思路展开叙述，即通过极大幂零理想来定义半单性。这种方式的好处是每一步的动机都比较自然，至少比上来就丢出一个 Jacobson 根的定义让人舒服一些。

<!-- more -->

# 背景

Wedderburn-Artin 定理最早源于 1907 年 Wedderburn 研究域上有限维结合代数的分类定理。在 Wedderburn 考虑这个问题的时候，Killing 和 Cartan 等人已经完成了有限维复半单 Lie 代数的分类工作，如果读者学过有限维 Lie 代数的知识的话，可能已经知道任何有限维复 Lie 代数 $L$ 有一个极大可解理想 $\rad{L}$，叫做 $L$ 的根 (radical)，去掉这个根的商代数 $L/\rad{L}$ 是半单代数，其上的双线性型 Killing 型是非退化的，从而可以通过反复取正交补的方式将 $L/\rad{L}$ 分解为一些单代数的直和，然后对单 Lie 代数的结构进行讨论得出其共有九种不同的类型。Wedderburn 的思路自然受到了 Killing 等人工作的启发，他采取了类似的套路：

对域 $F$ 上的有限维结合代数 $A$：

1. 定义根理想 $\rad{A}$。
2. 转移到半单代数 $A/\rad{A}$。
3. 将 $A/\rad{A}$ 分解为单代数的直和。
4. 讨论单代数的结构。

Wedderburn 考虑的根 $\rad{A}$ 是 $A$ 的极大幂零理想，去掉这个根后的商代数 $A/\rad{A}$ 是半单的，于是可以分解为一些单环的直和，然后进一步分析单环的结构得到其同构于某个除环 $D$ 上的矩阵环 ${\rm Mat}_n(D)$。

整个路线图如下所示：

<img style="margin:0px auto;display:block" src="/images/wedderburn-artin/steps.svg"/>

所以虽然有限维复李代数和结合代数结构相差很大，但它们的结构定理遵循了类似的套路：拿走可解/幂零的部分，剩下的部分是半单的，而半单又可以分解为单代数的直和，于是最终归结为对单代数的结构进行讨论。

Wedderburn-Artin 定理的过程比较长，不过在头脑中事先明确这条主线，理解整个证明并不是一件困难的事情。

本文主要参考了 Curtis 和 Reiner 的经典 [@curtis-reiner]，Herstein 的精彩小书 [@herstein-rings]，以及林节玄的 [@Lam01]。C&R 的书是个大部头，但它总是从最基本的概念讲起，叙述清楚易懂，对新手非常友好。Herstein 的书则是另一种风格，主线简单，节奏很快，短短几章就讲到了中心单代数和 Galois 上同调。林节玄的书风格则更为现代一些，我没有细读，不多评价。

# 记号与约定

+ 在本文中，$R$ 总表示含乘法单位元的结合环。我们称 $R$ 是 Artinian 环，如果 $R$ 的左理想满足所谓的降链条件 (Descending chain condition, DCC)，即对任何左理想 $\{I_n\}_{n=1}^\infty$ 组成的无穷序列
$$I_1\supseteq I_2\supseteq \cdots \supseteq I_n\supseteq\cdots$$
都必然存在正整数 $N$ 使得 $I_N=I_{N+1}=\cdots$。这样的环 $R$ 叫做左 Artinian 环。左 Artinian 环的另一种等价刻画是，任何由 $R$ 的左理想组成的非空集合必有极小元。

+ 左理想 $I\subseteq R$ 称作是**不可约**的，如果 $I$ 作为左 $R-$ 模是不可约的。不可约且非零的左理想叫作**极小左理想**。

我们将尝试对左 Artinian 环证明其结构定理，然后应用在有限维代数上。这样当然比直接证明有限维代数的情形要多花一些功夫，但可以帮助我们更好的理解半单环的结构。

# 定义环 $R$ 的根 $\rad{R}$

之前提到，Wedderburn 的想法第一步是仿照 Lie 代数的情形找出环 $R$ 的根 $\rad{R}$ 来，它必须是一个双边理想，使得商环 $R/\rad{R}$ 的根是平凡的，即半单。

这里可以与有限维复 Lie 代数作一个比较：一个有限维复 Lie 代数 $L$ 的根 $\rad{L}$ 是其所有可解理想的和，称作**极大可解理想**。由于可解理想的和仍然是 $L$ 的子空间，其维数不会超过 $L$ 的维数，极大可解理想一定存在且唯一。

对左 Artinian 环 $R$，Wedderburun 将 $\rad{R}$ 定义为其**极大幂零理想**，即所有幂零**左理想**的和。但是，Artinian 环不像有限维 Lie 代数的情形那里有维数这个很强的条件，所有幂零左理想的和是否真的是极大幂零理想这件事论证起来有一些麻烦。

:::{.definition}
我们称 $R$ 的左理想 $I$ 是幂零的，如果存在正整数 $n$ 使得 $I^n=0$。
:::

显然左理想幂零自动蕴含其元素都是幂零的：对任何 $x\in I$ 有 $x^n=0$。但是反过来则未必对：每个元素都幂零并不能保证左理想是幂零的。

:::{.definition}
$R$ 的所有幂零左理想的和记作 $\rad{R}$。
:::

现在我们需要解决两个问题：

1. $\rad{R}$ 还是幂零左理想的吗？不难证明有限多个幂零左理想的和仍然是幂零的，但是如果 $R$ 包含无穷多个幂零左理想呢？它们的和还幂零吗？

2. $\rad{R}$ 是双边理想吗？

这两个问题都可以用一个引理来解决，这个引理的证明颇有一点技巧性：


:::{.lemma #idempotent}
如果左理想 $I\subseteq R$ 不是幂零的，则其必然包含一个幂等元。
:::

这里 $e\in R$ 称作是幂等元，如果 $e$ 满足 $e\ne0$ 且 $e^2=e$。

我们把 @Pre:idempotent 的证明稍微放一放，先看看它是怎么解决上面的问题 1, 2 的。

记 $N$ 为 $R$ 的所有幂零左理想 $\{I_{\alpha}\}$ 的和，则 $N$ 也是左理想，并且其中的元素都是 $\{I_{\alpha}\}$ 中元素的有限线性组合：
$$x = x_{\alpha_1}+x_{\alpha_2}+\cdots+x_{\alpha_k},\quad x_{\alpha_i}\in I_{\alpha_i}.$$

1. 如果 $N$ 不是幂零的，那么根据 @Pre:idempotent 它包含一个幂等元 $e$，于是 $e$ 可以表示为有限多个幂零元的和，从而也是幂零的，矛盾！
2. $NR$ 是一个双边理想，而且它是幂零的：$$(NR)^i=N(RN)^{i-1}R\subseteq N^iR.$$特别它是一个幂零左理想，于是 $NR\subseteq N$，从而 $N$ 是双边理想。

**@Pre:idempotent 的证明**：

我们会反复使用 DCC 降链条件，即任何由 $R$ 的左理想构成的非空集合必有最小元。

首先不妨假设 $I$ 是“极小”非幂零的，即 $I$ 本身不幂零，但 $I$ 的任何真理想都是幂零的。否则考察所有包含在 $I$ 内的、非幂零的左理想组成的集合，此集合包含 $I$ 所以非空，于是根据 DCC 条件它包含一个极小元 $I_1$，$I_1$ 不是幂零的，但是任何真包含于 $I_1$ 内的左理想都是幂零的。用 $I_1$ 代替 $I$，故而可以假设 $I$ 是极小非幂零的。

$I^2$ 包含于 $I$ 内，但它不可能是幂零的，否则 $I$ 就幂零了，所以 $I^2=I$。我们考察所有满足如下条件的左理想 $L$ 组成的集合 $S$：

1. $L\subseteq I$。
2. $IL\ne0$。

显然 $S$ 包含 $I$ 从而非空，于是 $S$ 包含一个极小元 $L$。由于 $IL\ne0$ 所以存在 $x\in L$ 使得 $Ix\ne 0$。由于 $Ix$ 是包含在 $L$ 内的一个左理想，而且 $I(Ix)=Ix\ne0$ 所以 $Ix$ 也在 $S$ 中，由 $L$ 的极小性有 $Ix=L$。由 $x\in L$ 可知存在 $a\in I$ 满足 $x=ax$，从而
$$x= ax = a^2x = \cdots.$$
所以 $a$ 不可能是幂零的，并且 $(a^2-a)x=0$。我们断言 $a^2-a$ 是幂零的。为此进一步考虑包含在 $I$ 内的左理想
$$N = \{ u\in I\ |\ ux = 0\}.$$
于是 $Nx=0$，但 $Ix\ne0$，所以 $N$ 真包含于 $I$ 内，所以 $N$ 是幂零的，从而其每个元素都是幂零的，特别地 $a^2-a\in N$ 是幂零的。我们断言存在一个多项式 $p$ 使得 $u=p(a)$ 是一个幂等元。为此假设 $(a^2-a)^k=0$，展开以后可得存在多项式 $q$ 使得 $a^k=a^{k+1}q(a)$，从而 （反复将等式右边的 $a^k$ 替换为 $a^{k+1}q(a)$）
$$a^k=a^kaq(a)=a^{k+2}q^2(a)=a^{k+3}q^3(a)=\cdots=a^{2k}q^{k}(a).$$
令 $e=a^kq^k(a)$，则 $a^k=a^ke$, 由于 $a$ 不是幂零的所以 $e\ne0$。在 $a^k=a^ke$ 两边同乘以 $q^k(a)$ 得到 $a^kq^k(a)=a^{k}q^{k}(a)e$，即 $e=e^2$，从而 $e$ 是幂等元，这就证明了结论。

整理上述讨论，我们给出半单性的定义：

:::{.definition}
设 $R$ 是左 Artinian 环，定义其根 $\rad{R}$ 为 $R$ 的所有幂零左理想之和，则 $\rad{R}$ 是双边理想，且是幂零的。如果 $\rad{R}=0$，即 $R$ 不含任何非零的幂零左理想，就称 $R$ 是**半单**的。
:::

不难验证环 $R/\rad{R}$ 不含非零的幂零左理想，从而它符合我们对半单性的定义。下面的任务就是对半单环进行讨论。

# 将半单环分解为单环的直和

我们将证明半单环总是可以分解为一些单环的直和（单环的含义后面会介绍），而且这种分解还是唯一的。如果用整数分解为素数乘积来类比的话，极小左理想相当于单个素因子，单环相当于某个素因子的幂。

我们首先来证明

::: {.theorem #decompose-minimal}
半单环 $R$ 一定可以分解为有限个极小左理想的直和 $R=L_1\oplus\cdots\oplus L_n$。
:::


**证明**：设 $L$ 是 $R$ 的任一极小左理想，我们来说明必然存在左理想 $I$ 使得 $R=L\oplus I$。一旦如此，那么再取 $I$ 中 $R$ 的任一极小左理想 $L'$，将 $I$ 继续分解为 $I=L'\oplus I'$。如此下去，由于 $R$ 满足 DCC，所以这个过程必然在有限次后停止，这就把 $R$ 分解成了不可约左理想的直和。

设 $L$ 是任一极小左理想，由于 $R$ 是半单的所以 $L$ 不是幂零的，根据 @Pre:idempotent $L$ 包含一个幂等元 $e$，则 $Re\subset L$ 是包含在 $L$ 内的左理想从而 $L=Re$。于是 $I=R(1-e)$ 是左理想且
$$R = Re\oplus R(1-e) = L\oplus I.$$
所以 $R$ 的任何极小左理想总是有直和补的。

考虑所有包含在 $I$ 中的 $R$ 的非零左理想组成的集合，此集合包含 $I$ 所以非空，从而包含某个极小元 $L'$，$L'\subset I$ 是 $R$ 的极小左理想。假设 $R=L'\oplus J$，则不难验证有
$$ I = (I\cap L')\oplus (I\cap J) = L'\oplus (I\cap J),$$
$I\cap J$ 也是 $R$ 的左理想，所以可以继续分解下去，这就证明了 @Pre:decompose-minimal。$\blacksquare$

我们接下来要把 $R=\oplus_{i=1}^nL_i$ 中所有同构于某个 $L_i$ 的极小左理想合起来，形成一个单环。这类似于在整数的素因子分解中把相同的素数的乘积合起来得到单一素因子的幂。

:::{.definition}
如果两个极小左理想 $L,L'$ 作为左 $R-$ 模是同构的，就称它们是同构的，记作 $L\cong L'$。
:::

我们首先来说明，极小左理想具有某种“原子性”，即对两个极小左理想 $L$ 和 $L'$，若 $L\not\cong L'$ 则它们的乘积 $LL'= 0$，否则若 $L\cong L'$ 则 $LL'=L'$。

::: {.lemma #two-left-ideals}
两个极小左理想 $L\cong L'$ 当且仅当 $LL'\ne0$。特别地这个同构可以由右乘一个元素 $a\in L$ 给出：$L'=La$。
:::

**证明**：首先注意到 $L'L$ 是 $L$ 内的一个左理想，所以它只能是 $(0)$ 或者 $L$。其次对任何极小左理想 $L$，根据 @Pre:idempotent 它包含一个幂等元 $e$，于是必然有 $L=Re$，从而任何 $x\in L$ 都形如 $x=ae,\,a\in R$，从而 $xe=x$。

我们来证明以下三点是等价的：

::: {.lemma}
1. $L\cong L'$。
2. 存在 $a\in L$ 使得 $L=L'a$。
3. $L'L = L$。
:::

$1\Rightarrow 2$：
设 $\varphi: L\to L'$ 是一个左 $R-$ 模同构，$e$ 是 $L$ 的幂等元，则对任何 $x\in L$ 都有 $x=xe$，于是 $$\varphi(x)=\varphi(xe)=x\varphi(e),\quad x\in L.$$
即同构 $\varphi$ 由右乘 $a=\varphi(e)$ 给出。

$2\Rightarrow 3$：
注意到 $L'L\subset L$ 和 $L'L\supset L'a=L$ 即可。

$3\Rightarrow 1$：
若 $L'L=L$，则存在 $a\in L$ 使得 $L'a\ne0$，而 $L'a$ 是包含在 $L$ 中的左理想，所以 $L'a=L$，于是 $y\to ya$ 给出了从 $L'$ 到 $L$ 的一个左 $R-$ 模同构。

:::{.corollary #left-ideal}
设 $R=\oplus_{i=1}^n L_i$ 是上面所述的将 $R$ 分解极小左理想的直和，则 $R$ 的任何极小左理想必然同构于某个 $L_i$。
:::

证明：设 $x_i\in L_i$ 使得 $1=x_1+\cdots+x_n$。对任何极小左理想 $L$ 有 $$L =Lx_1+\cdots+Lx_n=\oplus_{i=1}^nLL_i,$$
所以必然存在某个 $i$ 使得 $LL_i\ne0$，从而根据 @Pre:two-left-ideals 有 $L\cong L_i$。

---

对 $R$ 的任一极小左理想 $L$，记 $B_L$ 为 $R$ 的所有同构于 $L$ 的极小左理想的和。我们来论证 $B_L$ 具有如下性质：

1. $B_LB_{L'}\ne 0$ 当且仅当 $L\cong L'$。（显然）
2. $B_L$ 是双边理想，从而是一个环。

    论证：记 $R = \oplus_{i=1}^nL_i$ 为极小左理想的直和，于是 $B_LR\subset\oplus_{i=1}^nB_LL_i$。右边每个 $B_LL_i$ 要么是 $(0)$ ($L_i\ncong L$)，要么等于 $L_i$ ($L_i\cong L$) 从而属于 $B_L$，所以 $B_LR\subset B_L$，即 $B_L$ 是双边理想。

    > 为简便以下记 $B_i = B_{L_i}$。

3. $B_L$ 也有乘法单位元 （与 $R$ 的单位元未必相同）。

    设在 $R$ 的极小左理想直和分解中，$\{L_1,\ldots, L_m\}$ 是互不同构的，$\{L_1,\ldots, L_n\}$ 中的任何一个都与 $\{L_1,\ldots, L_m\}$ 中的某一个同构，则 $R=B_1+\cdots+B_m$。于是环 $R$ 的单位元可以表示为
     $$1 = e_1+\cdots + e_m\quad e_i\in B_i.$$
    对任何 $x\in B_i$，利用 $i\ne j$ 时 $B_iB_j=0$ 有
    $$\begin{align*}x&=e_1x+\cdots+e_mx = e_ix,\\ x&=xe_1+\cdots + xe_m=xe_i.\end{align*}$$
    从而 $e_i$ 是 $B_i$ 的乘法单位元。

    根据 @Pre:left-ideal 任何 $B_L$ 必然等于 $\{B_1,\ldots,B_m\}$ 之一，所以也是有单位元的。

4. $B_L$ 也满足左理想的 DCC 降链条件。

    只要说明 $B_{L}$ 的左理想 $I$ 也是 $R$ 的左理想即可：由于 $e$ 是 $B_{L}$ 的乘法单位元所以 $I=eI$，于是 $RI=ReI\subset B_{L}I\subset I$。

5. $B_L$ 除了 (0) 和自身外不含其它双边理想。

     设 $D$ 是 $B_L$ 的非零双边理想，则 $D$ 也是 $R$ 的双边理想（因为对任何 $r\in R,\, d\in D$，$rd=r(ed)=(re)d\in D$，同理 $dr\in D$），从而其包含 $R$ 的某个极小左理想 $L_1$，即$$L_1\subset D \subset B_L.$$由于 $L_1B_L\supset L_1^2\ne0$ 所以 $L_1\cong L$。

     由于对任意的 $a\in R$ 都有 $L_1a\subset D$，根据 @Pre:two-left-ideals，这些 $L_1a$ 跑遍所有与 $L_1$ 同构的极小左理想，从而 $B_L\subset D$，于是 $B_L=D$，即 $B_L$ 不含非平凡的双边理想。

6. $R$ 是 $\{B_i\}$ 的直和：$$R = B_1\oplus\cdots\oplus B_m.$$

    设 $0=x_1+\cdots+x_m,\,x_i\in B_i$，两边同时乘以 $B_i$ 的单位元 $e_i$ 可得 $x_i=0$。

7. $R$ 的任何双边理想 $I$ 都可以表示为若干 $B_i$ 的直和。

    论证：由 $R=\oplus_{i=1}^mB_i$ 有 $I=\oplus_{i=1}^m IB_i$。每个 $IB_i$ 都是 $B_i$ 中的双边理想，而我们已经证明了 $B_i$ 没有非平凡的双边理想，所以每个 $IB_i$ 要么等于 $B_i$，要么等于 $(0)$，从而 $I$ 是一些 $B_i$ 的直和。

我们把满足 3, 4, 5 的环叫做**单环**，显然单环的根都是 $(0)$，所以也是半单的。

至此我们已经把半单环 $R$ 分解为了单环的直和：
$$R = B_1\oplus\cdots\oplus B_m.$$
实际上这个分解还是唯一的，即若
$$R = B'_1\oplus\cdots\oplus B'_l.$$
其中每个 $B'_j$ 是单环，并且是 $R$ 的双边理想，则 $m=l$ 且适当重排以后有 $B_i=B'_j$。（证明简单，略）

# 单环的结构定理

最终我们来到了单环的结构定理。在本节中，我们用 $A$ 来表示单环，以便与前面的半单环 $R$ 区分。回忆我们对单环的定义是：

1. 有乘法恒等元。
2. 满足左理想降链条件。
3. 没有非平凡的双边理想。

::: {.theorem #w-a}

(Wedderburn-Artin)

设 $A$ 是单环，则存在正整数 $n$ 和除环 $D$ 使得 $A\cong {\rm Mat}_n(D)$，这里 $n$ 和 $D$ 由 $A$ 唯一确定。
:::

我们先来验证 ${\rm Mat}_n(D)$ 满足单环的三个条件。记 $e_{ij}\in {\rm Mat}_n(D)$ 是第 $(i,j)$ 个分量为 1，其余位置都是 0 的初等矩阵。

1. 恒等矩阵 $I_n$ 是乘法单位元。
2. ${\rm Mat}_n(D)$ 可以分解为极小左理想的直和
$${\rm Mat}_n(D)={\rm Mat}_n(D)e_{11}\oplus\cdots {\rm Mat}_n(D)e_{nn}.$$
    其中 $\{e_{ii},\,1\leq i\leq n\}$ 是仅在对角线上第 $i$ 个元素为 1，其余所有元素都为 0 的矩阵，它们构成一组互相正交的幂等元，其和为单位矩阵。左理想 $L_i={\rm Mat}_n(D)e_{ii}$ 中的矩阵除了第 $i$ 列以外，其余的列都是 0。$L_i$ 是极小左理想是因为，对任何两个非零元素 $x,y\in L_i$，我们总可以用初等行变换将 $x$ 变成 $y$，而初等行变换就是左乘一个 ${\rm Mat}_n(D)$ 中的矩阵，所以任何非零元 $x$ 都可以在 ${\rm Mat}_n(D)$ 的左乘作用下生成整个 $L_i$，所以 $L_i$ 确实是极小左理想。
3. 这些极小左理想 $L_i\,(1\leq i\leq n)$ 是互相同构的。为此只要说明
    $$L_iL_j={\rm Mat}_n(D)e_{ii}\cdot {\rm Mat}_n(D)e_{jj}$$
    不为 0 即可，而这个乘积包含 $e_{ii}e_{ij}e_{jj}=e_{ij}$，当然不是 0。

下面回到 @Pre:w-a 的证明。

大多数文献上对这一步的处理方式都是证明单环 $A$ 和它的不可约模满足所谓的双重中心化子性质。我们先介绍大致的思路：

+ 设 $M$ 是一个左 $A-$ 模，则 $A$ 在 $M$ 上的左乘给出了 $A\to {\rm End}(M)$ 的一个环同态，记 $A$ 在 ${\rm End}(M)$ 中的同态像为 $A_L$。由于 $A$ 是单环，$A\cong A_L$。
+ $M$ 的所有 $A-$ 模同态记作 $D={\rm Hom}_A(M,M)$。$D$ 正是 $A_L$ 在 ${\rm End}(M)$ 中的中心化子：
    $$(am)d = a(md),\quad a\in A_L,\,m\in M,\,d\in D.$$
    值得注意的是，我们把 $A_L$ 的作用写在左边（这就是为什么用了 $L$ 作为下标），$D$ 在 $M$ 上的作用写在右边：对任何 $d\in D$，$d$ 在 $M$ 上的作用为 $m\to md$。把 $D$ 的作用写在右边有两个好处：一是可以避免后面在矩阵中使用讨厌的反环记号 [^4]，二是这样一来 $A$ 和 $D$ 交换就等价于说 $M$ 是一个 $(A, D)-$ 双模。
+ 进一步记 $E={\rm Hom}_D(M,M)$ 为 $D$ 在 ${\rm End}(M)$ 中的中心化子，$E$ 在 $M$ 上的作用写在左边。即 $E$ 由所有满足
    $$(fm)d = f(md),\quad f\in {\rm End}(M),\,m\in M,\,d\in D.$$
    的自同态 $f$ 组成。显然 $E$ 是由 $A_L$ 在 ${\rm End}(M)$ 中连续取两次中心化子得到的，且 $A_L\subseteq E$：
    $$A_L\xrightarrow{\text{Centralizer in }{\rm End}(M)}D\xrightarrow{\text{Centralizer in }{\rm End}(M)} E\supseteq A_L.$$
    特别地，如果 $A_L=E$ 我们就称 $(A,M)$ 具有**双重中心化子性质**。
+ 设 $M=Ae$ 是单环 $A$ 的一个极小左理想，我们希望证明 $(A,M)$ 具有双重中心化子性质。由 $M$ 是不可约左 $A-$ 模，根据 Schur 引理，$D={\rm Hom}_A(M,M)$ 是除环，$M$ 作为右 $D-$ 模是除环 $D$ 上的右向量空间。若 $(A,M)$ 具有双重中心化子性质则 $A\cong A_L\cong {\rm Hom}_D(M,M)$，即 $A$ 同构于除环 $D$ 上的右向量空间 $M_D$ 上的所有 $D-$ 线性变换构成的环。特别地如果维数 $\dim M_D=n<\infty$，则 $A\cong {\rm Mat}_n(D)$，这就证明了 Wedderburn-Artin 定理。

于是我们的思路就是先证明 $(A, M)$ 具有双重中心化子性质，再证明 $\dim M_D<\infty$。

注意到对左正则模 $_AA$ ，$(A, \,_AA)$ 是具有双重中心化子性质的。事实上很容易验证 $A$ 在自身上的左乘 $A_L$ 和右乘 $A_R$ 互为对方在 ${\rm End}(A)$ 中的中心化子，所以 $(A,\, _AA)$ 是具有双重中心化子性质的。

另一方面单环 $A$ 是其极小左理想 $M$ 的若干重直和：$_AA\cong\oplus_{i=1}^nM$，所以我们只要证明这样的结论就好了：

:::{.lemma #A-M}
设左 $A-$ 模 $V$ 可以分解为 $A-$ 子模 $M$ 的 $n$ 重直和：$V=\oplus_{i=1}^n M$，若 $(A, V)$ 具有双重中心化子性质，则 $(A, M)$ 也具有双重中心化子性质。
:::

注意这个引理中 $A$ 可以是任意的环，不仅限于单环；$M$ 也是任意的左 $A-$ 模，不仅限于不可约模。

:::{.simple}

**思路**

对
$$M\xrightarrow{f\,\in\,{\rm Hom}_D(M, M) }M,$$
我们将其提升为
$$\oplus nM\xrightarrow{\overbrace{f\oplus \cdots\oplus f}^{n \text{\ copies}}\,\in\, {\rm Hom}_{D^\ast}(\oplus nM,\,\oplus nM)}\oplus nM,$$
记 $f^\ast=f\oplus\cdots\oplus f$，即
$$V\xrightarrow{f^\ast\,\in\, {\rm Hom}_{D^\ast}(V, V)} V.$$
由于 $(A,V)$ 满足双重中心化子性质，$f^\ast$ 由某个 $a\in A$ 的左乘给出，从而取分量即得 $f$ 也由 $a$ 的左乘给出。
:::

**证明**：对任何 $f\in E={\rm Hom}_D(M, M)$，将其提升为 $V$ 的一个自同态
$$f^\ast: (m_1,m_2,\ldots, m_n)\to (f(m_1), f(m_2), \ldots, f(m_n)).$$
如果我们能说明 $f^\ast \in {\rm Hom}_{D^\ast}(V, V)$，其中 $D^\ast={\rm Hom}_A(V, V)$，则由于 $(A, V)$ 具有双重中心化子性质，$f^\ast\in{\rm Hom}_{D^\ast}(V, V)$ 由某个 $a\in A$ 在 $V$ 上的左乘给出，即对任何 $(m_1,m_2,\ldots,m_n)$ 有
$$ f^\ast(m_1,m_2,\ldots, m_n) =  (am_1,am_2,\ldots,am_n).$$
只看第一个分量即得对任何 $m\in M$ 有 $f(m)=am$，这就证明了结论。

为此我们只要注意到 [^5] （一个简单的练习，细节见脚注）
$$D^\ast={\rm Hom}_A(\oplus_{i=1}^nM, \oplus_{i=1}^nM)\cong {\rm Mat}_n({\rm Hom}_A(M, M)) = {\rm Mat}_n(D).$$
换言之任何 $\varphi\in D^\ast$ 都形如 $\varphi=(d_{ij})_{1\leq i,j\leq n}$，其中 $d_{ij}\in D={\rm Hom}_A(M,M)$，所以验证 $f^\ast\in{\rm Hom}_{D^\ast}(V, V)$ 变成了验证一串矩阵等式：
$$\begin{align*}
(f^\ast(m_1,\ldots,m_n))\varphi&=(f(m_1),\ldots,f(m_n))\varphi\\&=(f(m_1),\ldots,f(m_n))\begin{pmatrix}d_{11}&\cdots& d_{1n}\\\vdots&\ddots&\vdots\\d_{n1}&\cdots&d_{nn}\end{pmatrix}\\&=\left(\sum_{i=1}^nf(m_i)d_{i1},\ldots,\sum_{i=1}^nf(m_i)d_{in}\right)\\&=\left(f(\sum_{i=1}^nm_id_{i1}),\ldots,f(\sum_{i=1}^nm_id_{in})\right)\\&=f^\ast\left(\sum_{i=1}^nm_id_{i1},\ldots,\sum_{i=1}^nm_id_{in}\right)\\&=f^\ast((m_1,\ldots,m_n)\varphi)
\end{align*}
$$

即 $f^\ast \in {\rm Hom}_{D^\ast}(V, V)$，@Pre:A-M 得证。

我们还需要证明 $\dim M_D<\infty$。若不然，则存在一列 $\{m_k\}_{k=1}^\infty\in M$ 是 $D-$ 线性无关的。根据除环上向量空间的理论，我们可以将 $\{m_k\}$ 扩充为 $M$ 的一组 $D-$ 基，并在这组基上自由地定义线性变换。特别地，我们可以定义 $D-$ 线性变换 $f_k\in E=\mathrm{Hom}_D(M, M)$ 使得 $f_k(V_k)=0$ 但 $f_k(m_{k+1})\ne0$。其中 $V_k$ 为 $\{m_1,\ldots, m_k\}$ 张成的子空间。根据双重中心化子定理，存在 $a_k\in A$ 使得 $f_k(m)=a_km,\, \forall m\in M$。

定义 $A$ 的递降左理想序列 $\{I_k\}_{k=1}^\infty$ 为
$$I_k = \{a\in A \ |\ aV_k=0\}.$$
由于 $a_k\in I_k$ 但是 $a_k\notin I_{k+1}$，所以 $\{I_k\}_{k=1}^\infty$ 是一个无穷严格降链，这与 $A$  满足 DCC 矛盾！所以 $\dim M_D<\infty$。

最后来说明 $n$ 和 $D$ 是唯一确定的，即若 $n'$ 和 $D'$ 使得 $A\cong {\rm Mat}_n(D)\cong {\rm Mat}_{n'}(D')$，则 $n=n'$ 且 $D\cong D'$。从上面的证明中我们已经看到 $n$ 是 $A$ 分解为极小左理想 $M$ 直和的重数，从而是唯一确定的。而除环 $D={\rm Hom}_A(M,M)$ 是其唯一不可约模的 $A-$ 自同态环，所以也是唯一确定的。

[^4]: 除环上的向量空间与域上的向量空间的一个显著不同是：如果 $V$ 是一个左 $D-$ 向量空间且 $\dim _DV=n$，则其 $D-$ 自同态环 ${\rm End}_D(V)\cong {\rm Mat}_n(D^{\rm op})$，这里 $D^{\rm op}$ 是 $D$ 的反环。但是如果 $V$ 是右 $D-$ 向量空间，并且把 ${\rm End}_D(V)$ 在 $V$ 上的作用写在左边的话（即把 $V$ 看作是 $({\rm End}_D(V), D)-$ 双模），则 ${\rm End}_D(V)\cong {\rm Mat}_n(D)$。

[^5]:  记 $i_k$ 是从 $M$ 到 $\oplus_{i=1}^nM$ 的第 $k$ 个分量的嵌入映射：
$$i_k: m\to(0, 0,\ldots, m,\ldots, 0).$$
$\pi_l$ 是从 $\oplus_{i=1}^nM$ 的第 $l$ 个分量到 $M$ 的投影：
$$\pi_l: (m_1,\ldots,m_l,\ldots, m_n) \to m_l.$$
对任何 $\varphi\in {\rm Hom}_A(\oplus_{i=1}^nM,\oplus_{i=1}^nM)$，$(m_1,\ldots,m_n)\varphi$ 的第 $j$ 个分量当然就是 $(m_1,\ldots,m_n)\varphi\circ\pi_j$。进一步把左边的 $(m_1,\ldots,m_n)$ 拆成求和有
$$(m_1,\ldots,m_n)\varphi\circ\pi_j=\left(\sum_{i=1}^nm_i\circ i_i\right)\varphi\circ\pi_j=\sum_{i=1}^n m_i(i_i\circ\varphi\circ\pi_j)=\sum_{i=1}^nm_i\varphi_{ij}.$$
其中 $\varphi_{ij}=i_i\circ\varphi\circ\pi_j\in{\rm Hom}_A(M,M)$，注意 $\varphi_{ij}$ 是写在 $m$ 右边的，$i_i$ 先作用，其次是 $\varphi$，最后是 $\pi_j$。
这告诉我们 $(m_1,\ldots,m_n)\varphi$ 的第 $j$ 个分量等于 $\sum_{i=1}^nm_i\varphi_{ij}$，即下面的矩阵乘法等式成立：
$$(m_1,\ldots,m_n)\varphi=(m_1,\ldots,m_n)\begin{pmatrix}\varphi_{11}&\cdots&\varphi_{1n}\\\vdots&\ddots&\vdots\\\varphi_{n1}&\cdots&\varphi_{nn}\end{pmatrix}.$$
不难验证 $\varphi\to(\varphi_{ij})$ 是一个从 ${\rm Hom}_A(\oplus_{i=1}^nM,\oplus_{i=1}^nM)$ 到 ${\rm Mat}_n(D)$ 的同构。
