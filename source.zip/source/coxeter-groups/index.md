---
title: Coxeter 群笔记
---

1. [几何实现](geometric-realization)
2. [根系](root-system)
3. [Tits 锥及其对偶](tits-cone)
4. [有限、仿射、双曲三种情形的 Tits 锥](three-geometries)
5. [Coxeter 群的 level](level)
6. [Boyd-Maxwell 球堆](Boyd-Maxwell)