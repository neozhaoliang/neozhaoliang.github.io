title: 关于
layout: about
---

欢迎来到 **赵亮** 的个人网站。这里记录了我的一些关于数学和编程方面的文章，它们大致可以分为三类：

1. 从通俗有趣的问题出发介绍它们背后的数学。
2. 我写过的（自以为）有趣的开源项目。
3. 一些念书时的笔记（非常枯燥）。

由于个人水平不足，文中难免出现错误，还请读者不吝指正。

个人方面，以下信息也许对你了解我有帮助：

1. 80 后，已婚，有娃一只。
2. 工作之余带娃、念数学、写代码。
3. 喜欢听罗大佑/邓丽君/Beyond，最喜欢的电影有《肖申克的救赎》，《真实的谎言》，《谍影重重》。
4. 郑渊洁和刘慈欣爱好者。

博客使用 [hexo](https://hexo.io/) 搭建，主题为 [raytaylorism](https://github.com/raytaylorlin/hexo-theme-raytaylorism)，我在其基础上做了一些修改，特此鸣谢作者。

文章使用了 [Pandoc](https://pandoc.org/) 渲染，[statement](https://github.com/dialoa/statement) 生成自动编号的定理环境。

转载文章和图片注明出处即可。所有代码均采用 [MIT LICENSE](https://opensource.org/licenses/MIT)。


# 项目

以下是我正在进行的一些项目：

+ Coxeter 群，双曲蜂巢和双曲球堆。这个项目讨论 Coxeter 群的一些知识，以及有限、仿射、双曲三种空间中的万花筒结构。有一些 [草稿](https://neozhaoliang.github.io/hyperbolic-sphere-packings-book/)。
+ 可视化复分析。我在考虑用 manimgl 制作 Needham 的 "Visual complex analysis" 书中的一些有趣的复分析的事实，此外还会加上一些其它和复分析有关的内容，例如双曲空间，分形，Koebe-Andreev-Thurston 定理等。
+ 计数组合学。我一直都对 plane partition，alternating sign matrix 有关的计数问题感兴趣。我学过一些对称函数和表示论的知识，但是还需要学习更多 Hall polynomial, minuscle representation, crystal bases 有关的内容。
+ 随机游动。我正在写一个随机游动的系列，每次介绍一个有趣但具有挑战性的问题。我攒了几篇草稿，但是还有更多有趣的内容我想放进去。
+ Kleinian 群的极限集。这方面有很多漂亮的分形图可以渲染。
+ Durrett 概率论批判系列。Durrett 的概率论里面有不少难懂的地方，我有一些笔记记录了一些学习时的心得。

---

Below is a selection of blog posts translated from my Chinese posts:

+ [Walk the dog: winding number and Rouché theorem](/rouche-theorem)
+ [The E8 picture explained through code](/e8-and-coxeter-plane)
+ [Catacaustics of a coffee cup](/catacaustics)
+ [Coxeter groups, automata and uniform tilings](/uniform-tilings)
+ [Make awesome gif animation in a few seconds with pure Python](/gifmaze)
+ [Todd-Coxeter algorithm and uniform polytopes](/polytopes)