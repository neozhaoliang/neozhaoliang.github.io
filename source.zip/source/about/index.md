title: 关于
layout: about
---

欢迎来到 **赵亮** 的个人网站。这里记录了我的一些关于数学和编程方面的文章，它们大致可以分为三类：

1. 通过引入通俗易懂而又有趣的问题，介绍它们背后的奇妙数学。
2. 介绍我写过的有趣的或者有用的开源项目。
3. 一些念书时的笔记。

我感兴趣的方向主要是表示论、概率论、组合数学，所以这些方面着墨较多。由于个人水平较菜，行文难免有错误之处，欢迎批评指正。

博客使用 [hexo](https://hexo.io/) 搭建，主题为 [raytaylorism](https://github.com/raytaylorlin/hexo-theme-raytaylorism)，我在其基础上做了一些修改，特此鸣谢作者。

转载文章和图片注明出处即可。所有代码均采用 [MIT LICENSE](https://opensource.org/licenses/MIT)。


## 写博客有感


每当我学到一个新的数学知识时，心中不免得意，立刻写下来放在博客上。但是过一段时间，发现当初理解其实甚是粗浅，这文章就越看越别扭，可再要提笔重写，又惶恐自己所知太少，踟躇不敢下笔。代码也是如此。所以写博客最好的时机还是在初学时凭借一股奋劲记录下来。


## Pywonderland 英文文档

+ [Make awesome gif animation in a few seconds with pure Python](https://pywonderland.com/gifmaze).
+ [Reaction-Diffusion simulation with pyglet and glsl](https://pywonderland.com/grayscott).
+ [Todd-Coxeter algorithm and uniform polytopes](https://pywonderland.com/polytopes).
+ [Coxeter groups, automata and uniform tilings](https://pywonderland.com/uniform-tilings).