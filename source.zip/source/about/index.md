title: 关于
layout: about
---

欢迎来到 **赵亮** 的个人网站。这里记录了我的一些关于数学和编程方面的文章，它们大致可以分为三类：

1. 通过引入通俗易懂而又有趣的问题，介绍它们背后的奇妙数学。
2. 介绍我写过的有趣的或者有用的开源项目。
3. 一些念书时的笔记。

我感兴趣的方向主要是表示论、概率论、组合数学，所以这些方面着墨较多。

博客使用 [hexo](https://hexo.io/) 搭建，主题为 [raytaylorism](https://github.com/raytaylorlin/hexo-theme-raytaylorism)，特此鸣谢作者。

个人方面，以下信息也许对你了解我有帮助：

+ 80 后，已婚，有娃一只。
+ 工作之余带娃、念数学、写代码。不追网剧，不玩游戏。
+ 喜欢听罗大佑和黄霑的歌，喜欢的电影有《肖申克的救赎》，《真实的谎言》，《谍影重重》。
+ 喜欢郑渊洁和刘慈欣。


## Pywonderland 英文文档

+ [Make awesome gif animation in a few seconds with pure Python](https://pywonderland.com/gifmaze).
+ [Reaction-Diffusion simulation with pyglet and glsl](https://pywonderland.com/grayscott).
+ [Todd-Coxeter algorithm and uniform polytopes](https://pywonderland.com/polytopes).
+ [Coxeter groups, automata and uniform tilings](https://pywonderland.com/uniform-tilings).