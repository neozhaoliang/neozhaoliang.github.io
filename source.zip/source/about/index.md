title: 关于
layout: about
---

欢迎来到 **赵亮** 的个人网站。这里记录了我的一些关于数学和编程方面的文章，它们大致可以分为三类：

1. 通过引入通俗易懂而又有趣的问题，介绍它们背后的奇妙数学。
2. 介绍我写过的有趣的或者有用的开源项目。
3. 一些念书时的笔记。

由于个人水平不足，文中难免出现错误，还请读者不吝指正。

博客使用 [hexo](https://hexo.io/) 搭建，主题为 [raytaylorism](https://github.com/raytaylorlin/hexo-theme-raytaylorism)，我在其基础上做了一些修改，特此鸣谢作者。

转载文章和图片注明出处即可。所有代码均采用 [MIT LICENSE](https://opensource.org/licenses/MIT)。

此外我还在维护一个 [TODO 列表](/todo/)，你可以从中看到更多我感兴趣的以及未来这个博客会出现的内容。