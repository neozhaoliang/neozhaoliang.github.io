title: 关于
layout: about
---

欢迎来到 **赵亮** 的个人网站。这里记录了我的一些关于数学和编程方面的文章，它们大致可以分为三类：

1. 从通俗有趣的问题出发介绍它们背后的数学。
2. 我写过的（自以为）有趣的开源项目。
3. 一些念书时的笔记（非常枯燥）。

由于个人水平不足，文中难免出现错误，还请读者不吝指正。

个人方面，以下信息也许对你了解我有帮助：

1. 80 后，已婚，有娃一只。
2. 工作之余带娃、念数学、写代码。不追剧，不玩游戏。
3. 喜欢听罗大佑/邓丽君/Beyond，最喜欢的电影有《肖申克的救赎》，《真实的谎言》，《谍影重重》。
4. 郑渊洁和刘慈欣爱好者。

博客使用 [hexo](https://hexo.io/) 搭建，主题为 [raytaylorism](https://github.com/raytaylorlin/hexo-theme-raytaylorism)，我在其基础上做了一些修改，特此鸣谢作者。

转载文章和图片注明出处即可。所有代码均采用 [MIT LICENSE](https://opensource.org/licenses/MIT)。

---

Below is a selection of blog posts translated from my original Chinese articles:

+ [Walk the dog: winding number and Rouché theorem](/rouche-theorem)
+ [The E8 picture explained through code](/e8-and-coxeter-plane)
+ [Catacaustics of a coffee cup](/catacaustics)
+ [Coxeter groups, automata and uniform tilings](/uniform-tilings)
+ [Make awesome gif animation in a few seconds with pure Python](/gifmaze)
+ [Todd-Coxeter algorithm and uniform polytopes](/polytopes)