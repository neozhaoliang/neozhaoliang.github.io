---
title: "Todd Kemp 概率论课程笔记"
date: 2021-03-01
url: todd-kemp
---
<!-- md texcmd.md -->


# 33.2 Regular Conditional Distributions

本讲介绍了正则条件分布。