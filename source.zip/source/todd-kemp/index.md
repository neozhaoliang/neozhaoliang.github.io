---
title: "Todd Kemp 概率论课程笔记"
date: 2021-03-01
url: todd-kemp
---
\newcommand{\io}{\ \mathrm{i.o.}\ }
\newcommand{\ae}{\ \mathrm{a.e.}}
\newcommand{\ind}{\mathbb{1}}
\newcommand{\udx}[1]{\mu(\mathrm{d}#1)}
\newcommand{\du}{\,\mathrm{d}\mu}
\newcommand{\dv}{\,\mathrm{d}\nu}
\newcommand{\dx}{\,\mathrm{d}x}
\newcommand{\pd}[1]{\mathrm{d}#1}
\newcommand{\udw}{\mu(\mathrm{d}\omega)}
\newcommand{\Lone}{L^1(\Omega,\mathcal{F},\mathbb{P})}
\newcommand{\iid}{\text{i.i.d}}
\newcommand{\E}{\mathbb{E}}
\newcommand{\P}{\mathbb{P}}
\newcommand{\R}{\mathbb{R}}
\newcommand{\B}{\mathcal{B}}
\newcommand{\F}{\mathcal{F}}

# 0 Banach Tarski

**不可测集的例子**：记单位圆 $S^1=\{e^{it},\,t\in\mathbb{R}\}$，子群 $H=\{e^{iq},\,q\in\mathbb{Q}\}$，在每个左陪集 $S^1/H$ 中选择一个代表元组成集合 $E$，则 $E$ 是不可测集合。这是因为 $S^1 = \bigcup_{q\in\mathbb{Q}}e^{iq}E$ 是可数多个互不相交的集合的并，这些集合两两之间只差一个旋转，所以测度均相等，于是
$$1 = \sum_{q\in\mathbb{Q}}\mu(E) = \infty\cdot \mu(E)\Rightarrow E\text{\ is not measuabe.}$$

# 1.1 Probability Motivation

无要点

# 1.2 $\sigma$- Fields

介绍了 $\sigma$- 域的概念，以及最重要的 $\sigma$- 域的例子：拓扑空间中开集生成的 Borel 域。

# 2.1 Measures Definition and Examples

介绍了可测空间，以及测度的定义和基本性质。

> **定义**：设 $\mathcal{F}$ 是一个 $\sigma$- 域，称 $\mu:\ \mathcal{F}\to[0,\infty]$ 是测度，如果对任何可数多个不交并有 $\mu(\uplus_{n=1}^\infty E_n)=\sum_{n=1}^\infty\mu(E_n)$ 成立。

测度的三个基本性质：

+ 单调性：$A\subseteq B\Rightarrow \mu(A)\leq\mu(B)$。
+ 加法等式 $\mu(A\cup B) + \mu(A\cap B) = \mu(A) + \mu(B)$。
+ 次可数可加：$\mu(\cup_{n=1}^\infty E_n)\leq\sum_{n=1}^\infty\mu(E_n)$。


# 2.2 Finitely Additive Measures

这一讲介绍了**有限可加测度**，**预测度 (pre-measure，即域上的可数可加测度)**，**半代数 (semi-algebra)** 等概念。

> **核心思想**：半代数 $\mathcal{S}$ 上的有限可加测度 $\Rightarrow$ 代数 $\mathcal{A}$ 上的有限可加测度 $\Rightarrow$ 代数 $\mathcal{A}$ 上的可数可加测度 $\Rightarrow$ $\sigma$- 域上的可数可加测度。

域 $\mathcal{A}$ 上的有限可加测度的基本性质：

+ 单调性、加法等式同可数可加的情形。
+ **超可数可加**：$\mu(\uplus_{n=1}^\infty E_n)\geq\sum_{n=1}^\infty\mu(E_n)$。这是由于单调性左边始终是右边部分和的上界。注意这里要求每个 $E_n\in\mathcal{A}$ 以及 $\mu(\uplus_{n=1}^\infty E_n)\in\mathcal{A}$。

> **定义**：一个半代数 $\mathcal{S}$ 是指满足如下条件的集合族：
>
> 1. $\emptyset\in\mathcal{S}$。
> 2. 若 $A,\,B\in\mathcal{S}$ 则 $A\cap B\in\mathcal{S}$。
> 3. 若 $A\in\mathcal{S}$ 则 $A^c$ 可以表示为 $\mathcal{S}$ 中有限多个成员的不交并。

半代数 $\mathcal{S}$ 生成一个代数 $\mathcal{A}$：
$$\mathcal{A}=\{\text{all finite disjoint unions of sets from }\mathcal{S} \}.$$

第一步**半代数 $\mathcal{S}$ 上的有限可加测度 $\Rightarrow$ 代数 $\mathcal{A}$ 上的有限可加测度**：这一步是显然的，只需要验证定义不依赖于 $\mathcal{A}$ 作为 $\mathcal{S}$ 中集合不交并的表示方式即可。

第三步**代数 $\mathcal{A}$ 上的可数可加测度 $\Rightarrow$ $\sigma$- 域上的可数可加测度**：这一步总是可以做到的，由后面的测度扩张定理给出。

第二步**代数 $\mathcal{A}$ 上的有限可加测度 $\Rightarrow$ 代数 $\mathcal{A}$ 上的可数可加测度**：这一步并不总是可以做到。举个例子，在是整数集 $\mathbb{Z}$ 的所有子集上定义如下测度 $\mu$：若子集 $E$ 或者 $E^c$ 之一是有限集，则规定 $\mu(E)=0$，否则 $\mu(E)=1$。此测度有限可加但不是可数可加，所以也不会有可数可加的扩张。

最重要的半代数 $\mathcal{S}$ 的例子：所有形如 $\{(a, b],-\infty\leq a<b\leq \infty\}$ 的半开区间。

任何单调函数 $F$ 都可以给出其上的一个有限可加测度：$F((a, b])) = F(b) - F(a)$，从而可以扩张为代数 $\mathcal{A}$ 上的有限可加测度。

**但是要使得这个测度是可数可加的，我们必须限制 $F$ 是右连续的**，这样的测度叫做 Stieltjes 测度，会在下一讲介绍。

# 3.1 Stieltjes Premeasures

本讲接着上一讲的内容，证明了当 $F$ 单调且右连续时，$\mu((a,b])=F(b)-F(a)$ 确实给出 Borel 域 $\mathcal{A}$ 上的一个可数可加测度。当然 Borel 域还是太复杂了 (虽然它们都是有限多个半开区间的不交并)，无法用可数可加的定义来验证。我们还是要回到由半开区间构成的半代数 $\mathcal{S}$ 上。

> **引理**：代数 $\mathcal{A}(\mathcal{S})$ 上的有限可加测度 $\mu$ 是可数可加的，**当且仅当它限制在  $\mathcal{S}$ 上是次可数可加的**。这个话需要仔细解释清楚：$\mu$ 在 $\mathcal{S}$ 上次可数可加是指如果 $\{E_n\}$ 是半代数 $\mathcal{S}$ 中互不相交的集合，并且它们的可数并 $\uplus_{n} E_n$ 也在半代数 $\mathcal{S}$ 中，则 $\mu(\uplus_nE_n)\leq\sum_n\mu(E_n)$。

**证明概要**：$\Rightarrow$ 是显然的，可数可加必然蕴含次可数可加。

$\Leftarrow$：$\mu$ 作为 $\mathcal{A}(\mathcal{S})$ 上的有限可加测度自然是超可数可加的，要证明它可数可加，只要再证明它次可数可加：即若 $\uplus_n A_n$ 是 $\mathcal{A}(\mathcal{S})$ 中的可数不交并，则 $\mu(\uplus_n A_n)\leq\sum_n\mu(A_n)$。记住 $\uplus_n A_n$ 以及所有 $A_n$ 现在都是 $\mathcal{A}(\mathcal{S})$ 中的元素，所以 $\uplus_n A_n = \uplus_{j=1}^N E_j$，其中 $E_j\in\mathcal{S}$。于是
$$E_j = \uplus_n (A_n\cap E_j)=\uplus_n\uplus_{i=1}^{N_n}E_i^n\cap E_j.$$
利用 $\mu$ 在 $\mathcal{S}$ 上的次可数可加性有
$$\mu(E_j)\leq \sum_n\sum_{i=1}^{N_n}\mu(E_i^n\cap E_j).$$
再利用 $\mu$ 在 $\mathcal{A}(\mathcal{S})$ 上的有限可加性有
$$\sum_{i=1}^{N_n}\mu(E_i^n\cap E_j)=\mu(A_n\cap E_j).$$
于是
$$\mu(\uplus_j E_j)=\sum_{j=1}^N\mu(E_j)\leq\sum_{j=1}^N\sum_{n=1}^\infty\mu(A_n\cap E_j)=\sum_{n=1}^\infty\sum_{j=1}^N\mu(A_n\cap E_j)=\sum_{n=1}^\infty\mu(A_n).$$
即为所证。

> **定理**：由单调右连续的函数 $F$ 给出的半代数 $\mathcal{S}=\{(a,b]\ -\infty\leq a<b\leq\infty\}$ 上的 Stieltjes 测度是次可数可加的，因而由上面引理它给出 $\mathcal{A}(\mathcal{S})$ 上的可数可加测度。

**Todd-Kemp 的精彩证明讲解**：设 $(a,b]=\uplus_{i=1}^\infty (a_i, b_i]$，我们要证明 $$F(b)-F(a)=\mu((a, b])\leq\sum_{i=1}^\infty\mu((a_i,b_i])=\sum_{i=1}^\infty (F(b_i)-F(a_i)).$$
我们可以先假设 $a,b$ 都是有限的。

**不要幻想可以给区间 $(a_i,b_i]$ 之间按照大小排顺序，它们可能有无穷多个聚点**。

**想法是把 $(a, b]$ 缩小一点变成 $[a+\delta, b]$，把 $(a_i,b_i]$ 放大一点变成 $(a_i,b_i+\delta_i)$，这样可以使用紧集的有限开覆盖性质**。从而存在 $N$ 使得前 $N$ 个开区间就足以覆盖 $[a+\delta,b]$：
$$[a+\delta,b] \subseteq \cup_{j=1}^N (a_j, b_j+\delta_j).$$
现在 $\mu$ 作为一个有限可加测度，由于 $(a+\delta, b]$ 被 $\cup_{j=1}^N (a_j, b_j+\delta_j]$ 覆盖，因而必然有
$$\mu((a+\delta, b])\leq \sum_{j=1}^N \mu((a_j, b_j+\delta_j])\leq\sum_{j=1}^\infty \mu((a_j, b_j+\delta_j]).$$
上式左边等于 $F(b)-F(a+\delta)$，$\delta$ 是任意正数，所以令其趋于 0 并利用 $F$ 的右连续有 $F(a+\delta)\downarrow F(a)$，所以上式变为
$$\mu((a, b])\leq\sum_{j=1}^\infty\mu((a_j, b_j+\delta_j])=\sum_{j=1}^\infty \mu((a_j, b_j]) + \sum_{j=1}^\infty \mu((b_j, b_j+\delta_j]).$$
注意到 $\delta_j$ 也是任意的，并且 $F$ 右连续，所以对任何 $\epsilon>0$ 我们可以取 $\delta_j$ 足够小，使得
$F(b_j+\delta_j)- F(b_j) < \epsilon/2^j$。于是
$$\mu((a, b])\leq\sum_{j=1}^\infty\mu((a_j, b_j+\delta_j])=\sum_{j=1}^\infty \mu((a_j, b_j]) + \epsilon.$$
由 $\epsilon$ 任意性定理得证。

# 5.2 Lebesgue Measure

本讲介绍了 Lebesgue 是唯一的平移不变的 Radon 测度，以及 Lebesgue 测度作为 Borel 测度的完备化。

# 6.1 Random Variables Motivation

本节介绍了随机变量，分布函数的概念。样本空间 $\Omega$ (modelling space) 是难以接触到的，我们对其的观测是通过随机变量来进行的。

随机变量 $X$ 的分布函数为 $F(t) = \mathbb{P}(X\leq t),\, t\in\overline{\mathbb{R}}$。$F(t)$ 是单调递增且右连续的。

# 8.1 Simple integration

本讲给出了简单函数积分的定义。无要点。

# 8.2 Monotone convergence theorem

本讲给出了**非负可测函数积分**的定义：设 $f\in L^+$ 为非负可测函数，其积分定义为
$$\int f\du = \sup\left\{\int\varphi\du:\ \varphi\leq f,\ \varphi \text{ simple and measuable}\right\}.$$

这个定义的问题在于不容易直接得出积分的可加性：
$$\int (f+g) \du =\int f\du + \int g\du.$$

为此先证明了单调收敛定理：

> **单调收敛定理**：若 $\{f_n\}\in L^+$ 且 $f_n\uparrow f$，则 $\int f_n\du\uparrow \int f\du$。

**证明概要**：显然 $\lim\limits_{n\to\infty}\int f_n\du$ 存在且小于等于 $\int f\du$。为了证明二者相等，只要证明对任何简单函数 $\varphi\leq f$ 有
$$\lim_{n\to\infty} \int f_n\du \geq \int \varphi\du$$
即可。**不要指望通过分析集合 $\{f_n\geq \varphi\}$ 来得出结论**，这完全可能对任何 $n$ 都是空集。但是如果可以证明对任何 $0<c<1$ 有
$$\lim_{n\to\infty} \int f_n\du \geq c \int \varphi\du$$
成立，那么令 $c\uparrow1$ 即得结论。而集合 $E_n=\{f_n\geq c\varphi\}$ 满足 $E_n\uparrow\Omega$。于是由 $f_n\geq c\varphi\cdot\ind_{E_n}$ 以及积分单调性有
$$\int f_n\du \geq c\int\varphi\ind_{E_n}\du.$$
设 $\varphi = \sum_{k} a_k\ind_{1_{A_k}}$ 代入上面右边，有
$$\int f_n\du \geq c\int\varphi\du = c\sum_{k}a_k\mu(A_k\cap E_n).$$
令 $n\to\infty$ 并利用测度连续性 $\mu(A_k\cap E_n)\uparrow\mu(A_k)$ 即得
$$\lim_{n\to\infty} \int f_n\du \geq c \int \varphi\du.$$

非负可测函数 $f$ 可以用简单函数序列
$$\varphi_n = \sum_{k=1}^{2^{2n}}\frac{k-1}{2^n}\ind_{\{\frac{k-1}{2^n}\leq f<\frac{k}{2^n}\}} + 2^n\ind_{\{f\geq 2^n\}}$$
来逼近。在第 $n$ 次切割中，我们将切割范围扩大为原来的 2 倍以逼近 $f$ 在 $\infty$ 的部分，同时将切割的间隔缩小为原来的 1/2 以保证逼近的误差是减小的。

**MCT 告诉我们总是可以用一个只取有限多个值、每个值都有限的简单函数来逼近 $f$ 的积分**。


# 9.1 Integrals and Null Sets

本讲主要是论证积分的基本结论在 $\mathrm{a.e.}$ 的情形下也都成立。此外介绍了非负可测函数列积分的 Fatou 定理，它是上一讲中单调收敛定理的直接推论：
$$\int\liminf f_n\du \leq \liminf \int f_n\du.$$

另一个重要结论是 Borel-Cantelli 引理：

> **Borel-Cantelli (Ⅰ)**：如果 $\sum_{n=0}^\infty\mu(A_n)<\infty$，则 $\mu\{A_n\io\}=0$。

这个用积分很容易看出来：
$$\sum_{n=0}^\infty\mu(A_n)=\int\sum_{n=0}^\infty\ind_{A_n}\du.$$
左边如果有限，那么右边的函数必须几乎处处有限，所以 $\{A_n\io\}$ 是零测集。


# 9.2 L1 and the DCT

本讲引入了一般可积函数的定义，并证明了控制收敛定理。

> **定义**：称 $f\in\Lone$ 为可积函数，如果 $f^+,f^-$ 都是可积的：$\int f^{\pm}\du<\infty$。此时我们定义 $\int f=\int f^+-\int f^-$。或者等价地，$f$ 可积当且仅当 $\int |f|\du<\infty$。

对可积函数，积分是**线性的**、**保持单调性的**。

如果我们将几乎处处相等的函数看作是同一个函数的话，$\|\cdot\|_{L^1}$ 是可积函数空间上的度量。

{% blockquote %}
**控制收敛定理**：设 $f_n, g$ 都是可积函数并且 $|f_n|\leq g$，$\lim\limits_{n\to\infty}f_n=f$。
则 $f$ 也是可积函数并且 $\lim\limits_{n\to\infty}\int f_n=\int f$。
{% endblockquote %}
**证明概要**：显然 $|f|\leq g$，所以 $f$ 可积，从而由线性性质 $g\pm f$ 都是可积的。对可积函数序列 $g\pm f_n$ 使用 Fatou 引理，有
$$\int\liminf (g\pm f_n)\du\leq \liminf\int (g\pm f_n)\du = \int g\du\pm\liminf\int f_n\du.$$
比较两边有
$$\int (g\pm f)\du \leq \int g\du \pm \liminf\int f_n\du.$$
消去 $g$ 的积分，并注意对任一数列 $a_n$ 有 $\liminf (-a_n)=-\limsup a_n$，从而
$$\limsup\int f_n\du \leq \int f\du \leq \liminf\int f_n\du.$$
即得结论。

# 11.1 The Radon-Nikodym Theorem

本讲介绍了 Radon-Nikodym 定理，不过没有给出证明。

**Motivation**: 设 $\mu,\nu$ 是两个测度，是否存在非负可测函数 $\rho$ 使得 $\nu(A)=\int_A\rho\du$ 对任何可测集 $A$ 成立？

**必要条件**：$\mu(A)=0\Rightarrow\nu(A)=0$。这时我们称 $\nu$ 关于 $\mu$ **绝对连续**，记作 $\nu\ll\mu$。

此条件同样也是充分的：若 $\nu$ 关于 $\mu$ 绝对连续，则存在 $\rho$ 使得 $\rho=\dfrac{\mathrm{d}\nu}{\mathrm{d}\mu}$。

**奇异连续测度的例子**：Cantor 函数 (devil staircase)。[YouTube 科普](https://www.youtube.com/watch?v=dQXVn7pFsVI)。此函数没有点质量，也没有密度函数，但是确实给出一个全质量为 1 的概率测度。

+ 此函数是连续递增的，所以是一个分布函数。
+ 此函数是连续的，所以没有点质量，即单个点的测度是 0。
+ 此函数是奇异的，因为它在除去 Cantor 集对应的点之外几乎处处是常数。

# 11.2 Probability Laws Revisited

本讲主要介绍了计算积分的变量替换定理，但没有给出证明。

> **定理**：设 $X:\ (\Omega,\mathcal{F},\mu)\to(\mathcal{S},\mathcal{B})$ 是一个可测映射，$(\mathcal{S},\mathcal{B})$ 上的测度 $\nu$ 由 $\nu(E) = \mu(X^{-1}(E))$ 给出，$g:\ (\mathcal{S},\mathcal{B},\nu)\to\mathbb{R}$ 是一个可积函数，则 $$\int_{\Omega}g\circ X\du=\int_{\mathcal{S}}g\dv.$$

**证明概要**：设 $E\subseteq\mathcal{S}$ 是可测集，则有恒等式
$$\ind_{X^{-1}(E)}(\omega)=\ind_E\circ X(\omega).$$
所以两边对不同 $E$ 的线性组合也成立：
$$\left(\sum a_i\ind_{X^{-1}(E_i)}\right)(\omega)=\left(\sum _ia_i\ind_{E_i}\right)\circ X(\omega).$$
两边在 $\Omega$ 上积分即得结论对简单函数 $g$ 成立。

# 12.1 $L^2$

无要点

# 12.2 The Weak Law of Large Numbers (WLLN)

无要点。注意：

+ 弱大数定律并不要求 $\iid$，要求的是两两不相关。(和的方差等于方差的和)
+ 而且要求期望和方差都相同，从而是 $L^2$ 序列。
+ 给出的结果是平均值依测度收敛到共同的期望。

# 13.1 Convergence in measure

本讲介绍了可测函数的依测度收敛概念，及其与逐点收敛之间的联系。

{% blockquote %}
**定义**：称 $f_n\to_{\mu} f$ 为依测度收敛，如果对任意 $\epsilon >0$ 有
$$\lim_{n\to\infty}\mu\{|f_n-f|\geq0\}=0.$$
{% endblockquote %}

**依测度收敛但不处处收敛的例子**：将区间 $[0, 1]$ 等分为 $2^n$ 份，将它们的指标函数依次排开，再对所有 $n$ 将这些指标函数排列起来得到序列 $f_n$，则 $f_n$ 依测度收敛但不逐点收敛。

**重要技巧**：$f_n\to f,\ae$ 收敛等价于对任何 $\epsilon>0$ 有
$$\mu\{|f_n-f|\geq\epsilon,\io\} = 0.$$
这样就可以把逐点收敛和测度联系起来。有时候我们还可以使用更强的条件：
$$\mu\{|f_n-f|\geq 2^{-n},\io\} = 0.$$
这是因为当 $2^{-n}<\epsilon$ 时 $\{|f_n-f|\geq\epsilon\}\subseteq\{|f_n-f|\geq 2^{-n}\}$，前者发生无穷多次自然意味着后者也发生无穷多次。这样就可以和 Borel-Cantelli 引理结合起来使用。

{% blockquote %}
**定理**：逐点收敛可以推出依测度收敛。
{% endblockquote %}
**简要证明**：对任何 $\epsilon>0$，记 $A_n=\{|f_n-f|\geq\epsilon\}$，则
$$\mu\{A_n \io\} = \lim_{n\to\infty}\mu(\bigcup_{k\geq n}A_k)\geq \lim_{n\to\infty}\mu(A_n).$$

{% blockquote %}
**定理**：设 $\{f_n\}$ 为依测度收敛的 Cauchy 序列：
$$\lim_{n,m\to\infty}\mu\{|f_n-f_m|\geq\epsilon\} = 0.$$
则 $f_n$ 必有逐点收敛的子序列 $f_{n_k}\to f\ \mathrm{a.e.}$，并且 $f_n$ 依测度收敛到 $f$。
{% endblockquote %}
**简要证明必有逐点收敛的子序列**：利用上面介绍的技巧，归结为抽取子序列 $\{f_{n_k}\}$ 满足
$$\mu\{|f_{n_{k+1}} - f_{n_k}|\geq2^{-k}\io\} = 0.$$
利用 Borel-Cantelli 引理这只要让 $\sum_{k=1}^\infty\mu\{|f_{n_{k+1}} - f_{n_k}|\geq 2^{-k}\}<\infty$ 即可。为此又只要让 $\mu\{|f_{n_{k+1}} - f_{n_k}|\geq 2^{-k}\}\leq 2^{-k}$ 即可。根据 Cauchy 条件这是可以做到的。

**简要证明这个子序列的逐点极限是原序列的依测度极限**：对任何 $n$，取 $n_{k}>n$ 则有
$$\{|f_n-f|\geq\epsilon\}\subseteq \{|f_n-f_{n_k}|\geq\epsilon/2\}\cup \{|f_{n_k}-f|\geq\epsilon/2\}.$$
显然 $n$ 足够大时右边两个集合测度都趋于 0。

# 13.2 $L^p$ is Complete

首先证明了 $L^p$ 收敛可以推出依测度收敛。

> **定理**：$L^p$ 度量是完备的，任何 Cauchy 序列必有极限。

**证明概要**：$L^p$ Cauchy 列也都是依测度 Cauchy 列，从而有几乎处处收敛的子序列 $f_{n_k}\to f$。
$$\begin{align*}\int\|f_{n_k}-f\|^p\du&=\int\lim_{j\to\infty}\|f_{n_k}-f_{n_j}\|^p\du\leq\liminf_{j\to\infty}\int\|f_{n_k}-f_{n_j}\|^p\du\\
&\leq\limsup_{j\to\infty}\int\|f_{n_k}-f_{n_j}\|^p\du.\end{align*}$$
两边令 $k\to\infty$ 并利用 Cauchy 条件即得子序列 $f_{n_k}\xrightarrow{L^p}f$。再利用 Cauchy 条件可得原序列 $f_n\xrightarrow{L^p} f$。

> **依测度控制收敛定理**：设 $f_n$ 依测度收敛到 $f$，且 $|f_n|\leq f,\, f\in L^1$。则 $f_n\xrightarrow{L^1} f$。

**证明概要**：假设 $f_n$ 不 $L^1$ 收敛到 $f$，则对任何 $\epsilon>0$，存在子序列 $f_{n_k}$ 满足：

+ $\|f_{n_k} - f\|_{L^1}\geq\epsilon$。
+ $f_{n_k}$ 几乎处处收敛到 $f$。

这与控制收敛定理矛盾。

# 14.1 Dynkin's Multiplicative Systems Theorem

本讲介绍了 Dynkin $\pi-\lambda$ 定理的函数形式的版本。

> **定义**：设 $(\Omega,\mathcal{F})$ 是一个可测空间，称 $f$ 是一个关于 $\mathcal{F}$ 可测的有界函数，如果存在 $M>0$ 使得 $|f|\leq M\ae$ 成立。记 $\mathbb{B}(\Omega,\mathcal{F})$ 为全体这样的有界函数构成的向量空间。若 $\{f_n\}\in\mathbb{B}(M,\mathcal{F})$ 满足 $|f_n|\leq M\ae$ 并且 $f_n\to f\ae$，就称 $f_n$ **一致有界收敛到 $f$**。

> **定理**：设 $\mathcal{I}\subseteq\mathcal{F}$ 是一个 $\pi$- 系，设 $\mathbb{H}(\mathcal{I})\subseteq\mathbb{B}(\Omega,\mathcal{F})$ 满足如下条件：
>
> 1. $\mathbb{H}(\mathcal{I})$ 是一个向量空间。
> 2. $\mathbb{H}(\mathcal{I})$ 包含 $\Omega$ 上的常函数 $\ind$。
> 3. 若 $\{f_n\}$ 是 $\mathbb{H}(\mathcal{I})$ 中的可测函数序列，且 $f_n$ 一致有界收敛到 $f$，则 $f\in\mathbb{H}(\mathcal{I})$。
> 4. $\mathbb{H}(\mathcal{I})$ 包含 $\mathcal{I}$ 中的所有指标函数 $\ind_{A},\,A\in\mathcal{I}$。
>
> **结论**：$\mathbb{H}(\mathcal{I})$ 包含所有关于 $\sigma(\mathcal{I})$- 可测的有界函数。

**证明概要**：设
$$\mathcal{A}=\{A\in\mathcal{F}:\ \ind_A\in\mathbb{H}(\mathcal{I})\}.$$

+ 由 2 $\Omega\in\mathcal{A}$。
+ 由 1, 2 结合有若 $A\in\mathcal{A}$ 则 $A^c\in\mathcal{A}$。
+ 由 3 有若 $\{A_n\}\in\mathcal{A}$，$A_n\uparrow$ 则 $\cup_{n}A_n\in\mathcal{A}$。

于是 $\mathcal{A}$ 是一个 $\lambda$- 系，并且由 4 有 $\mathcal{A}\supseteq\mathcal{I}$，从而 $\mathcal{A}\supseteq\sigma(\mathcal{I})$。于是 $\mathbb{H}(\mathcal{I})$ 包含所有形如 $\ind_A,\,A\in\sigma(\mathcal{I})$ 的指标函数，也就包含所有 $\sigma(\mathcal{I})$ 上的简单可测函数，从而包含它们的所有一致有界极限，即全体 $\sigma(\mathcal{I})$- 可测的有界函数。

**补充**：条件 3 其实可以减弱为 $\{f_n\}$ 是非负可测函数序列，且 $f_n\uparrow f$，$f$ 有界。这样我们首先得到 $\mathbb{H}(\mathcal{I})$ 包含所有 $\sigma(\mathcal{I})$ 上的非负简单函数，因而包含所有的非负有界可测函数，而对任何一般的 $\sigma(\mathcal{I})$ 有界可测函数 $f$，$f^{\pm}$ 都是 $\sigma(\mathcal{I})$ 上的非负有界可测函数，因而 $f^{\pm}$ 和它们的差 $f=f^+-f^-$ 都属于 $\mathbb{H}(\mathcal{I})$。

# 14.2 Product Measure

本讲介绍了乘积测度的构造。**记住乘积测度的构造是用到重积分的**。

**可测空间的乘积**：设 $(\Omega_1,\mathcal{F_1}),\,(\Omega_2,\mathcal{F_2})$ 是两个可测空间，其乘积空间定义为 $(\Omega_1\times\Omega_2,\,\sigma(\mathcal{F}_1\times\mathcal{F}_2))$。其中 $\mathcal{F}_1\otimes\mathcal{F}_2=\sigma(\mathcal{F}_1\times\mathcal{F}_2)$ 是由所有形如 $\{A_1\times A_2, A_i\in\mathcal{F}_i\}$ 的集合生成的 $\sigma$- 域。

$\mathcal{F}_1\otimes\mathcal{F}_2$ 还有一种等价的刻画：它是使得投影映射 $\pi_i(\omega_1,\omega_2)=\omega_i$ 均可测的最小 $\sigma$- 域。

> **引理**：随机向量 $f:(\Omega, \mathcal{F})\to(\R^d,\B(\R^d))$ 是可测的，当且仅当其每个分量 $f_i$ 是可测的。

$\Rightarrow$: 每个 $f_i=\pi_i\circ f$ 作为两个可测映射的复合当然是可测的。

$\Leftarrow$: 本质是证明如果每个 $X_i$ 都是随机变量，则 $X=(X_1,\ldots,X_n)$ 是随机向量。对任何形如 $E=E_i\times_{j\ne i}\B_i(\R)$ 的集合，$X^{-1}(E) =\{\omega\in\Omega: X_i(\omega)\in E_i\}$ 是可测集，而这样的 $E$ 生成了 $\B(\R^d)$，所以 $X^{-1}(E)$ 对任何 $E\subset\B(\R^d)$ 都可测。结论得证。

如果每个 $(\Omega_i,\F_i)$ 还是测度空间，其上的测度为 $\mu_i$，则我们可以在 $(\Omega_1\times\Omega_2,\F_1\otimes\F_2)$ 上定义测度 $\mu_1\otimes\mu_2$ 使得 $(\mu_1\otimes\mu_2)(E_1\times E_2)=\mu_1(E_1)\mu_2(E_2)$ 对任何 $E_i\in\F_i,\, i=1,2$ 成立。

实际上我们可以让这个乘积测度满足

$$\int_{\Omega_1\times\Omega_2}f_1\otimes f_2\mathrm{d}(\mu_1\otimes\mu_2) = \int_{\Omega_1}f_1\mathrm{d}\mu_1\cdot\int_{\Omega_2}f_2\mathrm{d}\mu_2.$$

考虑满足如下条件的乘积空间 $\Omega_1\times\Omega_2$ 上的可测函数 $f$:

> 1. $\omega_1\to f(\omega_1,\omega_2)$ 对任何 $\omega_2$ 都是可测函数。
> 2. $\omega_2\to f(\omega_1,\omega_2)$ 对任何 $\omega_1$ 都是可测函数。
> 3. $\omega_1\to \int_{\Omega_2}f(\omega_1,\omega_2)\mu_2(\mathrm{d}\omega_2)$ 是 $\F_1/\B(\overline{\R})$ 可测函数。注意这个积分值可能是无穷。
> 4. $\omega_2\to \int_{\Omega_1}f(\omega_1,\omega_2)\mu_1(\mathrm{d}\omega_1)$ 是 $\F_2/\B(\overline{\R})$ 可测函数。
> 5. $$\int_{\Omega_1}\left(\int_{\Omega_2}f(\omega_1,\omega_2)\mu_2(\mathrm{d}\omega_2)\right)\mu_1(\mathrm{d}\omega_1)=\int_{\Omega_2}\left(\int_{\Omega_1}f(\omega_1,\omega_2)\mu_1(\mathrm{d}\omega_1)\right)\mu_2(\mathrm{d}\omega_2).$$

容易验证对所有形如 $f_1\otimes f_2$ 的函数它们满足上面的性质。它们构成一个乘法系，包含所有形如 $\ind_{E_1}\otimes\ind_{E_2}$ 的函数，然后上面的条件对函数列的有界极限仍然成立。根据函数版本的 Dynkin 定理，上面的条件对所有有界可测函数，或者非负可测函数都成立。

由此我们可以定义乘积空间中的测度为

$$\mu(E)=\int_{\Omega_1}\left(\int_{\Omega_2}\ind_{E}\mu_2(\mathrm{d}\omega_2)\right)\mu_1(\mathrm{d}\omega_1)=\int_{\Omega_2}\left(\int_{\Omega_1}\ind_{E}\mu_1(\mathrm{d}\omega_1)\right)\mu_2(\mathrm{d}\omega_2).$$
不难验证这样定义的积分是有限可加的 (积分的线性性质)，可以取单调上升的极限，所以是可数可加的，并且当 $E$ 形如 $E_1\times E_2$ 时有 $\mu(E)=\mu_1(E_1)\mu_2(E_2)$，从而确实给出符合要求的乘积测度。


# 15.1 Independence

本讲介绍了事件和 $\sigma$- 域之间的独立性概念。

要点总结：

1. 若干个事件 $\{A_n\}$ 独立不是指它们两两独立，而是从中取出任何子集都独立。
2. 验证若干 $\sigma$- 域 $\{\mathcal{F}_i\}$ 独立只需要验证生成它们的 $\pi$- 系 $\{C_i:\ \mathcal{F}_i=\sigma(C_i)\}$ 独立。

> **Borel-Cantelli 引理 II**：设 $\{A_n\}$ 是独立的事件列，则若 $\sum_{n=1}^\infty\P(A_n)=\infty$，则 $\P(\{A_n,\io\})=1$。

想法还是要用独立性，转到事件的交上去。

$$\P(\{A_n,\io\})=\P(\bigcap_{n=1}^\infty\bigcup_{k\geq n}A_k)=\lim_{n\to\infty}\P(\bigcup_{k\geq n}A_k).$$
观察两边，要想用上独立性，就得取补：
$$1-\P(\bigcup_{k\geq n}A_k)=\P(\bigcap_{k\geq n}A_k^c)=\lim_{M\to\infty}\prod_{k=n}^M\P(A_k^c)=\lim_{M\to\infty y}\prod_{k=n}^M(1-\P(A_k)).$$
利用 $1-x\leq e^{-x}$ 有
$$\lim_{M\to\infty}\prod_{k=n}^M(1-\P(A_k))\leq\lim_{M\to\infty}\prod_{k=n}^Me^{-\P(A_k)}=\lim_{M\to\infty}e^{-\sum_{k=n}^M\P(A_k)}.$$
上式右边对任何固定的 $n$ 其极限都是 0，从而 $\P(\bigcup_{k\geq n}A_k)\to1$，结论得证。


# 17.1 Kolmogorov's 0-1 Law

本讲介绍了独立随机变量序列的尾事件，以及 Kolmogrov 0-1 律。

设 $\{X_n\}$ 是独立的随机变量序列 (不是两两独立，而是任何有限多个都独立)称 $\mathcal{T}=\cap_{n=1}^\infty\sigma(X_n,X_{n+1},\ldots)$ 为尾事件域。

> **Kolmogrov 0-1 律**：对任何 $A\in\mathcal{T}$ 有 $\mathbb{P}(A)\in\{0,1\}$。

**证明概要**：

+ $\sigma(X_1,\ldots,X_n)$ 和 $\sigma(X_{n+1},X_{n+2},\ldots)$ 是独立的。因为考虑如下两个集合族：
$$\{\text{all finite intersections like }\cap A_i, A_i\in\sigma(X_i),i=1,2,\ldots,n\}.$$
$$\{\text{all finite intersections like }\cap A_j, A_j\in\sigma(X_j),j=n+1,n+2,\ldots\}.$$
这俩都是 $\pi$- 系且互相独立，所以它们生成的 $\sigma$- 域也独立。前者可以生成 $\sigma(X_1,\ldots,X_n)$，后者可以生成 $\sigma(X_{n+1},X_{n+2},\ldots)$。
+ 于是 $\sigma(X_1,\ldots,X_n)$ 和 $\mathcal{T}$ 是独立的。
+ 于是 $\pi$- 系 $\cup_{n=1}^\infty\sigma(X_1,\ldots,X_n)$ 和 $\mathcal{T}$ 是独立的。
+ 于是 $\sigma$- 域 $\sigma(X_1,\ldots,X_n,\ldots)$ 和 $\mathcal{T}$ 独立，从而 $\mathcal{T}$ 和 $\mathcal{T}$ 独立，从而得证。

# 18.1 Strong Law of Large Numbers, Part 1

本讲介绍了 Kolmogrov 强大数定理的表述，以及证明思想。

基本思想是利用截断的序列与原序列是尾等价的，先对截断的序列证明结论，再回到原序列。


> **强大数定理**：设 $\{X_n\}$ 是 $\iid$ 的 $L^1$ 序列且 $\E [X_n]=a$，则 $\dfrac{S_n}{n}\to a, \ae$。

**重要技巧**：同一个概率空间上的两个序列 $\{X_n\},\,\{Y_n\}$ 称作是尾等价的，如果
$\sum_{n=1}^\infty\mathbb{P}(X_n\ne Y_n)<\infty$。

这样根据 Borel-Cantelli 引理，$\{X_n\ne Y_n,\io\}$ 是零测集，从而 $X_n=Y_n$ 最终会几乎处处成立，从而二者的极限行为一致。即如果 $b_n\uparrow\infty$，则
$$\lim\limits_{n\to\infty}\dfrac{1}{b_n}\sum_{j=1}^n X_n = X \Leftrightarrow \lim\limits_{n\to\infty}\dfrac{1}{b_n}\sum_{j=1}^n Y_n = X.$$

**截断的序列和原序列是尾等价的**

> **引理**：若 $X\in L^1,\,\epsilon>0$，则 $$\sum_{n=1}^\infty\mathbb{P}(X\geq n\epsilon) \leq\frac{1}{\epsilon}\mathbb{E}|X|.$$

值得与 Markov 不等式比较一下，这个不等式更强。

**证明概要**：只要证明结论对 $\epsilon=1$ 成立即可。而这非常显然：

$$X\geq\lfloor X\rfloor = \sum_{n=1}^\infty \ind_{\{n\leq X\}}.$$

> **推论**：若 $\{X_n\}$ 是 $\iid$ 的 $L^1$ 序列，令 $Y_n = X_n\ind_{\{|X_n|\leq n\}}$，则 $\{Y_n\}$ 与 $\{X_n\}$ 是尾等价的。

于是接下来的任务就是证明 $S_n^Y = \dfrac{Y_1+\cdots+Y_n}{n}\to a,\,\ae$。


# 18.2 Kolmogorov's Convergence Criterion

本讲介绍了 Kolmogrov 收敛判定：独立随机变量序列如果是 $L^2$ 意义下的 Cauchy 序列，则也是逐点收敛意义下的 Cauchy 序列。

在上一讲中，我们通过把 $L^1$ 的序列 $\{X_n\}$ 取截断得到 $Y_n=X_n\ind_{\{|X_n|\leq n\}}$，这是一个与 $\{X_n\}$ 尾等价的序列。从而只要证明 $\frac{\sum_{k=1}^n Y_k}{n}\to a$。为此我们分两步：

1. 证明 $\frac{\sum_{k=1}^n (Y_k-\E Y_k)}{n}\to 0$。
2. 证明 $\E Y_n\to a$，从而 $\frac{\sum_{k=1}^n\E Y_k}{n}\to a$。结合上一点就证明了强大数定理。

2 用控制收敛定理很容易得出，所以关键是证明 1。

我们首先证明 $\sum_{k=1}^n \frac{Y_k-\E Y_k}{n}$ 是个收敛的序列，然后用下一讲介绍的 Kronecker 引理来得出 $\frac{\sum_{k=1}^n (Y_k-\E Y_k)}{n}\to 0$。

> **Kolmogrov 收敛判定**：若 $\iid$ 序列 $Z_n$ 满足 $\sum\mathrm{Var}(Z_n)<\infty$ 则 $\sum(Z_n-\E Z_n)$ 几乎处处收敛。

**证明概要**：我们可以不妨假设 $\E Z_n=0$，则问题变为若 $\iid$ 序列 $\sum\E |Z_n|^2$ 收敛，则 $\sum Z_n$ 几乎处处收敛。

记 $S_n=\sum_{k=1}^nZ_k$，利用 Markov 不等式不难有
$$\P(|S_n|\geq\epsilon)\leq \frac{1}{\epsilon^2}\E[S_n^2].$$
有意思的是，上面的不等式中在左边把 $S_n$ 换成 $S_n^\ast=\max_{1\leq i\leq n}|S_n|$ 仍然成立：

> **Kolmogrov 极大不等式**：对任何正数 $\epsilon>0$ 有
> $$\P(S_n^\ast\geq\epsilon)\leq \frac{1}{\epsilon^2}\E[S_n]^2.$$

证明：记 $\tau=\inf\{j\in\mathbb{Z}_{\geq1}:\ |S_j|\geq\epsilon\}$。则 $\P(S_n^\ast\geq\epsilon)=\P(\tau\leq n)$。
$$\E[S_n^2:\ S_n^\ast\geq\epsilon]=\E[S_n^2:\ \tau\leq n]=\sum_{k=1}^n\E[S_n^2:\ \tau=k].$$
使用技巧 $S_n^2=(S_k + S_n - S_k)^2$ 我们有
$$\E[S_n^2:\ \tau=k] = \E[S_k^2 + (S_n-S_k)^2:\ \tau=k] + \E[2S_k(S_n-S_k):\ \tau=k].$$
注意到第二项
$$\E[2S_k(S_n-S_k):\ \tau=k] = \E[2S_k\ind_{\{\tau=k\}}(S_n-S_k)]=2\E[S_k\ind_{\{\tau=k\}}]\cdot\E[S_n-S_k]=0.$$
所以
$$\E[S_n^2]\geq\sum_{k=1}^n\E[S_n^2:\ \tau=k] \geq \sum_{k=1}^n\E[S_k^2:\ \tau=k]\geq\epsilon^2\sum_{k=1}^n\E\ind_{\{\tau=k\}}=\epsilon^2\P(\tau\leq n)=\epsilon^2 \P(S_n^\ast\geq\epsilon).$$

回到 Kolmogrov 收敛定理的证明。

Kolmogrov 极大不等式告诉我们

$$\P(\max_{n\leq k \leq m}|S_k - S_n|\geq\epsilon)\leq \frac{1}{\epsilon^2}\E|S_m-S_n|^2=\frac{1}{\epsilon^2}\sum_{k=n}^m \E Z_k^2.$$
令 $m\to\infty$ 我们有
$$\P(\sup_{k\geq n}|S_k - S_n|\geq\epsilon)\leq\frac{1}{\epsilon^2}\sum_{k=n}^\infty \E Z_k^2.$$
于是
$$\P(\sup_{k,j\geq n}|S_k - S_j|\geq\epsilon)\leq\frac{2}{\epsilon^2}\sum_{k=n}^\infty \E Z_k^2.$$
所以随机变量序列 $\delta_n = \sup_{k,j\geq n}|S_k - S_j|$ 依测度收敛到 0。但是 $\delta_n$ 是一个单调下降的非负序列，它必然有一个几乎处处收敛的极限 $\delta$，$\delta$ 也非负。$\delta$ 依测度收敛到 0，又几乎处处收敛到 $\delta$，那必须 $\delta$ 几乎处处为 0，即 $\{S_n\}$ 是 Cauchy 序列。

# 19.1 Strong Law of Large Numbers, Part 2

介绍了证明强大数定理的第二个工具：Kronecker 引理。

> **Kronecker 引理**：若 $\{b_k\}\uparrow\infty$ 且 $\lim\limits_{n\to\infty}\sum\limits_{k=1}^n\dfrac{x_k}{b_k}$ 存在，则 $\lim\limits_{n\to\infty}\dfrac{1}{b_n}\sum\limits_{k=1}^n x_k=0$。

**证明概要**：记 $u_n=\sum\limits_{k=1}^n\dfrac{x_k}{b_k},\,u_0=0$，则 $\lim\limits_{n\to\infty}u_n=s$ 存在。
$$\begin{align*}\frac{1}{b_n}\sum_{k=1}^n x_k&=\frac{1}{b_n}\sum_{k=1}^n(u_k-u_{k-1})b_k=\frac{1}{b_n}\sum_{k=1}^nu_kb_k-\frac{1}{b_n}\sum_{k=0}^{n-1}u_kb_{k+1}\\&=u_n-\frac{b_n-b_1}{b_n}s-\sum_{k=1}^{n-1}\frac{b_{k+1}-b_k}{b_n}(u_k-s).\end{align*}$$
而最后一个余项的绝对值小于等于
$$\begin{align*}\sum_{k=1}^{n-1}\frac{b_{k+1}-b_k}{b_n}|u_k-s|=\left(\sum_{k=1}^{N}+\sum_{k=N+1}^{n-1}\right)\frac{b_{k+1}-b_k}{b_n}|u_k-s|\end{align*}$$
这里对 $n>N$ 有 $|u_n-s|<\epsilon$ 成立。

当 $n\to\infty$ 时第一个和项是一个有界的值除以 $b_n$ 从而趋于 0。第二个和项显然不大于 $\dfrac{b_n}{b_n}\epsilon$，所以这个余项可以任意小。

> **引理**：$Y_n' = Y_n/n$ 满足 Kolmogrov 收敛判定。

**证明概要**：
$$\begin{align*}\sum_{n=1}^\infty\mathrm{Var}(Y_n')&=\sum_{n=1}^\infty\frac{\mathbb{E}Y_n^2 - (\mathbb{E}Y_n)^2}{n^2}\leq \sum_{n=1}^\infty\frac{\mathbb{E}Y_n^2}{n^2}\\&=\sum_{n=1}^\infty\frac{\mathbb{E}X_n^2\ind_{\{|X_n|\leq n\}}}{n^2}\\&=\mathbb{E}\left[|X_1|^2\sum_{n=1}^\infty\frac{1}{n^2}\ind_{\{|X_1|\leq n\}}\right]\\&\leq\mathbb{E}\left[|X_1|^2\sum_{n=1}^\infty\frac{1}{n^2},\ |X_1|\leq 2\right] + \mathbb{E}\left[|X_1|^2\sum_{n=1}^\infty\frac{1}{n^2}\ind_{\{|X_1|\leq n\}},\ |X_1|>2\right]\\&\leq4\sum_{n=1}^\infty\frac{1}{n^2}+\mathbb{E}\left[|X_1|^2\sum_{n=1}^\infty\frac{1}{n^2}\ind_{\{|X_1|\leq n\}},\ |X_1|>2\right] .\end{align*}$$
为什么要用 $|X_1|$ 是否大于 2 把它分成两部分？这里其实可以用任何大于等于 2 的数，不过 2 已经足够了，这样做的原因下面就会看到。

现在第一项是有限的，我们只要说明第二项也有限即可。你可能想把 $\ind_{\{|X_1|\leq n\}}$ 扔掉，但是注意强大数定律中 $|X_1|$ 是 $L^1$ 可积的，未必是 $L^2$ 可积的，所以扔掉是不行的。我们得把 $\sum_{n=1}^\infty\frac{1}{n^2}\ind_{\{|X_1|\leq n\}}$ 这个东西估计一下。注意到对任何正整数 $k$，$\sum_{n=k}^\infty\frac{1}{n^2}$ 就是 $\frac{1}{\lfloor t\rfloor^2}$ 在 $[k,\infty)$ 上的积分， 所以当 $x>2$ 时
$$\begin{align*}
\sum_{n=1}^\infty\frac{1}{n^2}\ind_{\{x\leq n\}}&=\sum_{n\geq x}^\infty\frac{1}{n^2}=\sum_{n= \lceil x\rceil}^\infty\frac{1}{n^2}\\&=\int_{\lceil x\rceil}^\infty\frac{1}{\lfloor t\rfloor^2}\,\mathrm{d}t\\&\leq \int_{\lceil x\rceil}^\infty\frac{1}{(t-1)^2}\,\mathrm{d}t\\&=\frac{1}{\lceil x\rceil - 1}\\&\leq\frac{1}{x-1}<\frac{2}{x}.\end{align*}$$
所以取 $x>2$ 主要是为了最后一步的 $\frac{1}{x-1}<\frac{2}{x}$。

于是我们就证明了在 $|X_1|>2$ 上有
$$\sum_{n=1}^\infty\frac{1}{n^2}\ind_{\{|X_1|\leq n\}}<\frac{2}{|X_1|}.$$
两边乘以 $|X_1|^2$ 并积分，则
$$\mathbb{E}\left[|X_1|^2\sum_{n=1}^\infty\frac{1}{n^2}\ind_{\{|X_1|\leq n\}},\ |X_1|>2\right] < 2\mathbb{E}|X_1|.$$
这就证明了结论。

# 19.2 Renewal Theory

本讲以灯泡寿命为例子，介绍了强大数定理在更新理论中的应用。

设灯泡的寿命互相独立，且服从某个共同的非负随机变量 $X,\ \E X<\infty$。设长度为 $t$ 的时刻内需要报废的灯泡数最多为 $N_t$，即 $S_{N_t}\leq t < S_{N_t+1}$。则
$$\lim_{t\to\infty}\frac{N_t}{t}\to\frac{1}{\E X},\quad \ae$$
实际上由定义有
$$\frac{S_{N_t}}{N_t}\leq \frac{t}{N_t} < \frac{S_{N_t+1}}{N_t}.$$
如果我们能证明 $t\to\infty$ 时同样有 $N_t\to\infty,\ae$，则利用强大数定理就有 $S_{N_t}/N_t\to\E X$，从而结论得证。

我们考虑 $\Omega_1=\{\omega\in\Omega\mid S_n(\omega)<\infty,\ \forall n\geq1\}$。$\Omega_1$ 作为一列递减的测度均为 1 的集合列的极限，测度显然也是 1。我们只要证明在 $\Omega_1$ 上有 $S_{N_t}/N_t\to\E X$ 成立。

首先 $N_t$ 随着 $t$ 递增是没有问题的，如果它对某个 $\omega$ 是有界的，则 $N_t(\omega)\leq M$ 对所有 $t$ 成立。即不管 $t$ 是多少都有 $S_M\leq t < S_{M+1}$，这只能要求 $S_{M+1}(\omega)=\infty$，从而 $\omega$ 不属于 $\Omega_1$。

一个有意思的引理：

> **引理**：设 $X\in L^1$，如果 $\{X_n\}$ 是一列 $\iid$ 且服从和 $X$ 同样的分布，则 $\dfrac{X_n}{n}\to0,\ae$。

老技巧，只要证明 $\P(\{|X_n|\geq n\epsilon,\ \io\})=0$ 即可。根据 Borel-Cantelli 引理，只要证明 $\sum_{n=1}^\infty\P(|X_n|\geq n\epsilon)<\infty$ 即可，而这在 18.1 中已经证明过了。


# 24.1 Complex Integration and Dynkin's Theorem

无要点

# 24.2 Characteristic Function

本讲介绍了随机变量的特征函数及其基本性质。整体内容比较基础。

# 31.1 Orthogonal Projections

无要点

# 33.1 Probability Kernels, Part 1

本讲引入了概率核的概念。

设 $(S_i,\B_i), i=1,2$ 是两个可测空间，一个概率核 $Q(x, B):(S_1,\B_2)\to[0,1]$ 是一个二元函数，满足：

1. 对任何 $x\in S_1$，$Q(x,\cdot):\B_2\to[0,1]$ 是 $(S_2,\B_2)$ 上的概率测度。
2. 对任何 $B\in \B_2$，$Q(\cdot, B):S_1\to[0,1]$ 是 $(S_1,\B_1)$ 上的可测函数。

> **引理**：假设 $f(x,y)\in (S_1\times S_2, \B_1\otimes\B_2)$ 是乘积空间上的可测函数，并且是有界的或者非负的，则积分 $$x\to\int_{S_2}f(x,y)Q(x,\pd{y})$$ 是关于 $x$ 的可测函数。

此引理不难从简单函数 $\ind_{B_1\times B_2}(x,y)=\ind_{B_1}(x)\ind_{B_2}(y)$ 出发，使用函数形式的 Dynkin 引理得到。

由此对任何 $(S_1,\B_1)$ 上的测度 $\mu$，我们可以定义乘积空间 $(S_1\times S_2, \B_1\otimes\B_2)$ 上的乘积测度 $\mu\otimes Q$，这个乘积测度是随 $x$ 变化而变化的：
$$\mu\otimes Q(E)=\int_{S_1}\mu(\pd{x})\int_{S_2}\ind_{C}(x,y)Q(x,\pd{y}).$$
不过这真的是一个概率测度吗？你可以用积分的线性性质立刻看出它是有限可加的，并且利用积分项有界和控制收敛定理立刻看出它是可数可加的，所以确实是个概率测度。

有了概率核的乘积测度，我们自然要研究对这种测度的积分。由于这个测度本身就是通过对示性函数积分来定义的，所以其上的积分也具有类似的性质：

> **引理**：假设 $f(x,y)$ 是乘积空间的可测函数，并且是有界或者非负的，则
> $$\int_{S_1\times S_2}f\pd{(\mu\otimes Q)} = \int_{S_1}\mu(\pd{x})\int_{S_2}f(x,y)Q(x,\pd{y}).$$

后面花了很大力气证明当 $Q(x, \cdot)=\widetilde{Q}(x,\cdot)$ 对几乎处处的 $x$ 成立时有 $\mu\otimes Q=\mu\otimes\widetilde{Q}$。没仔细看。

# 46.3 Wald's Identity

本讲介绍了 Wald 引理。

> **Wald 引理**：设 $\{X_n\}$ 是 $\iid$ 的随机变量序列，$\tau$ 是一个停时，则在 $\E|X_1|<\infty$ 且 $\E\tau<\infty$ 的条件下有 $\E\sum\limits_{n=1}^\tau X_n=\E X_1\cdot \E\tau$。

这里的关键在于将上面的求和变成一个二重级数求和，然后交换求和次序。

$$\begin{align*}\sum_{n=1}^\tau\E X_n&=\sum_{n=1}^\infty\E X_n\cdot \ind_{\tau\geq n}=\sum_{n=1}^\infty\E X_n\cdot\sum_{k=n}^\infty\ind_{\tau=k}\\&=\sum_{k=1}^\infty\ind_{\tau=k}\sum_{n=1}^k\E X_n\\&=\E X_1\sum_{k=1}^\infty k\cdot\ind_{\tau=k}\\&=\E X_1\cdot \E\tau.\end{align*}$$

我们为什么可以在第一行的第二个等号处交换求和次序？这是因为上面的推导对 $|X_n|$ 是成立的，并且离散积分值 $\E|X_1|\cdot\E \tau<\infty$，所以由控制收敛定理对原序列 $X_n$ 交换求和也是 OK 的。

# 48.1 Uniform Integrability

这一讲介绍了随机变量集合的一致可积性，要点非常多。

对任何 $L^1$ 的随机变量 $X$，总是可以找一个紧集 $K$，使得 $|X|$ 在 $K^c$ 上的积分任意小：对任何 $\epsilon>0$，存在 $a>0$ 使得 $\E[|X|:\ |X|\geq a]<\epsilon$。但是如果是一族可积的随机变量的话，这个统一的 $a$ 就未必存在了。

如果这样的 $a$ 总是存在的话，我们就称这族随机变量是一致可积的。

> **定义**：随机变量列 $\{X_n\}$ 称作是一致可积的 (UI) 的，如果它们满足以下条件：
>
> 1. 每个 $X_i$ 都是 $L^1$ 的。
> 2. 对任何 $\epsilon>0$，存在 $a>0$ 使得 $\sup_n\E[X_n:\ |X_n|\geq a]< \epsilon$。

不难验证如果 $\{X_n\}$ 被一个可积随机变量控制，则它们是一致可积的：

> **例子 1**：如果 $|X_n|\leq Y,\ Y\in L^1$，则 $\{X_n\}$ 是一致可积的。

这是因为被积函数和积分区域都可以放大：$\E[|X_n|:\ |X_n|\geq a]\leq\E[|Y|:\ |Y|\geq a]$。

> **例子 2**：如果 $\{X_n\}$ 是 $L^p,\,p>1$ 一致有界的：$\sup_n\E |X_n|^p<\infty$，则 $\{X_n\}$ 是一致可积的。

这是因为被积函数可以放大：
$$\E[|X|: |X|\geq a]\leq \E[|X|\cdot\frac{|X|^{p-1}}{a^{p-1}}: |X|\geq a] = \frac{1}{a^{p-1}}\E[|X|^p: |X|\geq a]\leq \frac{M}{a^{p-1}}.$$

这个例子中的 $p>1$ 是不能减弱为 $p\geq1$ 的。不过我们可以证明 UI 的变量族必然是 $L^1$ 一致有界的：

> **定理**：若 $\{X_n\}$ 一致可积，则 $\sup_n E|X_n| <\infty$。

取 $a$ 使得 $\sup_n \E[|X_n|: |X_n|\geq a] < 1$，则不难证明 $\E |X_n| < a+1$。

现在我们来给出一致绝对连续的概念，并将说明**一致可积 = $L^1$ 一致有界 + 一致绝对连续**。

> **定义**：随机变量序列 $\{X_n\}$ 是一致绝对连续的，如果对任何 $\epsilon>0$，都存在 $\delta>0$，使得只要集合 $B$ 满足 $\mu(B)<\delta$，就有 $\sup_n\E[|X_n|: B]<\epsilon$。

> **定理**：$\{X_n\}$ 一致可积当且仅当它们 $L^1$ 一致有界且一致绝对连续。

$\Rightarrow$: $L^1$ 一致有界已经有了。下证一致绝对连续性质。对任何可测集 $B$，我们考虑用一个待定的 $a>0$ 把积分 $\E[|X_n|: B]$ 变成
$$\E[|X_n|: B,\ |X_n|\geq a] + \E[|X_n|: B,\ |X_n|<a].$$
第一项小于等于  $\E[|X_n|: |X_n|\geq a]$，由一致可积性我们可以取 $a$ 使得它小于 $\epsilon/2$。第二项小于等于 $a\mu(B)$。所以只要 $\mu(B)<\delta=\frac{\epsilon}{2a}$ 即可。

$\Leftarrow$: 我们可以料想 $\{|X_n|\geq a\}$ 的测度是会一致地越来越小的：

$$\P(\{|X_n|\geq a\})=\E[1: |X_n|\geq a]\leq \E[\frac{|X_n|}{a}: |X_n|\geq a]\leq \frac{\E|X_n|}{a}=\frac{K}{a}.$$
其中 $K$ 是 $\{X_n\}$ 的 $L^1$ 上界。所以确实可以取 $a$ 适当大使得 $\{|X_n|\geq a\}$ 的测度一致地小于一致绝对连续性中所需要的那个 $\delta$。

> **定理**：一致可积性是平移不变的： $\{X_n\}$ 一致可积且 $Y\in L^1$，则 $\{X_n+Y\}$ 也是一致可积的。

为此只要证明它们一致 $L^1$ 有界且一致绝对连续。其中一致 $L^1$ 有界是显然的。

对于一致绝对连续，我们有
$$\E[|X_n+Y|: B]\leq\E[|X_n|:B] + \E[|Y|: B].$$
取 $\delta_1$ 使得只要 $\mu(B)<\delta_1$ 就有 $\E[|X_n|:B]<\frac{\epsilon}{2}$，再取 $\delta_2$ 使得只要 $\mu(B)<\delta_2$ 就有 $\E[|Y|:B]<\frac{\epsilon}{2}$，则 $\delta=\min\{\delta_1,\delta_2\}$ 符合要求。

最后一个重要定理是：**依 $L^1$ 范数收敛 = 一致可积 + 依测度收敛**。

> **定理**：随机变量序列 $X_n\xrightarrow{L^1} X$ 当且仅当 $X_n\xrightarrow{\P}X$ 且 $\{X_n\}$ 一致可积。

$\Rightarrow$: $L^1$ 收敛当然可以得出依测度收敛 (Markov 不等式一步即得)。要证明一致可积，我们只要根据平移不变性，证明 $Y_n=X_n-X$ 是一致可积的即可。

考虑取一个待定的正整数 $N$，则
$$\sup_n\E[|Y_n|: |Y_n|\geq a] \leq \sup_{n< N}\E[|Y_n|: |Y_n|\geq a] \vee \sup_{n\geq N}\E[|Y_n|: |Y_n|\geq a]$$
上面右边第一项是有限多个可积随机变量组成的集合，是一致可积的，所以只要 $a$ 足够大第一项是可以任意小的。第二项小于等于 $\E|Y_n|$ 并且由于 $\E|Y_n|\to 0$ 所以只要 $N$ 足够大也是可以任意小的。所以我们先取 $N$ 足够大使得 $\E|Y_n|<\epsilon/2$，再取 $a$ 足够大使得 $n<N$ 时 $\sup_{n< N}\E[|Y_n|: |Y_n|\geq a]<\epsilon/2$，就得到了一致可积性。

$\Leftarrow$: 记 $Y_n = X_n - X$，则 $Y_n\ind_{|Y_n|<a}$ 是一个不大于 $a$ 的函数序列，且依测度收敛到 0，从而由**依测度的控制收敛定理**有 $Y_n\ind_{|Y_n|<a}\xrightarrow{L^1}0$。
从而
$$\|X_n-X\|_{L^1} = \E[Y_n\ind_{\{|Y_n|<a\}}] + \E[Y_n\ind_{\{|Y_n|\geq a\}}].$$
第一项取 $n$ 足够大就可以任意小，第二项取 $a$ 足够大也可以任意小，得证。

> **推论**：正则鞅 $X_n = \E[X|\mathcal{F}_n]$ 是一致可积的。

反过来也是对的：鞅序列如果是一致可积的，则一定是正则鞅。
