---
title: TODO List
url: todo
---

# 写作

1. 一篇关于 SO3 的表示的文章，与球谐函数、有限群的不变量、Shephard-Todd 定理的关系。配一个 shadertoy demo。
2. S_n 和 GL(n) 的表示论，Schur-Weyl 对偶。
3. 六顶点模型，Yang-Baxter 方程和 ASM 的证明。
4. 对称平面分拆的 Macdonald 猜想，Hall 多项式，SL(n) 表示在计数中的应用。
5. 永不回到原点的二维随机游动，介绍 Doob h-变换、调和测度。
6. 扭结与动力系统
7. 随机游动常返判断的几种方法讨论/Markov 链平稳分布/遍历性基础知识回顾
8. Lie 代数的 Minuscule 表示与对称平面分拆
9. GTM A course in enumeration 中剩余的 highlight 问题。
10. 二维码与 Reed-Solomon 编码算法介绍
11. 有限状态机的 Hopcroft 最小化算法
12. 图的环空间与割空间，顶点膨胀技巧
13. Hopf 纤维丛，球面群结构，实可除代数
14. Hilbert 曲线算法与 Golay 码
15. Debruijn 方法绘制 aperiodic tiling 的详细解释
16. Aztec diamond arctic circle 现象的解释
17. Penrose tiling 科普文
18. Random walk, circle packing and conformal mapping.
19. Billiard ball，测度论，Poncelet 定理
20. Durrett 概率论 Brownian 运动部分改写
21. Indra's pearls 部分内容介绍，附 shadertoy 动画
22. Coxeter 群系列 之圆堆和有限状态机
23. Raymarching 中 sdf 函数与各种变换的数学证明
24. 正的 Hausdoff 维数意味常返性 http://www.cmat.edu.uy/~lessa/resource/randomwalknotes.pdf
25. 准晶，Faraday 驻波。
26. 连分数，圆堆，Fary。
27. Fulton algebraic curves, Poncelet porism 的代数几何证明和 Jacobi 椭圆函数证明
28. G2 and the rolling ball 是啥回事。
29. Mobius gear 和 Quaternion 是啥关系，flockaroo 的 shadertoy
30. 蜂巢和 Gauss 整数的关系：https://twitter.com/roice713/status/1497252225785204738?s=20&t=WN0vB5s3eU_riCbC37nWiA
31. Schwartz-Pick 引理怎么可视化？
32. stable diffusion 学习
33. Karman vortex 学习


# 编程

1. Python + cairo 实现 hyperbolic tiling 矢量绘图库。
2. shadertoy 实现 sphere gears，并解释与 SO3 的表示的关系
3. shaderoty 实现 Chinese Shanshui landscape
4. shaderoty 演示相对论
5. shadertoy 演示 Schottky 变换和 Droste 效应
6. shadertoy 实现自动微分和 implicit surface 渲染
7. surface evovler C++ 改写
8. 用这个 https://www.shadertoy.com/view/NlKXWt 写一个 doyle spiral 的例子
9. shadertoy 版本的 Jigsaw Penrose tiling
10. shadertoy 实现墙上有个镜子，无限反射的场景
11. Python 实现 Voronoi + LLoyd 算法，理解 mapbox 的那个实现原理
12. Stange + sl2c 的 shader 研究实现
13. missing mirror，用正方体万花筒内部反射实现 pseudo kleinian
14. 把 gifmaze 中 hilbert 曲线的例子改成对输入图像生成 hilbert 曲线图


## 长期想法

+ 实现一个页面，包含 tiling, circle packing, limit set, Strange 的图案等功能。
+ 相对论 + 机器猫
+ Faraday 驻波模拟


## 2023 春节假期

+ Thurston 的圆堆算法
+ 把 creative blocks 改改，渲染 mobius 变换
