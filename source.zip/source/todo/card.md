1. ~~Aztec 钻石图~~
2. ~~Beauty of roots~~
3. ~~112 阶完美正方形~~
4. ~~Fano 平面~~
5. Hilbert 曲线
6. Weierstrass 函数
7. Platonic solids
8. Apollonian 圆堆
9. Monotile
10. 模群
11. Lorentz 吸引子
12. ~~三体周期解~~
13. ~~Mandelbrot~~
14. 焦散
15. Bruhat-Tits 树
16. 双曲空间随机游动
17. The beauty of Schottky groups
18. 龙曲线和 Cantor 集合 (complex bases)
19. 电场线和 Marden 定理
20. 五点共圆问题
21. Klein 自守函数
22. E8 根系图
23. 复半单李代数的 Coxeter-Dynkin 图
24. 卡门涡街
25. 复变函数和 airy flow? 或者 rreusser 的 potential flow?
26. 黎曼曲面
27. Voronoi?
28. Hexagon lloyd 算法？
29. Thurston circle packing
30. Bianchi and polyhedra circle packing