---
title: "Walk the dog: winding number and Rouché theorem"
---

I made a Shadertoy animation that demonstrates a metaphor from chapter 7, "Winding numbers and topology", of Needham's famous book "Visual Complex Analysis":

A man and his dog walking around a tree in a park, both of their paths are closed curves, meaning they return to their starting point after some time. If the person keeps the dog leash tight enough, such that the dog cannot touch the tree, then after they return to their starting positions, the number of circles made around the tree by the person and the dog are the same: (The tree's location is the origin, marked with a dial)

<iframe width="640" height="360" frameborder="0" src="https://www.shadertoy.com/embed/fdK3RD?gui=true&t=10&paused=true&muted=false" allowfullscreen></iframe>

The math behind this animation is: If two closed curves $\gamma_1,\gamma_2$ do not pass through the origin and $\gamma_1$ can be continuously deformed into $\gamma_2$ without touching the origin (homotopy), then $\gamma_1,\gamma_2$ have the same [winding number](https://en.wikipedia.org/wiki/Winding_number) around the origin.

Note that this fact only requires $\gamma_1,\gamma_2:, [0,1]\to\mathbb{R}^2$ to be two continuous curves and does not involve analyticity. As the concepts of winding number and homotopy only require continuity.

When $\gamma_1=f(S^1),\gamma_2=g(S^1)$ are the images of the unit circle $S^1:\{z\in\mathbb{C}:|z|=1\}$ under two analytic functions $f,g$, the [argument principle](https://en.wikipedia.org/wiki/Argument_principle) tells us that the winding numbers of $\gamma_1,\gamma_2$ around the origin are equal to the number of zeros of $f,g$ inside $S^1$, respectively. Further, Rouché's theorem tells us that if for any $z\in S^1$ we have $|f(z)|>|f(z)-g(z)|$, then $\gamma_1,\gamma_2$ have the same winding number around the origin, thereby $f,g$ have the same number of zeros inside $S^1$. The condition of Rouché's theorem is essentially saying, if we assume the person's position is $f(z)$, the dog's position is $g(z)$, and the leash $l(z)=f(z)-g(z)$ has length $|l(z)|$  always less than the distance from the person to the origin $|f(z)|$, then it can be guaranteed that the dog cannot reach the origin.

In the animation, the circle in the bottom left is $S^1$, and the paths on the right in red and green are respectively $f(S^1)$ and $g(S^1)$. Here, $f$ is taken as
$$f(z) =\frac{z-a}{1-\overline{a}z}\frac{z-b}{1-\overline{b}z}\frac{z-c}{1-\overline{c}z} (z-2-2i),\quad |a|,|b|,|c|<1.$$
$f(z)$ has 3 roots $a,b,c$ inside $S^1$ (marked with red dots), has no roots on $S^1$, and has a root outside $S^1$ (not shown). The first three factors of $f(z)$ form a Blaschke product, mapping the inside of $S^1$ to its inside and mapping $S^1$ to $S^1$ itself, so for any $z\in S^1$ we have
$$|f(z)| = |z - 2 - 2i| \geq 2\sqrt{2} - 1,\quad z\in S^1.$$
Thus, as long as the leash $l(z)$ satisfies $|l(S^1)| < 2\sqrt{2}-1$, the dog's path $g(S^1)=f(S^1)+l(S^1)$ won't touch the origin. Here, I took $l(z) = cz$, where $c$ is a positive real number less than $2\sqrt{2}-1$.

Chapter 7 of Needham's book also discussed another fact: the winding number of a curve $\gamma$ is constant on each connected component of $\mathbb{C}\setminus\gamma$. For a point $z\notin\gamma$, we can slightly move $z$ to another point $z'$, as long as $z'$ remains within the same connected component as $z$, then $\gamma$ has the same winding number around $z$ and $z'$. Using this fact, combined with the argument principle, it's not difficult to derive the following corollary:

> **Corollary**: Let $\gamma$ be a simple closed curve, enclosing a region $\Omega$, and $f(z)$ be a non-constant analytic function that analytic in a region containing $\gamma$. Suppose there are two trees at points $w_0,,w_1$, and the human walking path $f(\gamma)$ always maintains a distance greater than the distance between the two trees from $w_0$: i.e.,
> $$|f(z)-w_0| > |w_0-w_1|$$
> for all $z\in\gamma$, then $f(\gamma)$ has the same winding number around $w_0,w_1$, thereby the number of preimages of $w_0,w_1$ inside $\Omega$ is the same:
>
> $$\sharp\{z\in \Omega: f(z)=w_0\} = \sharp\{z\in \Omega: f(z)=w_1\}.$$

This is because, under the assumption, moving from $w_0$ along the line segment $[w_0,w_1]$ to $w_1$ will never touch the curve $f(\gamma)$, so $w_0,w_1$ must be located within the same connected component of $\mathbb{C}\setminus f(\gamma)$.

<img style="margin:0px auto;display:block" src="/images/rouche/winding_number.svg" width="250" />

Using this corollary, we can easily derive the [open mapping theorem](https://en.wikipedia.org/wiki/Open_mapping_theorem_(complex_analysis)) of complex analysis:

> **Theorem**: If $U\subseteq\mathbb{C}$ is an open set and $f:U\to\mathbb{C}$ is a non-constant analytic function, then $f(U)$ is also an open set.

I leave the proof to you (feel free to write your answer in the comments section).