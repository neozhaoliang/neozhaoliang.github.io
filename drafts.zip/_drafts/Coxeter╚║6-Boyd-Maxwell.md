---
title: "Coxeter 群笔记（六）：Boyd-Maxwell 球堆"
categories: [Coxeter Groups]
date: 2021-12-09
url: "coxeter-groups-boyd-maxwell"
---

\newcommand{\lfun}[2]{\langle #1,\,#2\rangle}
\newcommand{\fd}{\mathcal{D}}
\newcommand{\tc}{\mathcal{C}}
\newcommand{\stab}[1]{\mathrm{Stab}(#1)}
\newcommand{\negf}[1]{\mathrm{Neg}(#1)}
\newcommand{\barfd}{\overline{\mathcal{D}}}
\newcommand{\plc}[1]{\mathrm{PLC}(#1)}
\newcommand{\barc}{\overline{C}}
\newcommand{\bartc}{\overline{\tc}}
\newcommand{\sthe}[1]{\dfrac{\sin #1\theta}{\sin\theta}}
\newcommand{\shthe}[1]{\dfrac{\sinh #1\theta}{\sinh\theta}}
\newcommand{\inn}{(\cdot,\cdot)}
\newcommand{\gl}{\mathrm{GL}}
\newcommand{\R}{\mathbb{R}}
\newcommand{\span}{\mathrm{span}}
\newcommand{\rad}{\mathrm{rad}}
\newcommand{\cl}[1]{\overline{ #1 }}
\newcommand{\Q}{\mathcal{Q}}
\newcommand{\N}{\mathcal{N}}
\newcommand{\cone}[1]{\mathrm{cone}(#1)}
\newcommand{\bfA}{\mathbf{A}}
\newcommand{\P}{\mathcal{P}}
\newcommand{\S}{\mathcal{S}}
\newcommand{\H}{\mathcal{H}}
\newcommand{\tcr}{\overline{\mathcal{C}_r}}
\newcommand{\sign}[1]{\mathrm{sgn}(#1)}
\newcommand{\Rntwo}{\mathbb{R}^{n+1,1}}
\newcommand{\PR}{\mathrm{P}(\mathbb{R}^{n+1,1})}
\newcommand{\L}{\mathbb{L}^{n+1}}
\newcommand{\PL}{\mathrm{P}(\mathbb{L}^{n+1})}
\newcommand{\LR}{\mathbb{R}^{n+1,1}}
\newcommand{\ER}{\overline{\mathbb{R}^n}}

本文的内容主要来自 [@Maxwell82] 和 [@Maxwell89]，并修复了一些错误。Maxwell 在 [@Maxwell82, pp 81] 中写到：（采用我们的记号）

:::{.simple}
When $\Gamma$ is hyperbolic, the cone

$$\{v\in V\mid (v,v)\leq0\}$$

has two connected components (after deleting 0), which are also the equivalent classes for the relation
$$u\sim v\Leftrightarrow (u,v)\leq0.$$
:::

这显然是错误的，因为对 light-like 的向量 $u$，$u$ 和 $-u$ 属于不同的分支。这个错误导致后面 [@Maxwell82, prop 3.1] 的证明需要作一些修改。详情见下面的 @Pre:thm-sphere-packing。


# 球的反演

在这一节中，我们约定 $V=\R^{n+1,1}$ 是 $n+2$ 维的 Lorentzian 空间，$\{e_1,e_2,\ldots,e_{n+2}\}$ 是 $V$ 的一组标准正交基，即在这组基下内积的 Gram 矩阵为
$$\begin{pmatrix}I_{n+1} &\\ & -1\end{pmatrix}.$$
令 $e_0=\frac{1}{2}(e_{n+2}-e_{n+1}),\, e_\infty=\frac{1}{2}(e_{n+2}+e_{n+1})$，则 $\{e_0,e_1,\ldots,e_n,e_\infty\}$ 也构成 $V$ 的一组基，内积在这组基下的 Gram 矩阵为
$$\begin{pmatrix}0&&&-\frac{1}{2}\\&I_n&&\\-\frac{1}{2}&&&0\end{pmatrix}.$$
任何 $v\in V$ 可以写成 $v=ae_0 + x + be_\infty\,(a,b\in\R)$ 的形式，其中 $x\in\span\{e_1,\ldots,e_n\}$ 是一个 Euclidean 空间中的向量。设 $w=ce_0+y+de_\infty\,(c,d\in\R)$ 是另一个向量，则 $v,w$ 之间的内积为：
$$(v,w)=(x,y)-\frac{1}{2}(ad+bc).$$

采用 $\{e_0,e_1,\ldots,e_n,e_\infty\}$ 这种基可能乍看起来很奇怪，但是在后面处理球面时，它相比使用 $\{e_1,e_2,\ldots,e_{n+2}\}$ 这组基会方便许多。


## 射影模型

设 $v\in\R^{n+1,1}$，我们约定用 $[v]$ 表示 $v$ 在射影空间 $\PR$ 中的等价类。

::: definition
定义光锥 (light cone/null cone) 为
$$\L = \{v\in \LR \mid(v,v)=0\}.$$
以及
$$\PL=\{[v]\mid v\in\L\setminus\{0\}\}.$$
$\PL$ 是 $\L$ 中所有直线组成的集合。
:::

熟知 $\ER=\R^n\cup\{\infty\}$ 和 $\R^{n+1}$ 中的单位球 $S^n=\{x_1^2+x_2^2+\cdots+x_{n+1}^2=1\}$ 在球极投影下是一一对应的（北极点为 $e_{n+1}$）。我们来说明它们分别和 $\PL$ 是一一对应的，并且当 $x\in\ER$ 和 $y\in S^n$ 在球极投影下对应时，它们在 $\PL$ 中是同一个点。

:::{.simple}
**$\PL$ 的第一种参数化表示** \

我们在 $\{e_1,\ldots,e_{n+2}\}$ 这组基下计算。

设 $y=y_1e_1+\cdots+y_{n+1}e_{n+1}\in\R^{n+1}$，$|y|$ 是 $y$ 的 Euclidean 范数，则
$$y\in S_n\Leftrightarrow |y|=1\Leftrightarrow y+e_{n+2}\in\L.$$
即我们有一一映射：
$$
\begin{aligned}
S^n&\mapsto S^n_1\\
y &\mapsto y+e_{n+2}.
\end{aligned}$$
其中 $S^n_1$ 是平面 $y_{n+2}=1$ 与 $\L$ 相交给出的截线。由于 $\PL$ 中每个元素在 $S^n_1$ 中有唯一代表元，所以
$$\jmath\colon\ S^n\to\PL: y\to [y+e_{n+2}],$$
是一一对应，此即为 $\PL$ 的第一种参数化表示。
:::

:::{.simple}
**$\PL$ 的第二种参数化表示** \

我们在 $\{e_0,e_1,\ldots,e_n,e_\infty\}$ 这组基下计算。对 $[v]\in\PL$：

+ 如果 $v$ 的 $e_0$ 分量不为 0，则 $v$ 形如
$$v=e_0 + x + be_\infty,\quad x\in\span\{e_1,\ldots,e_n\}.$$
由于 $v\in\L$ 所以 $b=|x|^2$，即 $v=e_0 + x + |x|^2e_\infty$。
+ 如果 $v$ 的 $e_0$ 分量等于 0，则 $v$ 形如
$$v=x+be_\infty,\quad x\in\span\{e_1,\ldots,e_n\}.$$
$v\in\L$ 说明 $x=0$，从而 $[v] = [(0,0,b)]=[e_\infty]$。

于是我们可以定义如下从 $\ER$ 到 $\PL$ 的一一对应:
$$
\imath(x)=\begin{cases}[e_0 + x + |x|^2e_\infty] & x\in\R^n,\\
[e_\infty] & x = \infty.
\end{cases}
$$
此即为 $\PL$ 的第二种参数化表示。
:::

我们来验证当 $x\in\overline{\R^n}$ 和 $y\in S^n$ 是以 $e_{n+1}$ 为北极的球极投影下的对应点时，$x,y$ 在这两种参数化表示下给出 $\PL$ 的同一个点。

设 $y=y_1e_1+\cdots+y_{n+1}e_{n+1}\in S^n$，$y$ 在以 $e_{n+1}$ 为北极的球极投影下对应的 $x\in\overline{\R^n}$ 是
$$x=\begin{cases}
\sum\limits_{i=1}^n\dfrac{y_i}{1-y_{n+1}}e_i & y_{n+1}\ne1,\\
\infty & y_{n+1}=1.
\end{cases}
$$
我们来验证 $\jmath(y)=\imath(x)$，即
$$[y + e_{n+2}] = \begin{cases}[e_0 + x + |x|^2e_\infty] & y_{n+1}\ne1\\
[e_\infty] & y_{n+1}=1.
\end{cases}.$$

+ $y_{n+1}=1$ 时 $y=e_{n+1}$ 从而 $y+e_{n+2}= e_{n+1}+e_{n+2}=2e_\infty$，显然与 $e_\infty$ 射影等价。

+ $y_{n+1}\ne 1$ 时，由 $y\in S^n$ 可得 $\sum_{i=1}^ny_i^2=1-y_{n+1}^2$，从而
$$|x|^2=\frac{\sum_{i=1}^n y_i^2}{(1-y_{n+1})^2}= \frac{1+y_{n+1}}{1-y_{n+1}}.$$
把 $y+e_{n+2}$ 转化为 $\{e_0,e_1,\ldots,e_n,e_\infty\}$ 这组基下的表示：
$$y+e_{n+2} = \sum_{i=1}^ny_ie_i + (1-y_{n+1})e_0+(1+y_{n+1})e_\infty.$$
从而
$$[y+e_{n+2}] = \left[e_0+\sum_{i=1}^n\frac{y_i}{1-y_{n+1}}e_i +\frac{1+y_{n+1}}{1-y_{n+1}}e_\infty\right] = [e_0 + x + |x|^2e_\infty].$$


## 球面

:::{.simple}
**记号**

规定 $\S=\{v\in\LR\mid( v,v)=1\}$ 是所有 space-like 单位向量组成的集合。
:::

这一小节我们来建立 $\R^n$ 中的球/超平面和 $\S$ 之间的一一对应。

设 $B(a,r)=\{x\in\R^n\mid |x-a|=|r|\}$ 是 $\R^n$ 中以 $a$ 为中心，半径为 $r\ne 0$ 的球，我们允许 $r$ 是负数以区分 $B$ 的内部和外部：$r>0$ 时 $B$ 的内部就是通常意义下满足 $|x-a|< r$ 的有界集合；$r<0$ 时 $B$ 的内部是满足 $|x-a|>|r|$ 的无界集合。如果用球极投影转移到 $S^n$ 中来看的话，$\R^n$ 中的球的内/外之分在 $S^n$ 上其实没有意义，它们不过是 $S^n$ 中某个圆两侧的球帽。所以把球的内部和外部统一处理是很自然的。

我们把 $a$ 看作 $\span\{e_1,\ldots,e_n\}$ 中的点，记
$$ k_B = \frac{e_0}{r} + \frac{a}{r} + \frac{|a|^2 - r^2}{r}e_\infty.$$
不难验证 $k_B$ 满足 $(k_B,k_B)=1$，所以 $k_B\in\mathcal{S}$。


对 $x\in\R^n$，设 $\imath(x)=e_0+x+ |\x|^2e_\infty$ 是 $x$ 在 $\L$ 的截线 $H_1$ 中对应的点，则
$$(\imath(x),k_B)=\frac{r^2-|x-a|^2}{2r}.$$

于是 $\x\in B$ 当且仅当 $(\imath(\x),k_B)=0$，以及 $\x$ 落在 $B$ 的内部当且仅当 $(\imath(\x),k_B)>0$。

注意到 $\imath(\x)$ 和 $\jmath(\x)$ 只差一个正的倍数，所以 $\x\in B$ 等价于 $(\jmath(\x),k_B)=0$，这是 $S^n_1$ 与超平面 $k_B^\bot$ 的截线，其围成的内部是 $S^n_1$ 上的一个球帽。


当 $B$ 是超平面时，设其方程为 $(\n,\x)=d$，其中 $(\n,\n)=1$ 是超平面的单位法向量，$d\in\R$。我们将其对应到
$$k_B=(\n, 0, 2d).$$
不难验证 $(k_B,k_B)=1$，从而 $k_B\in\S$，并且对 $\imath(\x)=(\x,1,|\x|^2)$ 有
$$(\imath(\x),k_B)=(\x,\n)-d.$$
同理 $\x\in B$ 等价于 $(\imath(x),k_B)=0$，$\x$ 属于 $B$ 的正半空间 $(\n,\x)> d$ 当且仅当 $(\imath(\x),k_B)>0$。

反之任何 $k\in\S$ 也都唯一确定了 $\R^n$ 中的某个球或者超平面。为此只要设 $k=(\a, a, b)\in\S$，并根据 $a$ 是否等于 0 将 $k$ 对应为球 $B(\a/a ,1/a)$ 或者超平面 $H(\a, b/2)$ 即可。

最后，我们注意到 $k$ 和 $-k$ 分别对应一对内外互相翻转的球。

## 球面的 seperation

设 $B_1,B_2$ 是 $\R^n$ 中的两个球，球心分别为 $\a_1,\a_2$，半径分别为 $r_1,r_2$。记
$$k_1=\sph{\a_1}{r_1},\quad k_2=\sph{\a_2}{r_2}$$
分别是它们在 $\S$ 中对应的点，不难验证有
$$(k_1,k_2)=\frac{r_1^2+r_2^2 - |\a_1-\a_2|^2}{2r_1r_2}.$$
我们称如上的内积 $(k_1,k_2)$ 为 $B_1$ 和 $B_2$ 的 **seperation**。

1. $B_1$ 和 $B_2$ 相交当且仅当 $|(k_1,k_2)|\leq1$，这时 $(k_1,k_2)=\cos\theta$，$\theta$ 是它们球面交点处的内法向量夹角（用外法向量也可以，因为同时将内法向量变成外法向量，夹角的余弦不变）。当 $(k_1,k_2)=-1$ 时两球外切，$(k_1,k_2)=1$ 时两球内切。
2. $B_1$ 和 $B_2$ 不交当且仅当 $|(k_1,k_2)|>1$，这时 $|(k_1,k_2)|=\cosh\eta$，$\eta$ 是 $k_1,k_2$ 对应的双曲空间中测地线的双曲距离。两球在 $(k_1,k_2)<-1$ 时没有公共的内部，在 $(k_1,k_2)>1$ 时一个完全包含另一个。[见 @ratcliffe section 3.2]

|   |   |
|:---:|:---:|
| $(k_1,k_2)=\cos\theta$ |  $(k_1,k_2)=\cosh d(\ell_1,\ell_2)$  |
|![](images/image0.jpg){width=150} | ![](images/image1.jpg){width=150}  |
| $(k_1,k_2)=-\cosh d(\ell_1,\ell_2)$    | $(k_1,k_2)=-\cosh d(\ell_1,\ell_2)$|
|![](images/image2.jpg){width=150} | ![](images/image3.jpg){width=150}|

上面的结论同样适用于 $B_1$ 和 $B_2$ 中有平面的情形。例如设 $B_1,B_2$ 相交，并且 $B_1$ 是球面，$B_2$ 是超平面，其方程为 $(\x,\n)=d$，则 $k_2=(\n, 0, 2d)$，
$$(k_1,k_2)=\frac{(\a_1,\n)-d}{r_1}.$$
这时 $(k_1,k_2)$ 等于 $B_1$ 在球面交点处的内法向量和平面法向量夹角的余弦。

此外，当 $B_1,B_2$ 都是超平面时，$(k_1,k_2)=(\n_1,\n_2)$ 是它们法向量的夹角。

::: {.proposition #suff-for-disjoint}
设 $B_1,B_2$ 是两个球，且 $B_1,B_2$ 的内部不相交。设 $(k_1,k_2)$ 分别是它们对应的 space-like 的单位向量，则 $(k_1,k_2)\leq-1$。
:::

:::note
这个命题反过来是不对的。
:::

**证明**：$B_1$ 和 $B_2$ 内部不相交有如下几种可能：

1. $B_1,B_2$ 都是球，半径 $r_1,r_2$ 都大于 0，并且 $r_1+r_2 \geq |\a_1-\a_2|$。
2. $B_1,B_2$ 都是球，半径 $r_1>0,\, r_2<0$，且 $B_1$ 位于 $B_2$ 另一侧的有界区域，即 $-r_2-r_1\geq |\a_1-\a_2|$。
3. $B_1$ 是球，其半径 $r_1>0$；$B_2$ 是超平面，且 $B_1$ 位于 $B_2$ 的负半空间，从而其球心 $\a_1$ 到 $(\n,\x)=d$ 的有向距离 $\leq-r_1$，即 $(\a_1,\n)-d\leq -r_1$。
4. $B_1,B_2$ 是互相平行的超平面，且法向量相反的，即 $(\n_1,\n_2)=-1$。

不难验证这些都可以推出 $(k_1,k_2)\leq-1$。


## 球面的反演

::: definition
设 $B$ 是 $\R^n$ 中以 $\a$ 为中心，半径为 $r$ 的球。关于 $B$ 的反演 $\tau:\ER\to\ER$ 定义为
$$\tau(\x)=\frac{r^2}{|\x-\a|^2}(\x-\a) +\a.$$
:::
$\tau$ 是 $\R^n$ 中关于球面镜 $B$ 的反射，它保持 $B$ 的球面不动，将 $B$ 的内部映射为外部（反之亦然），并且 $\tau^2=1$。

![](images/cartoon_mirror.png){width=400}

我们来说明 $\tau$ 可以实现为 $n+1$ 维射影空间 $\PR$ 中的射影正交变换。

设 $\x\in\R^n$，$\imath(x)=(\x,1,|\x|^2)\in\L$。记 $k_B=\left(\frac{\a}{r},\frac{1}{r},\frac{|\a|^2-r^2}{r}\right)$ 为 $B$ 对应的单位向量，考虑反射 $\rho_B:\LR\to\LR$：
$$\rho_B(v) = v - 2(v,k_B)k_B,\quad v\in V.$$
注意到 $(\imath(x),k_B)=\frac{r^2-|\x-\a|^2}{2r}$，我们来验证
$$\begin{align*}
\begin{pmatrix}\x\\1\\ |\x|^2\end{pmatrix} &\xrightarrow{\rho_B}
\begin{pmatrix}\x\\1\\ |\x|^2\end{pmatrix} -\frac{r^2-|\x-\a|^2}{r}\begin{pmatrix}\frac{\a}{r}\\\frac{1}{r}\\ \frac{|\a|-r^2}{r}\end{pmatrix}\\
&=\begin{pmatrix}\x+\left(\frac{|\x-\a|^2}{r^2}-1\right)\a\\\frac{|\x-\a|^2}{r^2}\\ \ast \end{pmatrix}\\
&\sim \begin{pmatrix}\a+\frac{r^2}{|\x-\a|^2}(\x-\a)\\1\\ \ast \end{pmatrix}.
\end{align*}$$
这里我们不用关心 $\ast$ 是什么，最后的 $\sim$ 表示两个向量是射影等价的。注意到最后一步使用的归一化因子是 $\frac{|\x-\a|^2}{r^2}\geq0$，所以还是正射影等价的。

即我们有如下的交换图：

$$\require{amsCd}
\begin{CD}
\ER @>{\imath}>> \PL\\
@V{\tau}VV  @VV{\rho_B}V \\
\ER @>{\imath}>> \PL
\end{CD}$$

不仅如此，球和球之间的反演也可以通过 $\rho_B$ 来计算。设 $k$ 是球 $B'$ 对应的 space-like 的单位向量，则 $\rho_B(k)$ 也是 space-like 的单位向量，从而对应另一个球 $B''$。对 $\x\in\R^n$，根据上面的交换图有 $\rho_B\imath=\imath\tau$，从而
$$\x\in B''\Leftrightarrow (\imath(\x), \rho_B(k))=0
\Leftrightarrow(\rho_B(\imath(\x)), k)=0
\Leftrightarrow(\imath(\tau(\x)), k)=0
\Leftrightarrow \tau(\x)\in B'.
$$


# 双曲球堆

::: definition
如果一个非空集合 $\P\subset V$ 满足下列条件，我们就称 $\P$ 是一个**球堆**：

1. 对任何 $k\in\P$ 有 $(k,k)=1$。
2. 对 $\P$ 中任何 $k\ne k'$ 有 $(k,k')\leq -1$。
:::


我们称形如 $\P=\{k,-k\}$ 的球堆是平凡的，因为它由一个球的内部和外部组成。否则就称 $\P$ 是非平凡的。非平凡的球堆中的点必然两两互不共线。如果 $\P$ 是非平凡的球堆，则 $-\P=\{-k\mid k\in\P\}$ 也是非平凡的，它是通过翻转 $\P$ 中每个球的内部和外部得到的。

记 $\H$ 是超平面 $\{v_{n+2}=1\}$ 与 $\Q_+$ 的截面，对任何满足 $(k,k)=1$ 的点 $k$，定义球帽
$$C_k = \{v\in\H\mid (v,k)\geq0\}.$$

::: {.lemma #disjoint-pair}
设 $\P$ 是球堆且 $k_1\ne k_2\in\P$，则集合 $C_{k_1}\cap C_{k_2}$ 和 $C_{-k_1}\cap C_{-k_2}$ 中必有一个至多只包含一个点。并且当这两个集合中的某个恰好只含一个点时，此点与 $k_1+k_2$ 共线，并且有 $(k_1,k_2)=-1$ 成立。
:::

**证明**：设 $u\in C_{k_1}\cap C_{k_2}$，$v\in C_{-k_1}\cap C_{-k_2}$，则
$$(u, k_1+k_2)\geq0\quad\text{and}\quad(v,k_1+k_2)\leq0.$$
由于 $(k_1+k_2,k_1+k_2)=2+2(k_1,k_2)\leq0$，所以 $k_1+k_2$ 是 time-like 或者 light-like 的。如果 $k_1+k_2$ 是 time-like 的，则 $u\not\sim k_1+k_2$ 且 $v\sim k_1+k_2$，这与 $u\sim v$ 矛盾。所以 $k_1+k_2$ 必须是 light-like 的，从而 $(k_1,k_2)=-1$。

进一步如果 $(u,k_1+k_2)>0$ 且 $(v,k_1+k_2)<0$，则 $v\sim k_1+k_2$ 但是 $u\not\sim k_1+k_2$，这与 $u\sim v$ 矛盾。所以 $(u,k_1+k_2)$ 和 $(v,k_1+k_2)$ 中必然有一个是 0，即 $u$ 和 $v$ 中必有一个是 $k_1+k_2$ 的倍数，然而 $\H$ 中与 $k_1+k_2$ 共线的点是唯一确定的，所以 $C_{k_1}\cap C_{k_2}$ 和 $C_{-k_1}\cap C_{-k_2}$ 中必有一个至多包含一个点，且此点与 $k_1+k_2$ 共线。$\blacksquare$

:::{.lemma #contain-time-like}
设 $\P$ 是球堆且 $k_1\ne k_2\in\P$。如果 $|C_{k_1}\cap C_{k_2}|>1$，则 $C_{k_1}\cap C_{k_2}$ 中必然包含某个 time-like 的向量。
:::
**证明**：
设 $u,v\in C_{k_1}\cap C_{k_2}$ 是两个不同点，则 $u\sim v$ 且 $u,v$ 线性无关，从而 $(u,v)<0$。$z=u+v$ 满足 $z\sim u$ 和 $(z,z)<0$，从而 $z$ 的某个正倍数 $z'$ 属于 $\H$。$z'$ 即为所求。
$\blacksquare$

:::{.lemma #intersect-pair}
设 $\P$ 是球堆且 $k_1\ne k_2\in\P$。如果 $v\in\H$ 满足
$$(v,k_1)\geq0\quad \text{and}\quad (v,k_2)>0.$$
则 $|C_{k_1}\cap C_{k_2}|>1$。
:::

**证明**：记 $a=(v,k_2)>0$，考虑向量 $u=v-tk_2$，其中 $t\in(0, a)$ 是实数。

由于 $(u,u)=(v,v)+t^2-2at<0$ 是 time-like 的，以及 $(u,v)=(v,v)-at<0$，所以 $u\sim v$。从而 $u$ 的某个正倍数 $u'=cu\,(c>0)$ 属于 $\H$。由于

$$\begin{aligned}
(u,k_1)&=\overbrace{(v,k_1)}^{\geq0} - \overbrace{t}^{>0}\cdot\overbrace{(k_1,k_2)}^{\leq-1}>0,\\
(u,k_2)&=a-t>0.\end{aligned}$$
所以 $(u',k_1)>0,\,(u',k_2)>0$，从而 $u'\in C_{k_1}\cap C_{k_2}$。由于 $t\in(0,a)$ 有无穷多个取值，并且不难验证不同的 $t$ 给出的 $u'$ 互不相同，所以 $|C_{k_1}\cap C_{k_2}|=\infty>1$。$\blacksquare$

::: {.theorem #thm-sphere-packing}
设 $\P$ 是 $V$ 的一个非空子集，则下面两点是等价的：

1. $\P$ 是一个非平凡的球堆。
2. 对 $\P$ 或者 $-\P$ 之一，其包含的任何两个球帽 $C_k$ 和 $C_{k'}$ 至多有一个公共点。
:::
**证明**：

1 $\Rightarrow$ 2：根据 @Pre:disjoint-pair，不妨设 $k_1,k_2\in\P$ 使得 $C_{k_1}\cap C_{k_2}$ 至多包含一个点。我们来证明任何两个球帽 $k\ne k'\in\P$ 之间至多只有一个公共点。不妨设 $k\notin\{k_1,k_2\}$。用反证法，若 $|C_k\cap C_{k'}|>1$，我们来说明这时同样也有 $|C_{-k}\cap C_{-k'}|>1$，从而与 @Pre:disjoint-pair 矛盾。

根据 @Pre:contain-time-like，存在 time-like 的向量 $v\in C_k\cap C_{k'}$。我们来找 $w\sim v$ 满足 $(w, k)<0$ 和 $(w,k')\leq0$，这样的话 $w$ 的某个正倍数 $w'\in\H$ 并且 $(w',-k)>0,\,(w',-k')\geq0$，根据 @Pre:intersect-pair 即得 $|C_{-k}\cap C_{-k'}|>1$。

$w$ 的构造很容易，$w=k_1-(k_1,k_2)k_2$ 就满足要求。不难验证 $(w, k)<0$ 和 $(w,k')\leq0$。麻烦的地方在于证明 $w\sim v$。由于 $v$ 是 time-like 的，所以只要 $(v,w)\leq0$ 即可保证 $w\sim v$（实际上严格的不等号成立）。我们有
$$(v,w)=(v,k_1)-(k_1,k_2)(v,k_2)=(v-(v,k_2)k_2, k_1).$$
记 $u=v-(v, k_2)k_2$，则目标变为证明 $(u,k_1)\leq0$。注意到

$$\begin{aligned}
(u,k_2) &= (v,k_2) - (v,k_2)(k_2,k_2)=0,\\
(u,u)&=(u,v),\\
(u,u)&=\underbrace{(v,v)}_{<0}-\underbrace{(v,k_2)^2}_{\leq0} <0.
\end{aligned}
$$
即 $(u,u)=(u,v)<0$，从而 $u\sim v$。于是 $u$ 的某个正倍数 $u'$ 属于 $\H$。如果 $(u,k_1)>0$ 的话由 @Pre:intersect-pair 可得 $|C_{k_1}\cap C_{k_2}|>1$，矛盾。从而 $(v,w)\leq0$。这就证明了 $w\sim v$。

2 $\Rightarrow$ 1: 不妨设 $\P$ 中任何两个球帽至多只有一个交点。则对任何 $k_1,k_2\in\P$，内积 $\inn$ 限制在二维子空间 $U=\span\{k_1,k_2\}$ 上肯定不是正定的，否则的话 $U^\bot=k_1^\bot\cap k_2^\bot$ 是 time-like 的，从而 $C_{k_1}$ 和 $C_{k_2}$ 会在 $\H$ 的内部有交点，所以 $|(k_1,k_2)|\geq1$。如果 $(k_1,k_2)\geq1$，则 $C_{k_1}\cap C_{-k_2}$ 和 $C_{-k_1}\cap C_{k_2}$ 中必有一个至多只包含一个点，不妨设 $|C_{k_1}\cap C_{-k_2}|\leq1$。但是根据已知 $C_{k_1}\cap C_{k_2}$ 也至多只包含一个点，从而 $C_{k_1}$ 作为二者的并至多只有一个点，矛盾。$\blacksquare$


::: definition
记 $\Omega_r=\{\omega\in\Omega\mid (\omega,\omega)>0\}$ 是所有实权组成的集合，$\tc_r=\cone{\Omega_r}$ 是由所有实权生成的凸锥，以及
$$\hat{\Omega}_r=\{\hat{\omega}\mid \omega\in\Omega_r\}.$$
其中 $\hat{\omega}=\omega/\sqrt{(\omega,\omega)}$ 是将 $\omega$ 归一化得到的单位向量。
:::

::: {.theorem #real-cone-closure}
如果 $W$ 是不可约、双曲的，且 level 大于等于 2，则 $\tcr = \cl{\tc}$。
:::


**证明**：只要证明 $\tcr$ 包含那些非实的基本权 $(\omega_s, \omega_s)\leq 0$ 即可。若如此，则 $\tcr$ 包含全部基本权 $\Delta^\ast$，从而也包含 $\cone{\Delta^\ast}=\barfd$，再结合 $\tcr$ 是 $W$- 不变的，即得 $\tcr$ 包含 $\bigcup\limits_{w\in W}w\barfd=\tc$，从而包含 $\cl{\tc}$。

设 $\omega_s$ 是任一非实的基本权，记 $I=S-\{s\}$，$W_I$ 为标准椭圆子群。

$(\omega_s,\omega_s)<0$ 的情形比较容易，这时 $\omega_s$ 是 time-like 的，其正交补 $V_I=\span\{\alpha_t\mid t\ne s\}$ 是 space-like 的，从而 $W_I$ 是有限群。任取一个实的基本权 $(\omega_t,\omega_t)>0\,(t\in I)$ 并考虑
$$v = \sum_{w\in W_I}w(\omega_t),$$
显然 $v\in\tcr$，并且 $W_I$ 保持 $v$ 不动。特别地对任何 $t\in I$ 都有 $t(v)=v$。这是 $n-1$ 个独立的线性约束，其解空间是一维的，所以 $v$ 和 $\omega_s$ 共线：存在 $a\in\R$ 使得 $v=a\omega_k$。两边同时与 $\alpha_s$ 作内积得到
$$a = (\alpha_s,v)=\sum_{w\in W_I}(\alpha_s,w(\omega_t))=\sum_{w\in W_I}(w^{-1}(\alpha_s), \omega_t)=\sum_{w\in W_I}(w(\alpha_s), \omega_t).$$
对任何 $w\in W_I$，$w\alpha_s$ 形如 $w\alpha_s=\alpha_s+\sum_{i\in I}c_i\alpha_i$，所以 $w\alpha_s$ 仍然是正根，所有的系数 $c_i$ 都非负。所以上式右边的每一项
$$(w(\alpha_s), \omega_t)=\sum_{i\in I}c_i(\alpha_i, w_t) = c_t\geq0.$$
我们来选择一个特殊的 $w\in W_I$ 使得 $c_t>0$：由于 $\Gamma$ 是连通的，所以 $\Gamma$ 中存在一条从 $s$ 到 $t$ 的路径 $s=s_0\sim s_1\sim\cdots\sim s_m=t$，其中每个 $s_i\,(i\geq1)\in I$  且互不相同。不难验证对 $w=s_m\cdots s_1\in W_I$，$w\alpha_s$ 的系数 $c_t>0$，所以 $a$ 严格大于 0，所以 $\omega_s=v/a\in\tcr$。

$(\omega_s, \omega_s)=0$ 的情形稍微麻烦一些：这时 $\omega_s$ 的正交补 $\omega_s^\bot$ 是 light-like 的，即子图 $\Gamma\setminus\{s\}$ 是仿射的。特别地，$\Gamma\setminus\{s\}$ 由一些仿射或者有限的连通成分组成，并且有且恰有一个连通成分是仿射的（否则两个线性无关的 light-like 的向量的组合会给出 time-like 的向量）。任取一个实的基本权 $(\omega_t,\omega_t)>0$，我们需要讨论两种情况：

1. 如果 $\omega_t$ 属于某个有限型的连通成分 $Y$，类似上面的讨论，$v = \sum_{w\in W_Y}w(\omega_t)\in\tcr$ 满足对任何 $t\ne s$ 都有 $t(v)=v$，从而 $v$ 等于 $\omega_s$ 乘以一个正实数，从而 $\omega_s\in\tcr$。

2. 如果 $\omega_t$ 属于某个仿射型的连通成分 $X$，设 $Y=\Gamma\setminus(X\cup\{s\})$ 是 $\Gamma\setminus\{s\}$ 除去 $X$ 以外其它连通成分的并，则 $X$ 和 $Y$ 互不连通，从而
$$\omega_s = \underbrace{(\omega_s, \omega_s)}_{=0}\alpha_s + \sum_{t\ne s} (\omega_s, \omega_t)\alpha_t=\sum_{t\in X} (\omega_s,\omega_t)\alpha_t + \sum_{t\in Y} (\omega_s,\omega_t)\alpha_t=v_1+v_2.$$
这里 $v_1$ 和 $v_2$ 是正交的。于是
$$(\omega_s, \omega_s)=0\Rightarrow (v_1+v_2,v_1+v_2)=0\Rightarrow (v_1,v_1) + (v_2,v_2) = 0.$$
由于 $v_1\in V_X$ 来自不可约仿射型，$v_2\in V_Y$ 来自有限型，所以 $\R v_1=\rad(V_X)$ 并且 $v_2=0$，从而 $\omega_s=v_1$。于是 $\R \omega_s=\rad(V_X)$。从而 $\omega_s$ 表示为 $\{\alpha_i\mid i\in X\}$ 的线性组合时，所有的系数 $(\omega_s,\omega_i)$ 系数都是非零且同号的。我们断言它们都小于 0。实际上在
$$\omega_s=\sum_{i\in X} (\omega_s,\omega_i)\alpha_i$$
两边同时用 $\alpha_s$ 作内积有
$$1=(\omega_s,\alpha_s)=\sum_{i\in X} (\omega_s, \omega_i)\underbrace{(\alpha_s,\alpha_i)}_{\leq0}.$$
所以必须所有 $(\omega_s, \omega_i)<0$。所以 $X\cup \{s\}$ 构成的子图满足 [这个结论](/coxeter-groups-level/#ideal-vertex) 的条件，于是我们得到
$$\omega_s\in\cl{\cone{\bigcup_{w\in W_I}w(\omega_t)}}\subset\tcr.$$

$\blacksquare$

::: {.theorem #max-packing}
若 $W$ 是双曲的，则 $\hat{\Omega}_r$ 是非平凡的球堆当且仅当 $\Gamma$ 的 level 是 2，这时 $\hat{\Omega}_r$ 还是极大球堆。
:::

**证明**：若 $\Gamma$ 的 level 是 2，则 [$\Omega_r$ 中的元素两两分离](/coxeter-groups-level#level-12)，将其归一化后得到的 $\hat{\Omega}_r$ 仍然两两分离，所以 $\hat{\Omega}_r$ 的元素两两之间的内积 $\leq -1$，从而 $\hat{\Omega}_r$ 给出一个球堆。如果存在某个 space-like 的向量 $k$ 满足 $(k,k)=1$ 且 $k$ 对应的球与 $\hat{\Omega}_r$ 中的任何球都没有公共内部的话，有 $(k,\hat{\omega})\leq -1$ 对任何 $\hat{\omega}\in\hat{\Omega}_r$ 成立，从而 $(k,\omega)<0$ 对任何 $\omega\in\Omega_r$ 成立，从而 $(k,y)\leq0$ 对任何 $y\in\tcr=\cone{\Omega_r}$ 成立。根据 @Pre:real-cone-closure，$\tcr=\cl{\tc}$，这意味着 $(k,y)\leq0$ 对任何 $y\in\tc$ 成立，即 $-k\in\tc^\ast$。由于 [对偶锥 $\tc^\ast$ 中的向量范数 $\leq0$](/coxeter-groups-tits-cone/#dual-cone-nonspace)，$(k,k)=(-k,-k)\leq0$，矛盾。这就证明了 level 2 时 $\Omega_r$ 是极大球堆。

反之若 $\hat{\Omega}_r$ 是一个非平凡球堆，则 $W$ 的 level 必然大于 1，且所有的实权之间两两分离。于是任何两个基本权生成的二维子空间 $\span\{\omega_i,\omega_j\}$ 都是 time-like 或者 light-like 的。又由于 $W$ 是双曲的，从而 $\Gamma\setminus\{i,j\}$ 是 space-like 或者 light-like 的，所以 $\Gamma$ 的 level 只能是 2。$\blacksquare$